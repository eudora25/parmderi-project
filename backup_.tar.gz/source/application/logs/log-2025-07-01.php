<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-07-01 00:59:05 --> Config Class Initialized
INFO - 2025-07-01 00:59:05 --> Hooks Class Initialized
DEBUG - 2025-07-01 00:59:05 --> UTF-8 Support Enabled
INFO - 2025-07-01 00:59:05 --> Utf8 Class Initialized
INFO - 2025-07-01 00:59:05 --> URI Class Initialized
DEBUG - 2025-07-01 00:59:05 --> No URI present. Default controller set.
INFO - 2025-07-01 00:59:05 --> Router Class Initialized
INFO - 2025-07-01 00:59:05 --> Output Class Initialized
INFO - 2025-07-01 00:59:05 --> Security Class Initialized
DEBUG - 2025-07-01 00:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 00:59:05 --> Input Class Initialized
INFO - 2025-07-01 00:59:05 --> Language Class Initialized
INFO - 2025-07-01 00:59:05 --> Loader Class Initialized
INFO - 2025-07-01 00:59:05 --> Helper loaded: url_helper
INFO - 2025-07-01 00:59:05 --> Helper loaded: form_helper
INFO - 2025-07-01 00:59:05 --> Helper loaded: file_helper
INFO - 2025-07-01 00:59:05 --> Database Driver Class Initialized
DEBUG - 2025-07-01 00:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 00:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 00:59:06 --> Form Validation Class Initialized
INFO - 2025-07-01 00:59:06 --> Upload Class Initialized
INFO - 2025-07-01 00:59:06 --> Controller Class Initialized
INFO - 2025-07-01 00:59:06 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-07-01 00:59:06 --> Final output sent to browser
DEBUG - 2025-07-01 00:59:06 --> Total execution time: 1.1097
INFO - 2025-07-01 01:02:12 --> Config Class Initialized
INFO - 2025-07-01 01:02:12 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:02:12 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:02:12 --> Utf8 Class Initialized
INFO - 2025-07-01 01:02:12 --> URI Class Initialized
DEBUG - 2025-07-01 01:02:12 --> No URI present. Default controller set.
INFO - 2025-07-01 01:02:12 --> Router Class Initialized
INFO - 2025-07-01 01:02:12 --> Output Class Initialized
INFO - 2025-07-01 01:02:12 --> Security Class Initialized
DEBUG - 2025-07-01 01:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:02:12 --> Input Class Initialized
INFO - 2025-07-01 01:02:12 --> Language Class Initialized
INFO - 2025-07-01 01:02:12 --> Loader Class Initialized
INFO - 2025-07-01 01:02:12 --> Helper loaded: url_helper
INFO - 2025-07-01 01:02:12 --> Helper loaded: form_helper
INFO - 2025-07-01 01:02:12 --> Helper loaded: file_helper
INFO - 2025-07-01 01:02:12 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:02:12 --> Form Validation Class Initialized
INFO - 2025-07-01 01:02:12 --> Upload Class Initialized
INFO - 2025-07-01 01:02:12 --> Controller Class Initialized
INFO - 2025-07-01 01:02:12 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-07-01 01:02:12 --> Final output sent to browser
DEBUG - 2025-07-01 01:02:12 --> Total execution time: 0.2061
INFO - 2025-07-01 01:02:40 --> Config Class Initialized
INFO - 2025-07-01 01:02:40 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:02:40 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:02:40 --> Utf8 Class Initialized
INFO - 2025-07-01 01:02:40 --> URI Class Initialized
DEBUG - 2025-07-01 01:02:40 --> No URI present. Default controller set.
INFO - 2025-07-01 01:02:40 --> Router Class Initialized
INFO - 2025-07-01 01:02:40 --> Output Class Initialized
INFO - 2025-07-01 01:02:40 --> Security Class Initialized
DEBUG - 2025-07-01 01:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:02:40 --> Input Class Initialized
INFO - 2025-07-01 01:02:40 --> Language Class Initialized
INFO - 2025-07-01 01:02:40 --> Loader Class Initialized
INFO - 2025-07-01 01:02:40 --> Helper loaded: url_helper
INFO - 2025-07-01 01:02:40 --> Helper loaded: form_helper
INFO - 2025-07-01 01:02:40 --> Helper loaded: file_helper
INFO - 2025-07-01 01:02:40 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:02:40 --> Form Validation Class Initialized
INFO - 2025-07-01 01:02:40 --> Upload Class Initialized
INFO - 2025-07-01 01:02:40 --> Controller Class Initialized
INFO - 2025-07-01 01:02:40 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-07-01 01:02:40 --> Final output sent to browser
DEBUG - 2025-07-01 01:02:40 --> Total execution time: 0.1699
INFO - 2025-07-01 01:02:43 --> Config Class Initialized
INFO - 2025-07-01 01:02:43 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:02:43 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:02:43 --> Utf8 Class Initialized
INFO - 2025-07-01 01:02:43 --> URI Class Initialized
INFO - 2025-07-01 01:02:43 --> Router Class Initialized
INFO - 2025-07-01 01:02:43 --> Output Class Initialized
INFO - 2025-07-01 01:02:43 --> Security Class Initialized
DEBUG - 2025-07-01 01:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:02:43 --> Input Class Initialized
INFO - 2025-07-01 01:02:43 --> Language Class Initialized
ERROR - 2025-07-01 01:02:43 --> Severity: Compile Error --> Cannot redeclare Medical_products::search() /var/www/html/source/application/controllers/Medical_products.php 157
INFO - 2025-07-01 01:14:41 --> Config Class Initialized
INFO - 2025-07-01 01:14:41 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:14:41 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:14:41 --> Utf8 Class Initialized
INFO - 2025-07-01 01:14:41 --> URI Class Initialized
DEBUG - 2025-07-01 01:14:41 --> No URI present. Default controller set.
INFO - 2025-07-01 01:14:41 --> Router Class Initialized
INFO - 2025-07-01 01:14:41 --> Output Class Initialized
INFO - 2025-07-01 01:14:41 --> Security Class Initialized
DEBUG - 2025-07-01 01:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:14:41 --> Input Class Initialized
INFO - 2025-07-01 01:14:41 --> Language Class Initialized
INFO - 2025-07-01 01:14:41 --> Loader Class Initialized
INFO - 2025-07-01 01:14:41 --> Helper loaded: url_helper
INFO - 2025-07-01 01:14:41 --> Helper loaded: form_helper
INFO - 2025-07-01 01:14:41 --> Helper loaded: file_helper
INFO - 2025-07-01 01:14:41 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:14:41 --> Form Validation Class Initialized
INFO - 2025-07-01 01:14:41 --> Upload Class Initialized
INFO - 2025-07-01 01:14:41 --> Controller Class Initialized
INFO - 2025-07-01 01:14:41 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-07-01 01:14:41 --> Final output sent to browser
DEBUG - 2025-07-01 01:14:41 --> Total execution time: 0.2017
INFO - 2025-07-01 01:24:36 --> Config Class Initialized
INFO - 2025-07-01 01:24:36 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:24:36 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:24:36 --> Utf8 Class Initialized
INFO - 2025-07-01 01:24:36 --> URI Class Initialized
DEBUG - 2025-07-01 01:24:36 --> No URI present. Default controller set.
INFO - 2025-07-01 01:24:36 --> Router Class Initialized
INFO - 2025-07-01 01:24:36 --> Output Class Initialized
INFO - 2025-07-01 01:24:36 --> Security Class Initialized
DEBUG - 2025-07-01 01:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:24:36 --> Input Class Initialized
INFO - 2025-07-01 01:24:36 --> Language Class Initialized
INFO - 2025-07-01 01:24:36 --> Loader Class Initialized
INFO - 2025-07-01 01:24:36 --> Helper loaded: url_helper
INFO - 2025-07-01 01:24:36 --> Helper loaded: form_helper
INFO - 2025-07-01 01:24:36 --> Helper loaded: file_helper
INFO - 2025-07-01 01:24:36 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:24:36 --> Form Validation Class Initialized
INFO - 2025-07-01 01:24:36 --> Upload Class Initialized
INFO - 2025-07-01 01:24:36 --> Controller Class Initialized
INFO - 2025-07-01 01:24:36 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-07-01 01:24:36 --> Final output sent to browser
DEBUG - 2025-07-01 01:24:36 --> Total execution time: 0.4076
INFO - 2025-07-01 01:32:42 --> Config Class Initialized
INFO - 2025-07-01 01:32:42 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:32:42 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:32:42 --> Utf8 Class Initialized
INFO - 2025-07-01 01:32:42 --> URI Class Initialized
DEBUG - 2025-07-01 01:32:42 --> No URI present. Default controller set.
INFO - 2025-07-01 01:32:42 --> Router Class Initialized
INFO - 2025-07-01 01:32:42 --> Output Class Initialized
INFO - 2025-07-01 01:32:42 --> Security Class Initialized
DEBUG - 2025-07-01 01:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:32:42 --> Input Class Initialized
INFO - 2025-07-01 01:32:42 --> Language Class Initialized
INFO - 2025-07-01 01:32:42 --> Loader Class Initialized
INFO - 2025-07-01 01:32:42 --> Helper loaded: url_helper
INFO - 2025-07-01 01:32:42 --> Helper loaded: form_helper
INFO - 2025-07-01 01:32:42 --> Helper loaded: file_helper
INFO - 2025-07-01 01:32:42 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:32:42 --> Form Validation Class Initialized
INFO - 2025-07-01 01:32:42 --> Upload Class Initialized
INFO - 2025-07-01 01:32:42 --> Controller Class Initialized
INFO - 2025-07-01 01:32:42 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-07-01 01:32:42 --> Final output sent to browser
DEBUG - 2025-07-01 01:32:42 --> Total execution time: 0.1785
INFO - 2025-07-01 01:32:42 --> Config Class Initialized
INFO - 2025-07-01 01:32:42 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:32:42 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:32:42 --> Utf8 Class Initialized
INFO - 2025-07-01 01:32:42 --> URI Class Initialized
INFO - 2025-07-01 01:32:42 --> Router Class Initialized
INFO - 2025-07-01 01:32:42 --> Output Class Initialized
INFO - 2025-07-01 01:32:42 --> Security Class Initialized
DEBUG - 2025-07-01 01:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:32:42 --> Input Class Initialized
INFO - 2025-07-01 01:32:42 --> Language Class Initialized
INFO - 2025-07-01 01:32:46 --> Config Class Initialized
INFO - 2025-07-01 01:32:46 --> Config Class Initialized
INFO - 2025-07-01 01:32:46 --> Hooks Class Initialized
INFO - 2025-07-01 01:32:46 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:32:46 --> UTF-8 Support Enabled
DEBUG - 2025-07-01 01:32:46 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:32:46 --> Utf8 Class Initialized
INFO - 2025-07-01 01:32:46 --> Utf8 Class Initialized
INFO - 2025-07-01 01:32:46 --> URI Class Initialized
INFO - 2025-07-01 01:32:46 --> URI Class Initialized
INFO - 2025-07-01 01:32:46 --> Router Class Initialized
INFO - 2025-07-01 01:32:46 --> Router Class Initialized
INFO - 2025-07-01 01:32:46 --> Output Class Initialized
INFO - 2025-07-01 01:32:46 --> Output Class Initialized
INFO - 2025-07-01 01:32:46 --> Security Class Initialized
INFO - 2025-07-01 01:32:46 --> Security Class Initialized
DEBUG - 2025-07-01 01:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-07-01 01:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:32:46 --> Input Class Initialized
INFO - 2025-07-01 01:32:46 --> Input Class Initialized
INFO - 2025-07-01 01:32:46 --> Language Class Initialized
INFO - 2025-07-01 01:32:46 --> Language Class Initialized
INFO - 2025-07-01 01:35:19 --> Config Class Initialized
INFO - 2025-07-01 01:35:19 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:35:19 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:35:19 --> Utf8 Class Initialized
INFO - 2025-07-01 01:35:19 --> URI Class Initialized
DEBUG - 2025-07-01 01:35:19 --> No URI present. Default controller set.
INFO - 2025-07-01 01:35:19 --> Router Class Initialized
INFO - 2025-07-01 01:35:19 --> Output Class Initialized
INFO - 2025-07-01 01:35:19 --> Security Class Initialized
DEBUG - 2025-07-01 01:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:35:19 --> Input Class Initialized
INFO - 2025-07-01 01:35:19 --> Language Class Initialized
INFO - 2025-07-01 01:35:19 --> Loader Class Initialized
INFO - 2025-07-01 01:35:19 --> Helper loaded: url_helper
INFO - 2025-07-01 01:35:19 --> Helper loaded: form_helper
INFO - 2025-07-01 01:35:19 --> Helper loaded: file_helper
INFO - 2025-07-01 01:35:19 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:35:19 --> Form Validation Class Initialized
INFO - 2025-07-01 01:35:19 --> Upload Class Initialized
INFO - 2025-07-01 01:35:19 --> Controller Class Initialized
INFO - 2025-07-01 01:35:19 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-07-01 01:35:19 --> Final output sent to browser
DEBUG - 2025-07-01 01:35:19 --> Total execution time: 0.2870
INFO - 2025-07-01 01:35:19 --> Config Class Initialized
INFO - 2025-07-01 01:35:19 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:35:19 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:35:19 --> Utf8 Class Initialized
INFO - 2025-07-01 01:35:19 --> URI Class Initialized
INFO - 2025-07-01 01:35:19 --> Router Class Initialized
INFO - 2025-07-01 01:35:19 --> Output Class Initialized
INFO - 2025-07-01 01:35:19 --> Security Class Initialized
DEBUG - 2025-07-01 01:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:35:19 --> Input Class Initialized
INFO - 2025-07-01 01:35:19 --> Language Class Initialized
INFO - 2025-07-01 01:36:00 --> Config Class Initialized
INFO - 2025-07-01 01:36:00 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:36:00 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:36:00 --> Utf8 Class Initialized
INFO - 2025-07-01 01:36:00 --> URI Class Initialized
DEBUG - 2025-07-01 01:36:00 --> No URI present. Default controller set.
INFO - 2025-07-01 01:36:00 --> Router Class Initialized
INFO - 2025-07-01 01:36:00 --> Output Class Initialized
INFO - 2025-07-01 01:36:00 --> Security Class Initialized
DEBUG - 2025-07-01 01:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:36:00 --> Input Class Initialized
INFO - 2025-07-01 01:36:00 --> Language Class Initialized
INFO - 2025-07-01 01:36:00 --> Loader Class Initialized
INFO - 2025-07-01 01:36:00 --> Helper loaded: url_helper
INFO - 2025-07-01 01:36:00 --> Helper loaded: form_helper
INFO - 2025-07-01 01:36:00 --> Helper loaded: file_helper
INFO - 2025-07-01 01:36:00 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:36:00 --> Form Validation Class Initialized
INFO - 2025-07-01 01:36:00 --> Upload Class Initialized
INFO - 2025-07-01 01:36:00 --> Controller Class Initialized
INFO - 2025-07-01 01:36:00 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-07-01 01:36:00 --> Final output sent to browser
DEBUG - 2025-07-01 01:36:00 --> Total execution time: 0.1813
INFO - 2025-07-01 01:38:28 --> Config Class Initialized
INFO - 2025-07-01 01:38:28 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:38:28 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:38:28 --> Utf8 Class Initialized
INFO - 2025-07-01 01:38:28 --> URI Class Initialized
DEBUG - 2025-07-01 01:38:28 --> No URI present. Default controller set.
INFO - 2025-07-01 01:38:28 --> Router Class Initialized
INFO - 2025-07-01 01:38:28 --> Output Class Initialized
INFO - 2025-07-01 01:38:28 --> Security Class Initialized
DEBUG - 2025-07-01 01:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:38:28 --> Input Class Initialized
INFO - 2025-07-01 01:38:28 --> Language Class Initialized
INFO - 2025-07-01 01:38:28 --> Loader Class Initialized
INFO - 2025-07-01 01:38:28 --> Helper loaded: url_helper
INFO - 2025-07-01 01:38:28 --> Helper loaded: form_helper
INFO - 2025-07-01 01:38:28 --> Helper loaded: file_helper
INFO - 2025-07-01 01:38:28 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:38:28 --> Form Validation Class Initialized
INFO - 2025-07-01 01:38:28 --> Upload Class Initialized
INFO - 2025-07-01 01:38:28 --> Controller Class Initialized
INFO - 2025-07-01 01:38:28 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-07-01 01:38:28 --> Final output sent to browser
DEBUG - 2025-07-01 01:38:28 --> Total execution time: 0.1969
INFO - 2025-07-01 01:38:29 --> Config Class Initialized
INFO - 2025-07-01 01:38:29 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:38:29 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:38:29 --> Utf8 Class Initialized
INFO - 2025-07-01 01:38:29 --> URI Class Initialized
INFO - 2025-07-01 01:38:29 --> Router Class Initialized
INFO - 2025-07-01 01:38:29 --> Output Class Initialized
INFO - 2025-07-01 01:38:29 --> Security Class Initialized
DEBUG - 2025-07-01 01:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:38:29 --> Input Class Initialized
INFO - 2025-07-01 01:38:29 --> Language Class Initialized
INFO - 2025-07-01 01:47:28 --> Config Class Initialized
INFO - 2025-07-01 01:47:28 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:47:29 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:47:29 --> Utf8 Class Initialized
INFO - 2025-07-01 01:47:29 --> URI Class Initialized
DEBUG - 2025-07-01 01:47:29 --> No URI present. Default controller set.
INFO - 2025-07-01 01:47:29 --> Router Class Initialized
INFO - 2025-07-01 01:47:29 --> Output Class Initialized
INFO - 2025-07-01 01:47:29 --> Security Class Initialized
DEBUG - 2025-07-01 01:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:47:29 --> Input Class Initialized
INFO - 2025-07-01 01:47:29 --> Language Class Initialized
INFO - 2025-07-01 01:47:29 --> Loader Class Initialized
INFO - 2025-07-01 01:47:29 --> Helper loaded: url_helper
INFO - 2025-07-01 01:47:29 --> Helper loaded: form_helper
INFO - 2025-07-01 01:47:29 --> Helper loaded: file_helper
INFO - 2025-07-01 01:47:29 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:47:29 --> Form Validation Class Initialized
INFO - 2025-07-01 01:47:29 --> Upload Class Initialized
INFO - 2025-07-01 01:47:29 --> Controller Class Initialized
INFO - 2025-07-01 01:47:29 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-07-01 01:47:29 --> Final output sent to browser
DEBUG - 2025-07-01 01:47:29 --> Total execution time: 0.1879
INFO - 2025-07-01 01:47:29 --> Config Class Initialized
INFO - 2025-07-01 01:47:29 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:47:29 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:47:29 --> Utf8 Class Initialized
INFO - 2025-07-01 01:47:29 --> URI Class Initialized
INFO - 2025-07-01 01:47:29 --> Router Class Initialized
INFO - 2025-07-01 01:47:29 --> Output Class Initialized
INFO - 2025-07-01 01:47:29 --> Security Class Initialized
DEBUG - 2025-07-01 01:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:47:29 --> Input Class Initialized
INFO - 2025-07-01 01:47:29 --> Language Class Initialized
INFO - 2025-07-01 01:47:30 --> Config Class Initialized
INFO - 2025-07-01 01:47:30 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:47:30 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:47:30 --> Utf8 Class Initialized
INFO - 2025-07-01 01:47:30 --> URI Class Initialized
INFO - 2025-07-01 01:47:30 --> Router Class Initialized
INFO - 2025-07-01 01:47:30 --> Output Class Initialized
INFO - 2025-07-01 01:47:30 --> Security Class Initialized
DEBUG - 2025-07-01 01:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:47:30 --> Input Class Initialized
INFO - 2025-07-01 01:47:30 --> Language Class Initialized
INFO - 2025-07-01 01:47:30 --> Loader Class Initialized
INFO - 2025-07-01 01:47:30 --> Helper loaded: url_helper
INFO - 2025-07-01 01:47:30 --> Helper loaded: form_helper
INFO - 2025-07-01 01:47:30 --> Helper loaded: file_helper
INFO - 2025-07-01 01:47:30 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:47:30 --> Form Validation Class Initialized
INFO - 2025-07-01 01:47:30 --> Upload Class Initialized
INFO - 2025-07-01 01:47:30 --> Controller Class Initialized
INFO - 2025-07-01 01:47:30 --> Model "Question_type_model" initialized
INFO - 2025-07-01 01:47:30 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 01:47:30 --> Helper loaded: html_helper
DEBUG - 2025-07-01 01:47:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 01:47:31 --> File loaded: /var/www/html/source/application/views/hospital/search_main.php
INFO - 2025-07-01 01:47:31 --> Final output sent to browser
DEBUG - 2025-07-01 01:47:31 --> Total execution time: 0.4569
INFO - 2025-07-01 01:47:31 --> Config Class Initialized
INFO - 2025-07-01 01:47:31 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:47:31 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:47:31 --> Utf8 Class Initialized
INFO - 2025-07-01 01:47:31 --> URI Class Initialized
INFO - 2025-07-01 01:47:31 --> Router Class Initialized
INFO - 2025-07-01 01:47:31 --> Output Class Initialized
INFO - 2025-07-01 01:47:31 --> Security Class Initialized
DEBUG - 2025-07-01 01:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:47:31 --> Input Class Initialized
INFO - 2025-07-01 01:47:31 --> Language Class Initialized
INFO - 2025-07-01 01:50:43 --> Config Class Initialized
INFO - 2025-07-01 01:50:43 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:50:43 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:50:43 --> Utf8 Class Initialized
INFO - 2025-07-01 01:50:43 --> URI Class Initialized
INFO - 2025-07-01 01:50:43 --> Router Class Initialized
INFO - 2025-07-01 01:50:43 --> Output Class Initialized
INFO - 2025-07-01 01:50:43 --> Security Class Initialized
DEBUG - 2025-07-01 01:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:50:43 --> Input Class Initialized
INFO - 2025-07-01 01:50:43 --> Language Class Initialized
INFO - 2025-07-01 01:50:43 --> Loader Class Initialized
INFO - 2025-07-01 01:50:43 --> Helper loaded: url_helper
INFO - 2025-07-01 01:50:43 --> Helper loaded: form_helper
INFO - 2025-07-01 01:50:43 --> Helper loaded: file_helper
INFO - 2025-07-01 01:50:43 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:50:43 --> Form Validation Class Initialized
INFO - 2025-07-01 01:50:43 --> Upload Class Initialized
INFO - 2025-07-01 01:50:43 --> Controller Class Initialized
INFO - 2025-07-01 01:50:43 --> Model "Question_type_model" initialized
INFO - 2025-07-01 01:50:43 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 01:50:43 --> Helper loaded: html_helper
DEBUG - 2025-07-01 01:50:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 01:50:43 --> File loaded: /var/www/html/source/application/views/hospital/search_main.php
INFO - 2025-07-01 01:50:43 --> Final output sent to browser
DEBUG - 2025-07-01 01:50:43 --> Total execution time: 0.2146
INFO - 2025-07-01 01:50:43 --> Config Class Initialized
INFO - 2025-07-01 01:50:43 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:50:43 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:50:43 --> Utf8 Class Initialized
INFO - 2025-07-01 01:50:43 --> URI Class Initialized
INFO - 2025-07-01 01:50:43 --> Router Class Initialized
INFO - 2025-07-01 01:50:43 --> Output Class Initialized
INFO - 2025-07-01 01:50:43 --> Security Class Initialized
DEBUG - 2025-07-01 01:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:50:43 --> Input Class Initialized
INFO - 2025-07-01 01:50:43 --> Language Class Initialized
INFO - 2025-07-01 01:51:15 --> Config Class Initialized
INFO - 2025-07-01 01:51:15 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:51:15 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:51:15 --> Utf8 Class Initialized
INFO - 2025-07-01 01:51:15 --> URI Class Initialized
INFO - 2025-07-01 01:51:15 --> Router Class Initialized
INFO - 2025-07-01 01:51:15 --> Output Class Initialized
INFO - 2025-07-01 01:51:15 --> Security Class Initialized
DEBUG - 2025-07-01 01:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:51:15 --> Input Class Initialized
INFO - 2025-07-01 01:51:15 --> Language Class Initialized
INFO - 2025-07-01 01:51:15 --> Loader Class Initialized
INFO - 2025-07-01 01:51:15 --> Helper loaded: url_helper
INFO - 2025-07-01 01:51:15 --> Helper loaded: form_helper
INFO - 2025-07-01 01:51:15 --> Helper loaded: file_helper
INFO - 2025-07-01 01:51:15 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:51:15 --> Form Validation Class Initialized
INFO - 2025-07-01 01:51:15 --> Upload Class Initialized
INFO - 2025-07-01 01:51:15 --> Controller Class Initialized
INFO - 2025-07-01 01:51:15 --> Model "Question_type_model" initialized
INFO - 2025-07-01 01:51:15 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 01:51:15 --> Helper loaded: html_helper
DEBUG - 2025-07-01 01:51:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2025-07-01 01:51:15 --> Severity: Warning --> Trying to access array offset on value of type null /var/www/html/source/application/models/Hospital_search_model.php 350
ERROR - 2025-07-01 01:51:15 --> Severity: Warning --> Trying to access array offset on value of type null /var/www/html/source/application/models/Hospital_search_model.php 358
ERROR - 2025-07-01 01:51:15 --> Severity: Warning --> Trying to access array offset on value of type null /var/www/html/source/application/models/Hospital_search_model.php 366
INFO - 2025-07-01 01:51:15 --> 검색 로그: {"search_query":"\uc720\uc9c4\ub0b4\uacfc \uc9c4\ub8cc\uc2dc\uac04","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 01:51:15"}
INFO - 2025-07-01 01:51:15 --> Final output sent to browser
DEBUG - 2025-07-01 01:51:15 --> Total execution time: 0.2911
INFO - 2025-07-01 01:51:27 --> Config Class Initialized
INFO - 2025-07-01 01:51:27 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:51:27 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:51:27 --> Utf8 Class Initialized
INFO - 2025-07-01 01:51:27 --> URI Class Initialized
INFO - 2025-07-01 01:51:27 --> Router Class Initialized
INFO - 2025-07-01 01:51:27 --> Output Class Initialized
INFO - 2025-07-01 01:51:27 --> Security Class Initialized
DEBUG - 2025-07-01 01:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:51:27 --> Input Class Initialized
INFO - 2025-07-01 01:51:27 --> Language Class Initialized
INFO - 2025-07-01 01:51:27 --> Loader Class Initialized
INFO - 2025-07-01 01:51:27 --> Helper loaded: url_helper
INFO - 2025-07-01 01:51:27 --> Helper loaded: form_helper
INFO - 2025-07-01 01:51:27 --> Helper loaded: file_helper
INFO - 2025-07-01 01:51:27 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:51:27 --> Form Validation Class Initialized
INFO - 2025-07-01 01:51:27 --> Upload Class Initialized
INFO - 2025-07-01 01:51:27 --> Controller Class Initialized
INFO - 2025-07-01 01:51:27 --> Model "Question_type_model" initialized
INFO - 2025-07-01 01:51:27 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 01:51:27 --> Helper loaded: html_helper
DEBUG - 2025-07-01 01:51:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 01:51:27 --> 검색 로그: {"search_query":"\uc0bc\uc131\ubcd1\uc6d0 \uc8fc\uc18c","result_count":3,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 01:51:27"}
ERROR - 2025-07-01 01:51:27 --> Severity: Warning --> Undefined array key "search_params" /var/www/html/source/application/controllers/Hospital_search.php 57
INFO - 2025-07-01 01:51:27 --> Final output sent to browser
DEBUG - 2025-07-01 01:51:27 --> Total execution time: 0.8301
INFO - 2025-07-01 01:53:19 --> Config Class Initialized
INFO - 2025-07-01 01:53:19 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:53:19 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:53:19 --> Utf8 Class Initialized
INFO - 2025-07-01 01:53:19 --> URI Class Initialized
INFO - 2025-07-01 01:53:19 --> Router Class Initialized
INFO - 2025-07-01 01:53:19 --> Output Class Initialized
INFO - 2025-07-01 01:53:19 --> Security Class Initialized
DEBUG - 2025-07-01 01:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:53:19 --> Input Class Initialized
INFO - 2025-07-01 01:53:19 --> Language Class Initialized
INFO - 2025-07-01 01:53:19 --> Loader Class Initialized
INFO - 2025-07-01 01:53:19 --> Helper loaded: url_helper
INFO - 2025-07-01 01:53:19 --> Helper loaded: form_helper
INFO - 2025-07-01 01:53:19 --> Helper loaded: file_helper
INFO - 2025-07-01 01:53:19 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:53:19 --> Form Validation Class Initialized
INFO - 2025-07-01 01:53:19 --> Upload Class Initialized
INFO - 2025-07-01 01:53:19 --> Controller Class Initialized
INFO - 2025-07-01 01:53:19 --> Model "Question_type_model" initialized
INFO - 2025-07-01 01:53:19 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 01:53:19 --> Helper loaded: html_helper
DEBUG - 2025-07-01 01:53:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 01:53:19 --> 검색 로그: {"search_query":"\uc0bc\uc131\ubcd1\uc6d0 \uc8fc\uc18c","result_count":3,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 01:53:19"}
ERROR - 2025-07-01 01:53:19 --> Severity: Warning --> Undefined array key "search_params" /var/www/html/source/application/controllers/Hospital_search.php 57
INFO - 2025-07-01 01:53:19 --> Final output sent to browser
DEBUG - 2025-07-01 01:53:19 --> Total execution time: 0.4057
INFO - 2025-07-01 01:53:21 --> Config Class Initialized
INFO - 2025-07-01 01:53:21 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:53:21 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:53:21 --> Utf8 Class Initialized
INFO - 2025-07-01 01:53:21 --> URI Class Initialized
INFO - 2025-07-01 01:53:21 --> Router Class Initialized
INFO - 2025-07-01 01:53:21 --> Output Class Initialized
INFO - 2025-07-01 01:53:21 --> Security Class Initialized
DEBUG - 2025-07-01 01:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:53:21 --> Input Class Initialized
INFO - 2025-07-01 01:53:21 --> Language Class Initialized
INFO - 2025-07-01 01:53:21 --> Loader Class Initialized
INFO - 2025-07-01 01:53:21 --> Helper loaded: url_helper
INFO - 2025-07-01 01:53:21 --> Helper loaded: form_helper
INFO - 2025-07-01 01:53:21 --> Helper loaded: file_helper
INFO - 2025-07-01 01:53:21 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:53:21 --> Form Validation Class Initialized
INFO - 2025-07-01 01:53:21 --> Upload Class Initialized
INFO - 2025-07-01 01:53:21 --> Controller Class Initialized
INFO - 2025-07-01 01:53:21 --> Model "Question_type_model" initialized
INFO - 2025-07-01 01:53:21 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 01:53:21 --> Helper loaded: html_helper
DEBUG - 2025-07-01 01:53:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 01:53:22 --> 검색 로그: {"search_query":"\uc0bc\uc131\ubcd1\uc6d0 \uc8fc\uc18c","result_count":3,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 01:53:22"}
ERROR - 2025-07-01 01:53:22 --> Severity: Warning --> Undefined array key "search_params" /var/www/html/source/application/controllers/Hospital_search.php 57
INFO - 2025-07-01 01:53:22 --> Final output sent to browser
DEBUG - 2025-07-01 01:53:22 --> Total execution time: 0.3481
INFO - 2025-07-01 01:53:32 --> Config Class Initialized
INFO - 2025-07-01 01:53:32 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:53:32 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:53:32 --> Utf8 Class Initialized
INFO - 2025-07-01 01:53:32 --> URI Class Initialized
INFO - 2025-07-01 01:53:32 --> Router Class Initialized
INFO - 2025-07-01 01:53:32 --> Output Class Initialized
INFO - 2025-07-01 01:53:32 --> Security Class Initialized
DEBUG - 2025-07-01 01:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:53:32 --> Input Class Initialized
INFO - 2025-07-01 01:53:32 --> Language Class Initialized
INFO - 2025-07-01 01:53:32 --> Loader Class Initialized
INFO - 2025-07-01 01:53:32 --> Helper loaded: url_helper
INFO - 2025-07-01 01:53:32 --> Helper loaded: form_helper
INFO - 2025-07-01 01:53:32 --> Helper loaded: file_helper
INFO - 2025-07-01 01:53:32 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:53:32 --> Form Validation Class Initialized
INFO - 2025-07-01 01:53:32 --> Upload Class Initialized
INFO - 2025-07-01 01:53:32 --> Controller Class Initialized
INFO - 2025-07-01 01:53:32 --> Model "Question_type_model" initialized
INFO - 2025-07-01 01:53:32 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 01:53:32 --> Helper loaded: html_helper
DEBUG - 2025-07-01 01:53:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 01:53:32 --> File loaded: /var/www/html/source/application/views/hospital/search_main.php
INFO - 2025-07-01 01:53:32 --> Final output sent to browser
DEBUG - 2025-07-01 01:53:32 --> Total execution time: 0.2222
INFO - 2025-07-01 01:53:32 --> Config Class Initialized
INFO - 2025-07-01 01:53:32 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:53:32 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:53:32 --> Utf8 Class Initialized
INFO - 2025-07-01 01:53:32 --> URI Class Initialized
INFO - 2025-07-01 01:53:32 --> Router Class Initialized
INFO - 2025-07-01 01:53:32 --> Output Class Initialized
INFO - 2025-07-01 01:53:32 --> Security Class Initialized
DEBUG - 2025-07-01 01:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:53:32 --> Input Class Initialized
INFO - 2025-07-01 01:53:32 --> Language Class Initialized
INFO - 2025-07-01 01:53:40 --> Config Class Initialized
INFO - 2025-07-01 01:53:40 --> Hooks Class Initialized
DEBUG - 2025-07-01 01:53:40 --> UTF-8 Support Enabled
INFO - 2025-07-01 01:53:40 --> Utf8 Class Initialized
INFO - 2025-07-01 01:53:40 --> URI Class Initialized
INFO - 2025-07-01 01:53:40 --> Router Class Initialized
INFO - 2025-07-01 01:53:40 --> Output Class Initialized
INFO - 2025-07-01 01:53:40 --> Security Class Initialized
DEBUG - 2025-07-01 01:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 01:53:40 --> Input Class Initialized
INFO - 2025-07-01 01:53:40 --> Language Class Initialized
INFO - 2025-07-01 01:53:40 --> Loader Class Initialized
INFO - 2025-07-01 01:53:40 --> Helper loaded: url_helper
INFO - 2025-07-01 01:53:40 --> Helper loaded: form_helper
INFO - 2025-07-01 01:53:40 --> Helper loaded: file_helper
INFO - 2025-07-01 01:53:40 --> Database Driver Class Initialized
DEBUG - 2025-07-01 01:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 01:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 01:53:40 --> Form Validation Class Initialized
INFO - 2025-07-01 01:53:40 --> Upload Class Initialized
INFO - 2025-07-01 01:53:40 --> Controller Class Initialized
INFO - 2025-07-01 01:53:40 --> Model "Question_type_model" initialized
INFO - 2025-07-01 01:53:40 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 01:53:40 --> Helper loaded: html_helper
DEBUG - 2025-07-01 01:53:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 01:53:40 --> 검색 로그: {"search_query":"\uc0bc\uc131\ubcd1\uc6d0 \uc8fc\uc18c","result_count":3,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 01:53:40"}
ERROR - 2025-07-01 01:53:40 --> Severity: Warning --> Undefined array key "search_params" /var/www/html/source/application/controllers/Hospital_search.php 57
INFO - 2025-07-01 01:53:40 --> Final output sent to browser
DEBUG - 2025-07-01 01:53:40 --> Total execution time: 0.3612
INFO - 2025-07-01 02:06:34 --> Config Class Initialized
INFO - 2025-07-01 02:06:34 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:06:34 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:06:34 --> Utf8 Class Initialized
INFO - 2025-07-01 02:06:34 --> URI Class Initialized
INFO - 2025-07-01 02:06:34 --> Router Class Initialized
INFO - 2025-07-01 02:06:34 --> Output Class Initialized
INFO - 2025-07-01 02:06:34 --> Security Class Initialized
DEBUG - 2025-07-01 02:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:06:34 --> Input Class Initialized
INFO - 2025-07-01 02:06:34 --> Language Class Initialized
INFO - 2025-07-01 02:06:35 --> Loader Class Initialized
INFO - 2025-07-01 02:06:35 --> Helper loaded: url_helper
INFO - 2025-07-01 02:06:35 --> Helper loaded: form_helper
INFO - 2025-07-01 02:06:35 --> Helper loaded: file_helper
INFO - 2025-07-01 02:06:35 --> Database Driver Class Initialized
DEBUG - 2025-07-01 02:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 02:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 02:06:35 --> Form Validation Class Initialized
INFO - 2025-07-01 02:06:35 --> Upload Class Initialized
INFO - 2025-07-01 02:06:35 --> Controller Class Initialized
INFO - 2025-07-01 02:06:35 --> Model "Question_type_model" initialized
INFO - 2025-07-01 02:06:35 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 02:06:35 --> Helper loaded: html_helper
DEBUG - 2025-07-01 02:06:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 02:06:35 --> 검색 로그: {"search_query":"\uc0bc\uc131\ubcd1\uc6d0 \uc8fc\uc18c","result_count":3,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 02:06:35"}
ERROR - 2025-07-01 02:06:35 --> Severity: Warning --> Undefined array key "search_params" /var/www/html/source/application/controllers/Hospital_search.php 57
INFO - 2025-07-01 02:06:35 --> Final output sent to browser
DEBUG - 2025-07-01 02:06:35 --> Total execution time: 0.3887
INFO - 2025-07-01 02:06:40 --> Config Class Initialized
INFO - 2025-07-01 02:06:40 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:06:40 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:06:40 --> Utf8 Class Initialized
INFO - 2025-07-01 02:06:40 --> URI Class Initialized
INFO - 2025-07-01 02:06:40 --> Router Class Initialized
INFO - 2025-07-01 02:06:40 --> Output Class Initialized
INFO - 2025-07-01 02:06:40 --> Security Class Initialized
DEBUG - 2025-07-01 02:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:06:40 --> Input Class Initialized
INFO - 2025-07-01 02:06:40 --> Language Class Initialized
INFO - 2025-07-01 02:06:40 --> Loader Class Initialized
INFO - 2025-07-01 02:06:40 --> Helper loaded: url_helper
INFO - 2025-07-01 02:06:40 --> Helper loaded: form_helper
INFO - 2025-07-01 02:06:40 --> Helper loaded: file_helper
INFO - 2025-07-01 02:06:40 --> Database Driver Class Initialized
DEBUG - 2025-07-01 02:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 02:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 02:06:40 --> Form Validation Class Initialized
INFO - 2025-07-01 02:06:40 --> Upload Class Initialized
INFO - 2025-07-01 02:06:40 --> Controller Class Initialized
INFO - 2025-07-01 02:06:40 --> Model "Question_type_model" initialized
INFO - 2025-07-01 02:06:40 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 02:06:40 --> Helper loaded: html_helper
DEBUG - 2025-07-01 02:06:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 02:06:40 --> File loaded: /var/www/html/source/application/views/hospital/search_main.php
INFO - 2025-07-01 02:06:40 --> Final output sent to browser
DEBUG - 2025-07-01 02:06:40 --> Total execution time: 0.2187
INFO - 2025-07-01 02:06:40 --> Config Class Initialized
INFO - 2025-07-01 02:06:40 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:06:40 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:06:40 --> Utf8 Class Initialized
INFO - 2025-07-01 02:06:40 --> URI Class Initialized
INFO - 2025-07-01 02:06:40 --> Router Class Initialized
INFO - 2025-07-01 02:06:40 --> Output Class Initialized
INFO - 2025-07-01 02:06:40 --> Security Class Initialized
DEBUG - 2025-07-01 02:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:06:40 --> Input Class Initialized
INFO - 2025-07-01 02:06:40 --> Language Class Initialized
INFO - 2025-07-01 02:06:48 --> Config Class Initialized
INFO - 2025-07-01 02:06:48 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:06:48 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:06:48 --> Utf8 Class Initialized
INFO - 2025-07-01 02:06:48 --> URI Class Initialized
INFO - 2025-07-01 02:06:48 --> Router Class Initialized
INFO - 2025-07-01 02:06:48 --> Output Class Initialized
INFO - 2025-07-01 02:06:48 --> Security Class Initialized
DEBUG - 2025-07-01 02:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:06:48 --> Input Class Initialized
INFO - 2025-07-01 02:06:48 --> Language Class Initialized
INFO - 2025-07-01 02:06:48 --> Loader Class Initialized
INFO - 2025-07-01 02:06:48 --> Helper loaded: url_helper
INFO - 2025-07-01 02:06:48 --> Helper loaded: form_helper
INFO - 2025-07-01 02:06:48 --> Helper loaded: file_helper
INFO - 2025-07-01 02:06:48 --> Database Driver Class Initialized
DEBUG - 2025-07-01 02:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 02:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 02:06:48 --> Form Validation Class Initialized
INFO - 2025-07-01 02:06:48 --> Upload Class Initialized
INFO - 2025-07-01 02:06:48 --> Controller Class Initialized
INFO - 2025-07-01 02:06:48 --> Model "Question_type_model" initialized
INFO - 2025-07-01 02:06:48 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 02:06:48 --> Helper loaded: html_helper
DEBUG - 2025-07-01 02:06:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 02:06:49 --> 검색 로그: {"search_query":"\uc0bc\uc131\ubcd1\uc6d0 \uc8fc\uc18c","result_count":3,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 02:06:49"}
ERROR - 2025-07-01 02:06:49 --> Severity: Warning --> Undefined array key "search_params" /var/www/html/source/application/controllers/Hospital_search.php 57
INFO - 2025-07-01 02:06:49 --> Final output sent to browser
DEBUG - 2025-07-01 02:06:49 --> Total execution time: 0.3830
INFO - 2025-07-01 02:10:38 --> Config Class Initialized
INFO - 2025-07-01 02:10:38 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:10:38 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:10:38 --> Utf8 Class Initialized
INFO - 2025-07-01 02:10:38 --> URI Class Initialized
INFO - 2025-07-01 02:10:38 --> Router Class Initialized
INFO - 2025-07-01 02:10:38 --> Output Class Initialized
INFO - 2025-07-01 02:10:38 --> Security Class Initialized
DEBUG - 2025-07-01 02:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:10:38 --> Input Class Initialized
INFO - 2025-07-01 02:10:38 --> Language Class Initialized
INFO - 2025-07-01 02:10:38 --> Loader Class Initialized
INFO - 2025-07-01 02:10:38 --> Helper loaded: url_helper
INFO - 2025-07-01 02:10:39 --> Helper loaded: form_helper
INFO - 2025-07-01 02:10:39 --> Helper loaded: file_helper
INFO - 2025-07-01 02:10:39 --> Database Driver Class Initialized
DEBUG - 2025-07-01 02:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 02:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 02:10:39 --> Form Validation Class Initialized
INFO - 2025-07-01 02:10:39 --> Upload Class Initialized
INFO - 2025-07-01 02:10:39 --> Controller Class Initialized
INFO - 2025-07-01 02:10:39 --> Model "Question_type_model" initialized
INFO - 2025-07-01 02:10:39 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 02:10:39 --> Helper loaded: html_helper
DEBUG - 2025-07-01 02:10:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 02:10:39 --> 검색 로그: {"search_query":"\uac15\ubd81\uc758 \uc0bc\uc131\ubcd1\uc6d0","result_count":50,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 02:10:39"}
INFO - 2025-07-01 02:10:39 --> Final output sent to browser
DEBUG - 2025-07-01 02:10:39 --> Total execution time: 0.3209
INFO - 2025-07-01 02:34:39 --> Config Class Initialized
INFO - 2025-07-01 02:34:39 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:34:39 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:34:39 --> Utf8 Class Initialized
INFO - 2025-07-01 02:34:39 --> URI Class Initialized
INFO - 2025-07-01 02:34:39 --> Router Class Initialized
INFO - 2025-07-01 02:34:39 --> Output Class Initialized
INFO - 2025-07-01 02:34:39 --> Security Class Initialized
DEBUG - 2025-07-01 02:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:34:39 --> Input Class Initialized
INFO - 2025-07-01 02:34:39 --> Language Class Initialized
INFO - 2025-07-01 02:34:40 --> Loader Class Initialized
INFO - 2025-07-01 02:34:40 --> Helper loaded: url_helper
INFO - 2025-07-01 02:34:40 --> Helper loaded: form_helper
INFO - 2025-07-01 02:34:40 --> Helper loaded: file_helper
INFO - 2025-07-01 02:34:40 --> Database Driver Class Initialized
DEBUG - 2025-07-01 02:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 02:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 02:34:40 --> Form Validation Class Initialized
INFO - 2025-07-01 02:34:40 --> Upload Class Initialized
INFO - 2025-07-01 02:34:40 --> Controller Class Initialized
INFO - 2025-07-01 02:34:40 --> Model "Question_type_model" initialized
INFO - 2025-07-01 02:34:40 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 02:34:40 --> Helper loaded: html_helper
DEBUG - 2025-07-01 02:34:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 02:34:40 --> File loaded: /var/www/html/source/application/views/hospital/search_main.php
INFO - 2025-07-01 02:34:40 --> Final output sent to browser
DEBUG - 2025-07-01 02:34:40 --> Total execution time: 0.2402
INFO - 2025-07-01 02:34:40 --> Config Class Initialized
INFO - 2025-07-01 02:34:40 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:34:40 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:34:40 --> Utf8 Class Initialized
INFO - 2025-07-01 02:34:40 --> URI Class Initialized
INFO - 2025-07-01 02:34:40 --> Router Class Initialized
INFO - 2025-07-01 02:34:40 --> Output Class Initialized
INFO - 2025-07-01 02:34:40 --> Security Class Initialized
DEBUG - 2025-07-01 02:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:34:40 --> Input Class Initialized
INFO - 2025-07-01 02:34:40 --> Language Class Initialized
INFO - 2025-07-01 02:34:50 --> Config Class Initialized
INFO - 2025-07-01 02:34:50 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:34:50 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:34:50 --> Utf8 Class Initialized
INFO - 2025-07-01 02:34:50 --> URI Class Initialized
INFO - 2025-07-01 02:34:50 --> Router Class Initialized
INFO - 2025-07-01 02:34:50 --> Output Class Initialized
INFO - 2025-07-01 02:34:50 --> Security Class Initialized
DEBUG - 2025-07-01 02:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:34:50 --> Input Class Initialized
INFO - 2025-07-01 02:34:50 --> Language Class Initialized
INFO - 2025-07-01 02:34:50 --> Loader Class Initialized
INFO - 2025-07-01 02:34:50 --> Helper loaded: url_helper
INFO - 2025-07-01 02:34:50 --> Helper loaded: form_helper
INFO - 2025-07-01 02:34:50 --> Helper loaded: file_helper
INFO - 2025-07-01 02:34:50 --> Database Driver Class Initialized
DEBUG - 2025-07-01 02:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 02:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 02:34:50 --> Form Validation Class Initialized
INFO - 2025-07-01 02:34:50 --> Upload Class Initialized
INFO - 2025-07-01 02:34:50 --> Controller Class Initialized
INFO - 2025-07-01 02:34:50 --> Model "Question_type_model" initialized
INFO - 2025-07-01 02:34:50 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 02:34:50 --> Helper loaded: html_helper
DEBUG - 2025-07-01 02:34:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 02:34:50 --> 검색 로그: {"search_query":"\uac15\ubd81 \uc0bc\uc131\ubcd1\uc6d0","result_count":50,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 02:34:50"}
INFO - 2025-07-01 02:34:50 --> Final output sent to browser
DEBUG - 2025-07-01 02:34:50 --> Total execution time: 0.2436
INFO - 2025-07-01 02:39:24 --> Config Class Initialized
INFO - 2025-07-01 02:39:24 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:39:24 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:39:24 --> Utf8 Class Initialized
INFO - 2025-07-01 02:39:24 --> URI Class Initialized
INFO - 2025-07-01 02:39:24 --> Router Class Initialized
INFO - 2025-07-01 02:39:24 --> Output Class Initialized
INFO - 2025-07-01 02:39:24 --> Security Class Initialized
DEBUG - 2025-07-01 02:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:39:24 --> Input Class Initialized
INFO - 2025-07-01 02:39:24 --> Language Class Initialized
INFO - 2025-07-01 02:39:24 --> Loader Class Initialized
INFO - 2025-07-01 02:39:24 --> Helper loaded: url_helper
INFO - 2025-07-01 02:39:24 --> Helper loaded: form_helper
INFO - 2025-07-01 02:39:24 --> Helper loaded: file_helper
INFO - 2025-07-01 02:39:24 --> Database Driver Class Initialized
DEBUG - 2025-07-01 02:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 02:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 02:39:24 --> Form Validation Class Initialized
INFO - 2025-07-01 02:39:24 --> Upload Class Initialized
INFO - 2025-07-01 02:39:24 --> Controller Class Initialized
INFO - 2025-07-01 02:39:24 --> Model "Question_type_model" initialized
INFO - 2025-07-01 02:39:24 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 02:39:24 --> Helper loaded: html_helper
DEBUG - 2025-07-01 02:39:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 02:39:24 --> File loaded: /var/www/html/source/application/views/hospital/search_main.php
INFO - 2025-07-01 02:39:24 --> Final output sent to browser
DEBUG - 2025-07-01 02:39:24 --> Total execution time: 0.2584
INFO - 2025-07-01 02:39:24 --> Config Class Initialized
INFO - 2025-07-01 02:39:24 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:39:24 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:39:24 --> Utf8 Class Initialized
INFO - 2025-07-01 02:39:24 --> URI Class Initialized
INFO - 2025-07-01 02:39:24 --> Router Class Initialized
INFO - 2025-07-01 02:39:24 --> Output Class Initialized
INFO - 2025-07-01 02:39:24 --> Security Class Initialized
DEBUG - 2025-07-01 02:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:39:24 --> Input Class Initialized
INFO - 2025-07-01 02:39:24 --> Language Class Initialized
INFO - 2025-07-01 02:41:34 --> Config Class Initialized
INFO - 2025-07-01 02:41:34 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:41:34 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:41:34 --> Utf8 Class Initialized
INFO - 2025-07-01 02:41:34 --> URI Class Initialized
INFO - 2025-07-01 02:41:34 --> Router Class Initialized
INFO - 2025-07-01 02:41:34 --> Output Class Initialized
INFO - 2025-07-01 02:41:34 --> Security Class Initialized
DEBUG - 2025-07-01 02:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:41:34 --> Input Class Initialized
INFO - 2025-07-01 02:41:34 --> Language Class Initialized
INFO - 2025-07-01 02:41:34 --> Loader Class Initialized
INFO - 2025-07-01 02:41:34 --> Helper loaded: url_helper
INFO - 2025-07-01 02:41:34 --> Helper loaded: form_helper
INFO - 2025-07-01 02:41:34 --> Helper loaded: file_helper
INFO - 2025-07-01 02:41:34 --> Database Driver Class Initialized
DEBUG - 2025-07-01 02:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 02:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 02:41:34 --> Form Validation Class Initialized
INFO - 2025-07-01 02:41:34 --> Upload Class Initialized
INFO - 2025-07-01 02:41:34 --> Controller Class Initialized
INFO - 2025-07-01 02:41:34 --> Model "Question_type_model" initialized
INFO - 2025-07-01 02:41:34 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 02:41:34 --> Helper loaded: html_helper
DEBUG - 2025-07-01 02:41:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 02:41:34 --> 검색 로그: {"search_query":"\uac15\ubd81 \uc0bc\uc131\ubcd1\uc6d0","result_count":50,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 02:41:34"}
INFO - 2025-07-01 02:41:34 --> Final output sent to browser
DEBUG - 2025-07-01 02:41:34 --> Total execution time: 0.2784
INFO - 2025-07-01 02:41:47 --> Config Class Initialized
INFO - 2025-07-01 02:41:47 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:41:47 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:41:47 --> Utf8 Class Initialized
INFO - 2025-07-01 02:41:47 --> URI Class Initialized
INFO - 2025-07-01 02:41:47 --> Router Class Initialized
INFO - 2025-07-01 02:41:47 --> Output Class Initialized
INFO - 2025-07-01 02:41:47 --> Security Class Initialized
DEBUG - 2025-07-01 02:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:41:47 --> Input Class Initialized
INFO - 2025-07-01 02:41:47 --> Language Class Initialized
INFO - 2025-07-01 02:41:47 --> Loader Class Initialized
INFO - 2025-07-01 02:41:47 --> Helper loaded: url_helper
INFO - 2025-07-01 02:41:47 --> Helper loaded: form_helper
INFO - 2025-07-01 02:41:47 --> Helper loaded: file_helper
INFO - 2025-07-01 02:41:47 --> Database Driver Class Initialized
DEBUG - 2025-07-01 02:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 02:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 02:41:47 --> Form Validation Class Initialized
INFO - 2025-07-01 02:41:47 --> Upload Class Initialized
INFO - 2025-07-01 02:41:47 --> Controller Class Initialized
INFO - 2025-07-01 02:41:47 --> Model "Question_type_model" initialized
INFO - 2025-07-01 02:41:47 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 02:41:47 --> Helper loaded: html_helper
DEBUG - 2025-07-01 02:41:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 02:41:47 --> 검색 로그: {"search_query":"\uac15\ubd81\uad6c \uc0bc\uc131\ubcd1\uc6d0","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 02:41:47"}
INFO - 2025-07-01 02:41:47 --> Final output sent to browser
DEBUG - 2025-07-01 02:41:47 --> Total execution time: 0.2602
INFO - 2025-07-01 02:41:55 --> Config Class Initialized
INFO - 2025-07-01 02:41:55 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:41:55 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:41:55 --> Utf8 Class Initialized
INFO - 2025-07-01 02:41:55 --> URI Class Initialized
INFO - 2025-07-01 02:41:55 --> Router Class Initialized
INFO - 2025-07-01 02:41:55 --> Output Class Initialized
INFO - 2025-07-01 02:41:55 --> Security Class Initialized
DEBUG - 2025-07-01 02:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:41:55 --> Input Class Initialized
INFO - 2025-07-01 02:41:55 --> Language Class Initialized
INFO - 2025-07-01 02:41:55 --> Loader Class Initialized
INFO - 2025-07-01 02:41:55 --> Helper loaded: url_helper
INFO - 2025-07-01 02:41:55 --> Helper loaded: form_helper
INFO - 2025-07-01 02:41:55 --> Helper loaded: file_helper
INFO - 2025-07-01 02:41:55 --> Database Driver Class Initialized
DEBUG - 2025-07-01 02:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 02:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 02:41:55 --> Form Validation Class Initialized
INFO - 2025-07-01 02:41:55 --> Upload Class Initialized
INFO - 2025-07-01 02:41:55 --> Controller Class Initialized
INFO - 2025-07-01 02:41:55 --> Model "Question_type_model" initialized
INFO - 2025-07-01 02:41:55 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 02:41:55 --> Helper loaded: html_helper
DEBUG - 2025-07-01 02:41:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 02:41:55 --> 검색 로그: {"search_query":"\uc0bc\uc131\ubcd1\uc6d0 \uc8fc\uc18c\\","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 02:41:55"}
ERROR - 2025-07-01 02:41:55 --> Severity: Warning --> Undefined array key "search_params" /var/www/html/source/application/controllers/Hospital_search.php 57
INFO - 2025-07-01 02:41:55 --> Final output sent to browser
DEBUG - 2025-07-01 02:41:55 --> Total execution time: 0.3516
INFO - 2025-07-01 02:41:56 --> Config Class Initialized
INFO - 2025-07-01 02:41:56 --> Hooks Class Initialized
DEBUG - 2025-07-01 02:41:56 --> UTF-8 Support Enabled
INFO - 2025-07-01 02:41:56 --> Utf8 Class Initialized
INFO - 2025-07-01 02:41:56 --> URI Class Initialized
INFO - 2025-07-01 02:41:56 --> Router Class Initialized
INFO - 2025-07-01 02:41:56 --> Output Class Initialized
INFO - 2025-07-01 02:41:56 --> Security Class Initialized
DEBUG - 2025-07-01 02:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 02:41:56 --> Input Class Initialized
INFO - 2025-07-01 02:41:56 --> Language Class Initialized
INFO - 2025-07-01 02:41:56 --> Loader Class Initialized
INFO - 2025-07-01 02:41:56 --> Helper loaded: url_helper
INFO - 2025-07-01 02:41:56 --> Helper loaded: form_helper
INFO - 2025-07-01 02:41:56 --> Helper loaded: file_helper
INFO - 2025-07-01 02:41:56 --> Database Driver Class Initialized
DEBUG - 2025-07-01 02:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 02:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 02:41:56 --> Form Validation Class Initialized
INFO - 2025-07-01 02:41:56 --> Upload Class Initialized
INFO - 2025-07-01 02:41:56 --> Controller Class Initialized
INFO - 2025-07-01 02:41:56 --> Model "Question_type_model" initialized
INFO - 2025-07-01 02:41:56 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 02:41:56 --> Helper loaded: html_helper
DEBUG - 2025-07-01 02:41:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 02:41:56 --> 검색 로그: {"search_query":"\uc0bc\uc131\ubcd1\uc6d0 \uc8fc\uc18c","result_count":3,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 02:41:56"}
ERROR - 2025-07-01 02:41:56 --> Severity: Warning --> Undefined array key "search_params" /var/www/html/source/application/controllers/Hospital_search.php 57
INFO - 2025-07-01 02:41:56 --> Final output sent to browser
DEBUG - 2025-07-01 02:41:56 --> Total execution time: 0.3231
INFO - 2025-07-01 04:41:48 --> Config Class Initialized
INFO - 2025-07-01 04:41:48 --> Hooks Class Initialized
DEBUG - 2025-07-01 04:41:48 --> UTF-8 Support Enabled
INFO - 2025-07-01 04:41:48 --> Utf8 Class Initialized
INFO - 2025-07-01 04:41:48 --> URI Class Initialized
INFO - 2025-07-01 04:41:48 --> Router Class Initialized
INFO - 2025-07-01 04:41:48 --> Output Class Initialized
INFO - 2025-07-01 04:41:48 --> Security Class Initialized
DEBUG - 2025-07-01 04:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 04:41:48 --> Input Class Initialized
INFO - 2025-07-01 04:41:48 --> Language Class Initialized
INFO - 2025-07-01 04:41:48 --> Loader Class Initialized
INFO - 2025-07-01 04:41:48 --> Helper loaded: url_helper
INFO - 2025-07-01 04:41:48 --> Helper loaded: form_helper
INFO - 2025-07-01 04:41:48 --> Helper loaded: file_helper
INFO - 2025-07-01 04:41:48 --> Database Driver Class Initialized
DEBUG - 2025-07-01 04:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 04:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 04:41:48 --> Form Validation Class Initialized
INFO - 2025-07-01 04:41:48 --> Upload Class Initialized
INFO - 2025-07-01 04:41:48 --> Controller Class Initialized
INFO - 2025-07-01 04:41:48 --> Model "Question_type_model" initialized
INFO - 2025-07-01 04:41:48 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 04:41:48 --> Helper loaded: html_helper
DEBUG - 2025-07-01 04:41:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 04:41:48 --> File loaded: /var/www/html/source/application/views/hospital/search_main.php
INFO - 2025-07-01 04:41:48 --> Final output sent to browser
DEBUG - 2025-07-01 04:41:48 --> Total execution time: 0.2771
INFO - 2025-07-01 04:41:48 --> Config Class Initialized
INFO - 2025-07-01 04:41:48 --> Hooks Class Initialized
DEBUG - 2025-07-01 04:41:48 --> UTF-8 Support Enabled
INFO - 2025-07-01 04:41:48 --> Utf8 Class Initialized
INFO - 2025-07-01 04:41:48 --> URI Class Initialized
INFO - 2025-07-01 04:41:48 --> Router Class Initialized
INFO - 2025-07-01 04:41:48 --> Output Class Initialized
INFO - 2025-07-01 04:41:48 --> Security Class Initialized
DEBUG - 2025-07-01 04:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 04:41:48 --> Input Class Initialized
INFO - 2025-07-01 04:41:48 --> Language Class Initialized
INFO - 2025-07-01 04:42:04 --> Config Class Initialized
INFO - 2025-07-01 04:42:04 --> Hooks Class Initialized
DEBUG - 2025-07-01 04:42:04 --> UTF-8 Support Enabled
INFO - 2025-07-01 04:42:04 --> Utf8 Class Initialized
INFO - 2025-07-01 04:42:04 --> URI Class Initialized
INFO - 2025-07-01 04:42:04 --> Router Class Initialized
INFO - 2025-07-01 04:42:04 --> Output Class Initialized
INFO - 2025-07-01 04:42:04 --> Security Class Initialized
DEBUG - 2025-07-01 04:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 04:42:04 --> Input Class Initialized
INFO - 2025-07-01 04:42:04 --> Language Class Initialized
INFO - 2025-07-01 04:42:04 --> Loader Class Initialized
INFO - 2025-07-01 04:42:04 --> Helper loaded: url_helper
INFO - 2025-07-01 04:42:04 --> Helper loaded: form_helper
INFO - 2025-07-01 04:42:04 --> Helper loaded: file_helper
INFO - 2025-07-01 04:42:05 --> Database Driver Class Initialized
DEBUG - 2025-07-01 04:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 04:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 04:42:05 --> Form Validation Class Initialized
INFO - 2025-07-01 04:42:05 --> Upload Class Initialized
INFO - 2025-07-01 04:42:05 --> Controller Class Initialized
INFO - 2025-07-01 04:42:05 --> Model "Question_type_model" initialized
INFO - 2025-07-01 04:42:05 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 04:42:05 --> Helper loaded: html_helper
DEBUG - 2025-07-01 04:42:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 04:42:05 --> 검색 로그: {"search_query":"\uc0bc\uc131\ubcd1\uc6d0 \uc704\uce58","result_count":3,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 04:42:05"}
ERROR - 2025-07-01 04:42:05 --> Severity: Warning --> Undefined array key "search_params" /var/www/html/source/application/controllers/Hospital_search.php 57
INFO - 2025-07-01 04:42:05 --> Final output sent to browser
DEBUG - 2025-07-01 04:42:05 --> Total execution time: 0.4326
INFO - 2025-07-01 04:46:11 --> Config Class Initialized
INFO - 2025-07-01 04:46:11 --> Hooks Class Initialized
DEBUG - 2025-07-01 04:46:11 --> UTF-8 Support Enabled
INFO - 2025-07-01 04:46:11 --> Utf8 Class Initialized
INFO - 2025-07-01 04:46:11 --> URI Class Initialized
INFO - 2025-07-01 04:46:11 --> Router Class Initialized
INFO - 2025-07-01 04:46:11 --> Output Class Initialized
INFO - 2025-07-01 04:46:11 --> Security Class Initialized
DEBUG - 2025-07-01 04:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 04:46:11 --> Input Class Initialized
INFO - 2025-07-01 04:46:11 --> Language Class Initialized
INFO - 2025-07-01 04:46:11 --> Loader Class Initialized
INFO - 2025-07-01 04:46:11 --> Helper loaded: url_helper
INFO - 2025-07-01 04:46:11 --> Helper loaded: form_helper
INFO - 2025-07-01 04:46:11 --> Helper loaded: file_helper
INFO - 2025-07-01 04:46:11 --> Database Driver Class Initialized
DEBUG - 2025-07-01 04:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 04:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 04:46:11 --> Form Validation Class Initialized
INFO - 2025-07-01 04:46:11 --> Upload Class Initialized
INFO - 2025-07-01 04:46:11 --> Controller Class Initialized
INFO - 2025-07-01 04:46:11 --> Model "Question_type_model" initialized
INFO - 2025-07-01 04:46:11 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 04:46:11 --> Helper loaded: html_helper
DEBUG - 2025-07-01 04:46:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 04:46:11 --> 검색 로그: {"search_query":"\uadfc\ucc98 \uc751\uae09\uc2e4","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 04:46:11"}
INFO - 2025-07-01 04:46:11 --> Final output sent to browser
DEBUG - 2025-07-01 04:46:11 --> Total execution time: 0.6502
INFO - 2025-07-01 04:46:20 --> Config Class Initialized
INFO - 2025-07-01 04:46:20 --> Hooks Class Initialized
DEBUG - 2025-07-01 04:46:20 --> UTF-8 Support Enabled
INFO - 2025-07-01 04:46:20 --> Utf8 Class Initialized
INFO - 2025-07-01 04:46:20 --> URI Class Initialized
INFO - 2025-07-01 04:46:20 --> Router Class Initialized
INFO - 2025-07-01 04:46:20 --> Output Class Initialized
INFO - 2025-07-01 04:46:20 --> Security Class Initialized
DEBUG - 2025-07-01 04:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 04:46:20 --> Input Class Initialized
INFO - 2025-07-01 04:46:20 --> Language Class Initialized
INFO - 2025-07-01 04:46:20 --> Loader Class Initialized
INFO - 2025-07-01 04:46:20 --> Helper loaded: url_helper
INFO - 2025-07-01 04:46:20 --> Helper loaded: form_helper
INFO - 2025-07-01 04:46:20 --> Helper loaded: file_helper
INFO - 2025-07-01 04:46:20 --> Database Driver Class Initialized
DEBUG - 2025-07-01 04:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 04:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 04:46:20 --> Form Validation Class Initialized
INFO - 2025-07-01 04:46:20 --> Upload Class Initialized
INFO - 2025-07-01 04:46:20 --> Controller Class Initialized
INFO - 2025-07-01 04:46:20 --> Model "Question_type_model" initialized
INFO - 2025-07-01 04:46:20 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 04:46:20 --> Helper loaded: html_helper
DEBUG - 2025-07-01 04:46:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 04:46:20 --> 검색 로그: {"search_query":"\uac15\ub0a8\uad6c \uc751\uae09\uc2e4","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 04:46:20"}
INFO - 2025-07-01 04:46:20 --> Final output sent to browser
DEBUG - 2025-07-01 04:46:20 --> Total execution time: 0.4500
INFO - 2025-07-01 04:46:37 --> Config Class Initialized
INFO - 2025-07-01 04:46:37 --> Hooks Class Initialized
DEBUG - 2025-07-01 04:46:37 --> UTF-8 Support Enabled
INFO - 2025-07-01 04:46:37 --> Utf8 Class Initialized
INFO - 2025-07-01 04:46:37 --> URI Class Initialized
INFO - 2025-07-01 04:46:37 --> Router Class Initialized
INFO - 2025-07-01 04:46:37 --> Output Class Initialized
INFO - 2025-07-01 04:46:37 --> Security Class Initialized
DEBUG - 2025-07-01 04:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 04:46:37 --> Input Class Initialized
INFO - 2025-07-01 04:46:37 --> Language Class Initialized
INFO - 2025-07-01 04:46:37 --> Loader Class Initialized
INFO - 2025-07-01 04:46:37 --> Helper loaded: url_helper
INFO - 2025-07-01 04:46:37 --> Helper loaded: form_helper
INFO - 2025-07-01 04:46:37 --> Helper loaded: file_helper
INFO - 2025-07-01 04:46:38 --> Database Driver Class Initialized
DEBUG - 2025-07-01 04:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 04:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 04:46:38 --> Form Validation Class Initialized
INFO - 2025-07-01 04:46:38 --> Upload Class Initialized
INFO - 2025-07-01 04:46:38 --> Controller Class Initialized
INFO - 2025-07-01 04:46:38 --> Model "Question_type_model" initialized
INFO - 2025-07-01 04:46:38 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 04:46:38 --> Helper loaded: html_helper
DEBUG - 2025-07-01 04:46:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 04:46:38 --> 검색 로그: {"search_query":"\uac15\ub0a8\uad6c \uc751\uae09\uc2e4","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 04:46:38"}
INFO - 2025-07-01 04:46:38 --> Final output sent to browser
DEBUG - 2025-07-01 04:46:38 --> Total execution time: 0.4974
INFO - 2025-07-01 05:03:56 --> Config Class Initialized
INFO - 2025-07-01 05:03:56 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:03:56 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:03:56 --> Utf8 Class Initialized
INFO - 2025-07-01 05:03:56 --> URI Class Initialized
INFO - 2025-07-01 05:03:56 --> Router Class Initialized
INFO - 2025-07-01 05:03:56 --> Output Class Initialized
INFO - 2025-07-01 05:03:56 --> Security Class Initialized
DEBUG - 2025-07-01 05:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:03:56 --> Input Class Initialized
INFO - 2025-07-01 05:03:56 --> Language Class Initialized
INFO - 2025-07-01 05:03:56 --> Loader Class Initialized
INFO - 2025-07-01 05:03:56 --> Helper loaded: url_helper
INFO - 2025-07-01 05:03:56 --> Helper loaded: form_helper
INFO - 2025-07-01 05:03:56 --> Helper loaded: file_helper
INFO - 2025-07-01 05:03:56 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:03:56 --> Form Validation Class Initialized
INFO - 2025-07-01 05:03:56 --> Upload Class Initialized
INFO - 2025-07-01 05:03:56 --> Controller Class Initialized
INFO - 2025-07-01 05:03:56 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:03:56 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:03:56 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:03:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:03:56 --> File loaded: /var/www/html/source/application/views/hospital/search_main.php
INFO - 2025-07-01 05:03:56 --> Final output sent to browser
DEBUG - 2025-07-01 05:03:56 --> Total execution time: 0.2234
INFO - 2025-07-01 05:03:56 --> Config Class Initialized
INFO - 2025-07-01 05:03:56 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:03:56 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:03:56 --> Utf8 Class Initialized
INFO - 2025-07-01 05:03:56 --> URI Class Initialized
INFO - 2025-07-01 05:03:56 --> Router Class Initialized
INFO - 2025-07-01 05:03:56 --> Output Class Initialized
INFO - 2025-07-01 05:03:56 --> Security Class Initialized
DEBUG - 2025-07-01 05:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:03:56 --> Input Class Initialized
INFO - 2025-07-01 05:03:56 --> Language Class Initialized
INFO - 2025-07-01 05:03:58 --> Config Class Initialized
INFO - 2025-07-01 05:03:58 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:03:58 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:03:58 --> Utf8 Class Initialized
INFO - 2025-07-01 05:03:58 --> URI Class Initialized
INFO - 2025-07-01 05:03:58 --> Router Class Initialized
INFO - 2025-07-01 05:03:58 --> Output Class Initialized
INFO - 2025-07-01 05:03:59 --> Security Class Initialized
DEBUG - 2025-07-01 05:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:03:59 --> Input Class Initialized
INFO - 2025-07-01 05:03:59 --> Language Class Initialized
INFO - 2025-07-01 05:03:59 --> Loader Class Initialized
INFO - 2025-07-01 05:03:59 --> Helper loaded: url_helper
INFO - 2025-07-01 05:03:59 --> Helper loaded: form_helper
INFO - 2025-07-01 05:03:59 --> Helper loaded: file_helper
INFO - 2025-07-01 05:03:59 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:03:59 --> Form Validation Class Initialized
INFO - 2025-07-01 05:03:59 --> Upload Class Initialized
INFO - 2025-07-01 05:03:59 --> Controller Class Initialized
INFO - 2025-07-01 05:03:59 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:03:59 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:03:59 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:03:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:03:59 --> 검색 로그: {"search_query":"\uac15\ub0a8\uad6c \uc751\uae09\uc2e4","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:03:59"}
ERROR - 2025-07-01 05:03:59 --> Severity: Warning --> Undefined array key "search_params" /var/www/html/source/application/controllers/Hospital_search.php 57
INFO - 2025-07-01 05:03:59 --> Final output sent to browser
DEBUG - 2025-07-01 05:03:59 --> Total execution time: 0.3039
INFO - 2025-07-01 05:06:59 --> Config Class Initialized
INFO - 2025-07-01 05:06:59 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:07:00 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:07:00 --> Utf8 Class Initialized
INFO - 2025-07-01 05:07:00 --> URI Class Initialized
INFO - 2025-07-01 05:07:00 --> Router Class Initialized
INFO - 2025-07-01 05:07:00 --> Output Class Initialized
INFO - 2025-07-01 05:07:00 --> Security Class Initialized
DEBUG - 2025-07-01 05:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:07:00 --> Input Class Initialized
INFO - 2025-07-01 05:07:00 --> Language Class Initialized
INFO - 2025-07-01 05:07:00 --> Loader Class Initialized
INFO - 2025-07-01 05:07:00 --> Helper loaded: url_helper
INFO - 2025-07-01 05:07:00 --> Helper loaded: form_helper
INFO - 2025-07-01 05:07:00 --> Helper loaded: file_helper
INFO - 2025-07-01 05:07:00 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:07:00 --> Form Validation Class Initialized
INFO - 2025-07-01 05:07:00 --> Upload Class Initialized
INFO - 2025-07-01 05:07:00 --> Controller Class Initialized
INFO - 2025-07-01 05:07:00 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:07:00 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:07:00 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:07:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:07:00 --> 검색 로그: {"search_query":"\uac15\ub0a8\uad6c \uc751\uae09\uc2e4","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:07:00"}
ERROR - 2025-07-01 05:07:00 --> Severity: Warning --> Undefined array key "search_params" /var/www/html/source/application/controllers/Hospital_search.php 57
INFO - 2025-07-01 05:07:00 --> Final output sent to browser
DEBUG - 2025-07-01 05:07:00 --> Total execution time: 0.4928
INFO - 2025-07-01 05:11:18 --> Config Class Initialized
INFO - 2025-07-01 05:11:18 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:11:18 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:11:18 --> Utf8 Class Initialized
INFO - 2025-07-01 05:11:18 --> URI Class Initialized
INFO - 2025-07-01 05:11:18 --> Router Class Initialized
INFO - 2025-07-01 05:11:18 --> Output Class Initialized
INFO - 2025-07-01 05:11:18 --> Security Class Initialized
DEBUG - 2025-07-01 05:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:11:18 --> Input Class Initialized
INFO - 2025-07-01 05:11:18 --> Language Class Initialized
INFO - 2025-07-01 05:11:18 --> Loader Class Initialized
INFO - 2025-07-01 05:11:18 --> Helper loaded: url_helper
INFO - 2025-07-01 05:11:18 --> Helper loaded: form_helper
INFO - 2025-07-01 05:11:18 --> Helper loaded: file_helper
INFO - 2025-07-01 05:11:18 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:11:18 --> Form Validation Class Initialized
INFO - 2025-07-01 05:11:18 --> Upload Class Initialized
INFO - 2025-07-01 05:11:18 --> Controller Class Initialized
INFO - 2025-07-01 05:11:18 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:11:18 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:11:18 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:11:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:11:18 --> 검색 로그: {"search_query":"\uac15\ub0a8\uad6c \ubcd1\uc6d0","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:11:18"}
INFO - 2025-07-01 05:11:18 --> Final output sent to browser
DEBUG - 2025-07-01 05:11:18 --> Total execution time: 0.3465
INFO - 2025-07-01 05:11:21 --> Config Class Initialized
INFO - 2025-07-01 05:11:21 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:11:21 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:11:21 --> Utf8 Class Initialized
INFO - 2025-07-01 05:11:21 --> URI Class Initialized
INFO - 2025-07-01 05:11:21 --> Router Class Initialized
INFO - 2025-07-01 05:11:21 --> Output Class Initialized
INFO - 2025-07-01 05:11:21 --> Security Class Initialized
DEBUG - 2025-07-01 05:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:11:21 --> Input Class Initialized
INFO - 2025-07-01 05:11:21 --> Language Class Initialized
INFO - 2025-07-01 05:11:21 --> Loader Class Initialized
INFO - 2025-07-01 05:11:21 --> Helper loaded: url_helper
INFO - 2025-07-01 05:11:21 --> Helper loaded: form_helper
INFO - 2025-07-01 05:11:21 --> Helper loaded: file_helper
INFO - 2025-07-01 05:11:21 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:11:21 --> Form Validation Class Initialized
INFO - 2025-07-01 05:11:21 --> Upload Class Initialized
INFO - 2025-07-01 05:11:21 --> Controller Class Initialized
INFO - 2025-07-01 05:11:21 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:11:21 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:11:21 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:11:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:11:21 --> 검색 로그: {"search_query":"\uac15\ub0a8\uad6c \ubcd1\uc6d0","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:11:21"}
INFO - 2025-07-01 05:11:21 --> Final output sent to browser
DEBUG - 2025-07-01 05:11:21 --> Total execution time: 0.3262
INFO - 2025-07-01 05:27:41 --> Config Class Initialized
INFO - 2025-07-01 05:27:41 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:27:41 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:27:41 --> Utf8 Class Initialized
INFO - 2025-07-01 05:27:41 --> URI Class Initialized
INFO - 2025-07-01 05:27:41 --> Router Class Initialized
INFO - 2025-07-01 05:27:41 --> Output Class Initialized
INFO - 2025-07-01 05:27:41 --> Security Class Initialized
DEBUG - 2025-07-01 05:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:27:41 --> Input Class Initialized
INFO - 2025-07-01 05:27:41 --> Language Class Initialized
INFO - 2025-07-01 05:27:42 --> Loader Class Initialized
INFO - 2025-07-01 05:27:42 --> Helper loaded: url_helper
INFO - 2025-07-01 05:27:42 --> Helper loaded: form_helper
INFO - 2025-07-01 05:27:42 --> Helper loaded: file_helper
INFO - 2025-07-01 05:27:42 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:27:42 --> Form Validation Class Initialized
INFO - 2025-07-01 05:27:42 --> Upload Class Initialized
INFO - 2025-07-01 05:27:42 --> Controller Class Initialized
INFO - 2025-07-01 05:27:42 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:27:42 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:27:42 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:27:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:27:42 --> File loaded: /var/www/html/source/application/views/hospital/search_main.php
INFO - 2025-07-01 05:27:42 --> Final output sent to browser
DEBUG - 2025-07-01 05:27:42 --> Total execution time: 0.2375
INFO - 2025-07-01 05:27:42 --> Config Class Initialized
INFO - 2025-07-01 05:27:42 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:27:42 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:27:42 --> Utf8 Class Initialized
INFO - 2025-07-01 05:27:42 --> URI Class Initialized
INFO - 2025-07-01 05:27:42 --> Router Class Initialized
INFO - 2025-07-01 05:27:42 --> Output Class Initialized
INFO - 2025-07-01 05:27:42 --> Security Class Initialized
DEBUG - 2025-07-01 05:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:27:42 --> Input Class Initialized
INFO - 2025-07-01 05:27:42 --> Language Class Initialized
INFO - 2025-07-01 05:27:50 --> Config Class Initialized
INFO - 2025-07-01 05:27:50 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:27:50 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:27:50 --> Utf8 Class Initialized
INFO - 2025-07-01 05:27:50 --> URI Class Initialized
INFO - 2025-07-01 05:27:50 --> Router Class Initialized
INFO - 2025-07-01 05:27:50 --> Output Class Initialized
INFO - 2025-07-01 05:27:50 --> Security Class Initialized
DEBUG - 2025-07-01 05:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:27:50 --> Input Class Initialized
INFO - 2025-07-01 05:27:50 --> Language Class Initialized
INFO - 2025-07-01 05:27:50 --> Loader Class Initialized
INFO - 2025-07-01 05:27:50 --> Helper loaded: url_helper
INFO - 2025-07-01 05:27:50 --> Helper loaded: form_helper
INFO - 2025-07-01 05:27:50 --> Helper loaded: file_helper
INFO - 2025-07-01 05:27:50 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:27:50 --> Form Validation Class Initialized
INFO - 2025-07-01 05:27:50 --> Upload Class Initialized
INFO - 2025-07-01 05:27:50 --> Controller Class Initialized
INFO - 2025-07-01 05:27:50 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:27:50 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:27:50 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:27:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:27:50 --> 검색 로그: {"search_query":"\uac15\ub0a8\uad6c \ubcd1\uc6d0","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:27:50"}
INFO - 2025-07-01 05:27:50 --> Final output sent to browser
DEBUG - 2025-07-01 05:27:50 --> Total execution time: 0.3565
INFO - 2025-07-01 05:29:15 --> Config Class Initialized
INFO - 2025-07-01 05:29:15 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:29:15 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:29:15 --> Utf8 Class Initialized
INFO - 2025-07-01 05:29:15 --> URI Class Initialized
INFO - 2025-07-01 05:29:15 --> Router Class Initialized
INFO - 2025-07-01 05:29:15 --> Output Class Initialized
INFO - 2025-07-01 05:29:15 --> Security Class Initialized
DEBUG - 2025-07-01 05:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:29:15 --> Input Class Initialized
INFO - 2025-07-01 05:29:15 --> Language Class Initialized
INFO - 2025-07-01 05:29:15 --> Loader Class Initialized
INFO - 2025-07-01 05:29:15 --> Helper loaded: url_helper
INFO - 2025-07-01 05:29:15 --> Helper loaded: form_helper
INFO - 2025-07-01 05:29:15 --> Helper loaded: file_helper
INFO - 2025-07-01 05:29:15 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:29:15 --> Form Validation Class Initialized
INFO - 2025-07-01 05:29:15 --> Upload Class Initialized
INFO - 2025-07-01 05:29:15 --> Controller Class Initialized
INFO - 2025-07-01 05:29:15 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:29:15 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:29:15 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:29:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:29:15 --> File loaded: /var/www/html/source/application/views/hospital/search_main.php
INFO - 2025-07-01 05:29:15 --> Final output sent to browser
DEBUG - 2025-07-01 05:29:15 --> Total execution time: 0.2771
INFO - 2025-07-01 05:29:15 --> Config Class Initialized
INFO - 2025-07-01 05:29:15 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:29:15 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:29:15 --> Utf8 Class Initialized
INFO - 2025-07-01 05:29:15 --> URI Class Initialized
INFO - 2025-07-01 05:29:15 --> Router Class Initialized
INFO - 2025-07-01 05:29:15 --> Output Class Initialized
INFO - 2025-07-01 05:29:16 --> Security Class Initialized
DEBUG - 2025-07-01 05:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:29:16 --> Input Class Initialized
INFO - 2025-07-01 05:29:16 --> Language Class Initialized
INFO - 2025-07-01 05:29:21 --> Config Class Initialized
INFO - 2025-07-01 05:29:21 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:29:21 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:29:21 --> Utf8 Class Initialized
INFO - 2025-07-01 05:29:21 --> URI Class Initialized
INFO - 2025-07-01 05:29:21 --> Router Class Initialized
INFO - 2025-07-01 05:29:21 --> Output Class Initialized
INFO - 2025-07-01 05:29:21 --> Security Class Initialized
DEBUG - 2025-07-01 05:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:29:21 --> Input Class Initialized
INFO - 2025-07-01 05:29:21 --> Language Class Initialized
INFO - 2025-07-01 05:29:21 --> Loader Class Initialized
INFO - 2025-07-01 05:29:21 --> Helper loaded: url_helper
INFO - 2025-07-01 05:29:21 --> Helper loaded: form_helper
INFO - 2025-07-01 05:29:21 --> Helper loaded: file_helper
INFO - 2025-07-01 05:29:21 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:29:21 --> Form Validation Class Initialized
INFO - 2025-07-01 05:29:21 --> Upload Class Initialized
INFO - 2025-07-01 05:29:21 --> Controller Class Initialized
INFO - 2025-07-01 05:29:21 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:29:21 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:29:21 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:29:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:29:21 --> 검색 로그: {"search_query":"\uac15\ub0a8\uad6c \ubcd1\uc6d0","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:29:21"}
INFO - 2025-07-01 05:29:21 --> Final output sent to browser
DEBUG - 2025-07-01 05:29:21 --> Total execution time: 0.3951
INFO - 2025-07-01 05:30:18 --> Config Class Initialized
INFO - 2025-07-01 05:30:18 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:30:18 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:30:18 --> Utf8 Class Initialized
INFO - 2025-07-01 05:30:18 --> URI Class Initialized
INFO - 2025-07-01 05:30:18 --> Router Class Initialized
INFO - 2025-07-01 05:30:18 --> Output Class Initialized
INFO - 2025-07-01 05:30:18 --> Security Class Initialized
DEBUG - 2025-07-01 05:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:30:18 --> Input Class Initialized
INFO - 2025-07-01 05:30:18 --> Language Class Initialized
INFO - 2025-07-01 05:30:18 --> Loader Class Initialized
INFO - 2025-07-01 05:30:19 --> Helper loaded: url_helper
INFO - 2025-07-01 05:30:19 --> Helper loaded: form_helper
INFO - 2025-07-01 05:30:19 --> Helper loaded: file_helper
INFO - 2025-07-01 05:30:19 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:30:19 --> Form Validation Class Initialized
INFO - 2025-07-01 05:30:19 --> Upload Class Initialized
INFO - 2025-07-01 05:30:19 --> Controller Class Initialized
INFO - 2025-07-01 05:30:19 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:30:19 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:30:19 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:30:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:30:19 --> 검색 로그: {"search_query":"\uac15\ub0a8\uad6c \ubcd1\uc6d0","result_count":50,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:30:19"}
INFO - 2025-07-01 05:30:19 --> Final output sent to browser
DEBUG - 2025-07-01 05:30:19 --> Total execution time: 0.4007
INFO - 2025-07-01 05:30:31 --> Config Class Initialized
INFO - 2025-07-01 05:30:31 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:30:31 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:30:31 --> Utf8 Class Initialized
INFO - 2025-07-01 05:30:31 --> URI Class Initialized
INFO - 2025-07-01 05:30:31 --> Router Class Initialized
INFO - 2025-07-01 05:30:31 --> Output Class Initialized
INFO - 2025-07-01 05:30:31 --> Security Class Initialized
DEBUG - 2025-07-01 05:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:30:31 --> Input Class Initialized
INFO - 2025-07-01 05:30:31 --> Language Class Initialized
INFO - 2025-07-01 05:30:31 --> Loader Class Initialized
INFO - 2025-07-01 05:30:31 --> Helper loaded: url_helper
INFO - 2025-07-01 05:30:31 --> Helper loaded: form_helper
INFO - 2025-07-01 05:30:31 --> Helper loaded: file_helper
INFO - 2025-07-01 05:30:31 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:30:31 --> Form Validation Class Initialized
INFO - 2025-07-01 05:30:31 --> Upload Class Initialized
INFO - 2025-07-01 05:30:31 --> Controller Class Initialized
INFO - 2025-07-01 05:30:31 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:30:31 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:30:31 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:30:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:30:31 --> 검색 로그: {"search_query":"\uad11\ub3d9\ubcd1\uc6d0 \uc704\uce58","result_count":1,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:30:31"}
ERROR - 2025-07-01 05:30:31 --> Severity: Warning --> Undefined array key "search_params" /var/www/html/source/application/controllers/Hospital_search.php 57
INFO - 2025-07-01 05:30:31 --> Final output sent to browser
DEBUG - 2025-07-01 05:30:31 --> Total execution time: 0.4553
INFO - 2025-07-01 05:34:04 --> Config Class Initialized
INFO - 2025-07-01 05:34:04 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:34:04 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:34:04 --> Utf8 Class Initialized
INFO - 2025-07-01 05:34:04 --> URI Class Initialized
INFO - 2025-07-01 05:34:05 --> Router Class Initialized
INFO - 2025-07-01 05:34:05 --> Output Class Initialized
INFO - 2025-07-01 05:34:05 --> Security Class Initialized
DEBUG - 2025-07-01 05:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:34:05 --> Input Class Initialized
INFO - 2025-07-01 05:34:05 --> Language Class Initialized
INFO - 2025-07-01 05:34:05 --> Loader Class Initialized
INFO - 2025-07-01 05:34:05 --> Helper loaded: url_helper
INFO - 2025-07-01 05:34:05 --> Helper loaded: form_helper
INFO - 2025-07-01 05:34:05 --> Helper loaded: file_helper
INFO - 2025-07-01 05:34:05 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:34:05 --> Form Validation Class Initialized
INFO - 2025-07-01 05:34:05 --> Upload Class Initialized
INFO - 2025-07-01 05:34:05 --> Controller Class Initialized
INFO - 2025-07-01 05:34:05 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:34:05 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:34:05 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:34:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:34:05 --> 검색 로그: {"search_query":"\uadfc\ucc98 \ubcd1\uc6d0","result_count":50,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:34:05"}
INFO - 2025-07-01 05:34:05 --> Final output sent to browser
DEBUG - 2025-07-01 05:34:05 --> Total execution time: 0.3547
INFO - 2025-07-01 05:34:07 --> Config Class Initialized
INFO - 2025-07-01 05:34:07 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:34:07 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:34:07 --> Utf8 Class Initialized
INFO - 2025-07-01 05:34:07 --> URI Class Initialized
INFO - 2025-07-01 05:34:07 --> Router Class Initialized
INFO - 2025-07-01 05:34:07 --> Output Class Initialized
INFO - 2025-07-01 05:34:07 --> Security Class Initialized
DEBUG - 2025-07-01 05:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:34:07 --> Input Class Initialized
INFO - 2025-07-01 05:34:07 --> Language Class Initialized
INFO - 2025-07-01 05:34:07 --> Loader Class Initialized
INFO - 2025-07-01 05:34:07 --> Helper loaded: url_helper
INFO - 2025-07-01 05:34:07 --> Helper loaded: form_helper
INFO - 2025-07-01 05:34:07 --> Helper loaded: file_helper
INFO - 2025-07-01 05:34:07 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:34:07 --> Form Validation Class Initialized
INFO - 2025-07-01 05:34:07 --> Upload Class Initialized
INFO - 2025-07-01 05:34:07 --> Controller Class Initialized
INFO - 2025-07-01 05:34:07 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:34:07 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:34:07 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:34:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:34:07 --> 검색 로그: {"search_query":"\uadfc\ucc98 \ubcd1\uc6d0","result_count":50,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:34:07"}
INFO - 2025-07-01 05:34:07 --> Final output sent to browser
DEBUG - 2025-07-01 05:34:07 --> Total execution time: 0.3363
INFO - 2025-07-01 05:34:09 --> Config Class Initialized
INFO - 2025-07-01 05:34:09 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:34:09 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:34:09 --> Utf8 Class Initialized
INFO - 2025-07-01 05:34:09 --> URI Class Initialized
INFO - 2025-07-01 05:34:09 --> Router Class Initialized
INFO - 2025-07-01 05:34:09 --> Output Class Initialized
INFO - 2025-07-01 05:34:09 --> Security Class Initialized
DEBUG - 2025-07-01 05:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:34:09 --> Input Class Initialized
INFO - 2025-07-01 05:34:09 --> Language Class Initialized
INFO - 2025-07-01 05:34:09 --> Loader Class Initialized
INFO - 2025-07-01 05:34:09 --> Helper loaded: url_helper
INFO - 2025-07-01 05:34:09 --> Helper loaded: form_helper
INFO - 2025-07-01 05:34:09 --> Helper loaded: file_helper
INFO - 2025-07-01 05:34:09 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:34:09 --> Form Validation Class Initialized
INFO - 2025-07-01 05:34:09 --> Upload Class Initialized
INFO - 2025-07-01 05:34:09 --> Controller Class Initialized
INFO - 2025-07-01 05:34:09 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:34:09 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:34:09 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:34:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:34:09 --> File loaded: /var/www/html/source/application/views/hospital/search_main.php
INFO - 2025-07-01 05:34:09 --> Final output sent to browser
DEBUG - 2025-07-01 05:34:09 --> Total execution time: 0.1436
INFO - 2025-07-01 05:34:09 --> Config Class Initialized
INFO - 2025-07-01 05:34:09 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:34:09 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:34:09 --> Utf8 Class Initialized
INFO - 2025-07-01 05:34:09 --> URI Class Initialized
INFO - 2025-07-01 05:34:09 --> Router Class Initialized
INFO - 2025-07-01 05:34:09 --> Output Class Initialized
INFO - 2025-07-01 05:34:09 --> Security Class Initialized
DEBUG - 2025-07-01 05:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:34:09 --> Input Class Initialized
INFO - 2025-07-01 05:34:09 --> Language Class Initialized
INFO - 2025-07-01 05:34:16 --> Config Class Initialized
INFO - 2025-07-01 05:34:16 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:34:16 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:34:16 --> Utf8 Class Initialized
INFO - 2025-07-01 05:34:16 --> URI Class Initialized
INFO - 2025-07-01 05:34:16 --> Router Class Initialized
INFO - 2025-07-01 05:34:16 --> Output Class Initialized
INFO - 2025-07-01 05:34:16 --> Security Class Initialized
DEBUG - 2025-07-01 05:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:34:16 --> Input Class Initialized
INFO - 2025-07-01 05:34:16 --> Language Class Initialized
INFO - 2025-07-01 05:34:16 --> Loader Class Initialized
INFO - 2025-07-01 05:34:16 --> Helper loaded: url_helper
INFO - 2025-07-01 05:34:16 --> Helper loaded: form_helper
INFO - 2025-07-01 05:34:16 --> Helper loaded: file_helper
INFO - 2025-07-01 05:34:16 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:34:16 --> Form Validation Class Initialized
INFO - 2025-07-01 05:34:16 --> Upload Class Initialized
INFO - 2025-07-01 05:34:16 --> Controller Class Initialized
INFO - 2025-07-01 05:34:16 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:34:16 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:34:16 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:34:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:34:16 --> 검색 로그: {"search_query":"\uadfc\ucc98\ubcd1\uc6d0","result_count":50,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:34:16"}
INFO - 2025-07-01 05:34:16 --> Final output sent to browser
DEBUG - 2025-07-01 05:34:16 --> Total execution time: 0.2924
INFO - 2025-07-01 05:34:32 --> Config Class Initialized
INFO - 2025-07-01 05:34:32 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:34:32 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:34:32 --> Utf8 Class Initialized
INFO - 2025-07-01 05:34:32 --> URI Class Initialized
INFO - 2025-07-01 05:34:32 --> Router Class Initialized
INFO - 2025-07-01 05:34:32 --> Output Class Initialized
INFO - 2025-07-01 05:34:32 --> Security Class Initialized
DEBUG - 2025-07-01 05:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:34:32 --> Input Class Initialized
INFO - 2025-07-01 05:34:32 --> Language Class Initialized
INFO - 2025-07-01 05:34:32 --> Loader Class Initialized
INFO - 2025-07-01 05:34:32 --> Helper loaded: url_helper
INFO - 2025-07-01 05:34:32 --> Helper loaded: form_helper
INFO - 2025-07-01 05:34:32 --> Helper loaded: file_helper
INFO - 2025-07-01 05:34:32 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:34:32 --> Form Validation Class Initialized
INFO - 2025-07-01 05:34:32 --> Upload Class Initialized
INFO - 2025-07-01 05:34:32 --> Controller Class Initialized
INFO - 2025-07-01 05:34:32 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:34:32 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:34:32 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:34:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:34:31 --> 검색 로그: {"search_query":"\uadfc\ucc98 \ubcd1\uc6d0","result_count":50,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:34:31"}
INFO - 2025-07-01 05:34:31 --> Final output sent to browser
DEBUG - 2025-07-01 05:34:31 --> Total execution time: -1.5231
INFO - 2025-07-01 05:34:40 --> Config Class Initialized
INFO - 2025-07-01 05:34:40 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:34:40 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:34:40 --> Utf8 Class Initialized
INFO - 2025-07-01 05:34:40 --> URI Class Initialized
INFO - 2025-07-01 05:34:40 --> Router Class Initialized
INFO - 2025-07-01 05:34:40 --> Output Class Initialized
INFO - 2025-07-01 05:34:40 --> Security Class Initialized
DEBUG - 2025-07-01 05:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:34:40 --> Input Class Initialized
INFO - 2025-07-01 05:34:40 --> Language Class Initialized
INFO - 2025-07-01 05:34:40 --> Loader Class Initialized
INFO - 2025-07-01 05:34:40 --> Helper loaded: url_helper
INFO - 2025-07-01 05:34:40 --> Helper loaded: form_helper
INFO - 2025-07-01 05:34:40 --> Helper loaded: file_helper
INFO - 2025-07-01 05:34:40 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:34:40 --> Form Validation Class Initialized
INFO - 2025-07-01 05:34:40 --> Upload Class Initialized
INFO - 2025-07-01 05:34:40 --> Controller Class Initialized
INFO - 2025-07-01 05:34:40 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:34:40 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:34:40 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:34:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:34:40 --> 검색 로그: {"search_query":"37.4056318,127.1151263","result_count":0,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:34:40"}
INFO - 2025-07-01 05:34:40 --> Final output sent to browser
DEBUG - 2025-07-01 05:34:40 --> Total execution time: 0.4827
INFO - 2025-07-01 05:34:46 --> Config Class Initialized
INFO - 2025-07-01 05:34:46 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:34:46 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:34:46 --> Utf8 Class Initialized
INFO - 2025-07-01 05:34:46 --> URI Class Initialized
INFO - 2025-07-01 05:34:46 --> Router Class Initialized
INFO - 2025-07-01 05:34:46 --> Output Class Initialized
INFO - 2025-07-01 05:34:46 --> Security Class Initialized
DEBUG - 2025-07-01 05:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:34:46 --> Input Class Initialized
INFO - 2025-07-01 05:34:46 --> Language Class Initialized
INFO - 2025-07-01 05:34:46 --> Loader Class Initialized
INFO - 2025-07-01 05:34:46 --> Helper loaded: url_helper
INFO - 2025-07-01 05:34:46 --> Helper loaded: form_helper
INFO - 2025-07-01 05:34:46 --> Helper loaded: file_helper
INFO - 2025-07-01 05:34:46 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:34:46 --> Form Validation Class Initialized
INFO - 2025-07-01 05:34:46 --> Upload Class Initialized
INFO - 2025-07-01 05:34:46 --> Controller Class Initialized
INFO - 2025-07-01 05:34:46 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:34:46 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:34:46 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:34:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:34:46 --> 검색 로그: {"search_query":"\uadfc\ucc98 \ubcd1\uc6d0","result_count":50,"ip_address":"172.20.0.1","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/138.0.0.0 Safari\/537.36","search_date":"2025-07-01 05:34:46"}
INFO - 2025-07-01 05:34:46 --> Final output sent to browser
DEBUG - 2025-07-01 05:34:46 --> Total execution time: 0.3388
INFO - 2025-07-01 05:41:19 --> Config Class Initialized
INFO - 2025-07-01 05:41:19 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:41:19 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:41:19 --> Utf8 Class Initialized
INFO - 2025-07-01 05:41:19 --> URI Class Initialized
INFO - 2025-07-01 05:41:19 --> Router Class Initialized
INFO - 2025-07-01 05:41:19 --> Output Class Initialized
INFO - 2025-07-01 05:41:19 --> Security Class Initialized
DEBUG - 2025-07-01 05:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:41:19 --> Input Class Initialized
INFO - 2025-07-01 05:41:19 --> Language Class Initialized
INFO - 2025-07-01 05:41:19 --> Loader Class Initialized
INFO - 2025-07-01 05:41:19 --> Helper loaded: url_helper
INFO - 2025-07-01 05:41:19 --> Helper loaded: form_helper
INFO - 2025-07-01 05:41:19 --> Helper loaded: file_helper
INFO - 2025-07-01 05:41:19 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:41:19 --> Form Validation Class Initialized
INFO - 2025-07-01 05:41:19 --> Upload Class Initialized
INFO - 2025-07-01 05:41:19 --> Controller Class Initialized
INFO - 2025-07-01 05:41:19 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:41:19 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:41:19 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:41:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:41:19 --> File loaded: /var/www/html/source/application/views/hospital/search_main.php
INFO - 2025-07-01 05:41:19 --> Final output sent to browser
DEBUG - 2025-07-01 05:41:19 --> Total execution time: 0.2348
INFO - 2025-07-01 05:41:19 --> Config Class Initialized
INFO - 2025-07-01 05:41:19 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:41:19 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:41:19 --> Utf8 Class Initialized
INFO - 2025-07-01 05:41:19 --> URI Class Initialized
INFO - 2025-07-01 05:41:19 --> Router Class Initialized
INFO - 2025-07-01 05:41:19 --> Output Class Initialized
INFO - 2025-07-01 05:41:19 --> Security Class Initialized
DEBUG - 2025-07-01 05:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:41:19 --> Input Class Initialized
INFO - 2025-07-01 05:41:19 --> Language Class Initialized
INFO - 2025-07-01 05:41:21 --> Config Class Initialized
INFO - 2025-07-01 05:41:21 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:41:21 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:41:21 --> Utf8 Class Initialized
INFO - 2025-07-01 05:41:21 --> URI Class Initialized
INFO - 2025-07-01 05:41:21 --> Router Class Initialized
INFO - 2025-07-01 05:41:21 --> Output Class Initialized
INFO - 2025-07-01 05:41:21 --> Security Class Initialized
DEBUG - 2025-07-01 05:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:41:21 --> Input Class Initialized
INFO - 2025-07-01 05:41:21 --> Language Class Initialized
INFO - 2025-07-01 05:41:21 --> Loader Class Initialized
INFO - 2025-07-01 05:41:21 --> Helper loaded: url_helper
INFO - 2025-07-01 05:41:21 --> Helper loaded: form_helper
INFO - 2025-07-01 05:41:21 --> Helper loaded: file_helper
INFO - 2025-07-01 05:41:21 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:41:21 --> Form Validation Class Initialized
INFO - 2025-07-01 05:41:21 --> Upload Class Initialized
INFO - 2025-07-01 05:41:21 --> Controller Class Initialized
INFO - 2025-07-01 05:41:21 --> Model "Question_type_model" initialized
INFO - 2025-07-01 05:41:21 --> Model "Hospital_search_model" initialized
INFO - 2025-07-01 05:41:21 --> Helper loaded: html_helper
DEBUG - 2025-07-01 05:41:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-01 05:41:22 --> Final output sent to browser
DEBUG - 2025-07-01 05:41:22 --> Total execution time: 0.2760
INFO - 2025-07-01 05:43:15 --> Config Class Initialized
INFO - 2025-07-01 05:43:15 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:43:15 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:43:15 --> Utf8 Class Initialized
INFO - 2025-07-01 05:43:15 --> URI Class Initialized
DEBUG - 2025-07-01 05:43:15 --> No URI present. Default controller set.
INFO - 2025-07-01 05:43:15 --> Router Class Initialized
INFO - 2025-07-01 05:43:15 --> Output Class Initialized
INFO - 2025-07-01 05:43:15 --> Security Class Initialized
DEBUG - 2025-07-01 05:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:43:15 --> Input Class Initialized
INFO - 2025-07-01 05:43:15 --> Language Class Initialized
INFO - 2025-07-01 05:43:15 --> Loader Class Initialized
INFO - 2025-07-01 05:43:15 --> Helper loaded: url_helper
INFO - 2025-07-01 05:43:15 --> Helper loaded: form_helper
INFO - 2025-07-01 05:43:15 --> Helper loaded: file_helper
INFO - 2025-07-01 05:43:15 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:43:15 --> Form Validation Class Initialized
INFO - 2025-07-01 05:43:16 --> Upload Class Initialized
INFO - 2025-07-01 05:43:16 --> Controller Class Initialized
INFO - 2025-07-01 05:43:16 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-07-01 05:43:16 --> Final output sent to browser
DEBUG - 2025-07-01 05:43:16 --> Total execution time: 0.2930
INFO - 2025-07-01 05:43:16 --> Config Class Initialized
INFO - 2025-07-01 05:43:16 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:43:16 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:43:16 --> Utf8 Class Initialized
INFO - 2025-07-01 05:43:16 --> URI Class Initialized
INFO - 2025-07-01 05:43:16 --> Router Class Initialized
INFO - 2025-07-01 05:43:16 --> Output Class Initialized
INFO - 2025-07-01 05:43:16 --> Security Class Initialized
DEBUG - 2025-07-01 05:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:43:16 --> Input Class Initialized
INFO - 2025-07-01 05:43:16 --> Language Class Initialized
INFO - 2025-07-01 05:43:17 --> Config Class Initialized
INFO - 2025-07-01 05:43:17 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:43:17 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:43:17 --> Utf8 Class Initialized
INFO - 2025-07-01 05:43:17 --> URI Class Initialized
DEBUG - 2025-07-01 05:43:17 --> No URI present. Default controller set.
INFO - 2025-07-01 05:43:17 --> Router Class Initialized
INFO - 2025-07-01 05:43:17 --> Output Class Initialized
INFO - 2025-07-01 05:43:17 --> Security Class Initialized
DEBUG - 2025-07-01 05:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:43:17 --> Input Class Initialized
INFO - 2025-07-01 05:43:17 --> Language Class Initialized
INFO - 2025-07-01 05:43:17 --> Loader Class Initialized
INFO - 2025-07-01 05:43:17 --> Helper loaded: url_helper
INFO - 2025-07-01 05:43:18 --> Helper loaded: form_helper
INFO - 2025-07-01 05:43:18 --> Helper loaded: file_helper
INFO - 2025-07-01 05:43:18 --> Database Driver Class Initialized
DEBUG - 2025-07-01 05:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-01 05:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-01 05:43:18 --> Form Validation Class Initialized
INFO - 2025-07-01 05:43:18 --> Upload Class Initialized
INFO - 2025-07-01 05:43:18 --> Controller Class Initialized
INFO - 2025-07-01 05:43:18 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-07-01 05:43:18 --> Final output sent to browser
DEBUG - 2025-07-01 05:43:18 --> Total execution time: 0.1475
INFO - 2025-07-01 05:43:18 --> Config Class Initialized
INFO - 2025-07-01 05:43:18 --> Hooks Class Initialized
DEBUG - 2025-07-01 05:43:18 --> UTF-8 Support Enabled
INFO - 2025-07-01 05:43:18 --> Utf8 Class Initialized
INFO - 2025-07-01 05:43:18 --> URI Class Initialized
INFO - 2025-07-01 05:43:18 --> Router Class Initialized
INFO - 2025-07-01 05:43:18 --> Output Class Initialized
INFO - 2025-07-01 05:43:18 --> Security Class Initialized
DEBUG - 2025-07-01 05:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-01 05:43:18 --> Input Class Initialized
INFO - 2025-07-01 05:43:18 --> Language Class Initialized
