<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-06-30 04:14:12 --> Config Class Initialized
INFO - 2025-06-30 04:14:12 --> Hooks Class Initialized
DEBUG - 2025-06-30 04:14:12 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:14:12 --> Utf8 Class Initialized
INFO - 2025-06-30 04:14:12 --> URI Class Initialized
DEBUG - 2025-06-30 04:14:12 --> No URI present. Default controller set.
INFO - 2025-06-30 04:14:12 --> Router Class Initialized
INFO - 2025-06-30 04:14:12 --> Output Class Initialized
INFO - 2025-06-30 04:14:12 --> Security Class Initialized
DEBUG - 2025-06-30 04:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:14:12 --> Input Class Initialized
INFO - 2025-06-30 04:14:12 --> Language Class Initialized
INFO - 2025-06-30 04:14:12 --> Loader Class Initialized
INFO - 2025-06-30 04:14:12 --> Controller Class Initialized
ERROR - 2025-06-30 04:14:12 --> Severity: error --> Exception: Call to undefined function base_url() /var/www/html/application/views/main_dashboard.php 11
INFO - 2025-06-30 04:14:48 --> Config Class Initialized
INFO - 2025-06-30 04:14:48 --> Hooks Class Initialized
INFO - 2025-06-30 04:14:48 --> URI Class Initialized
DEBUG - 2025-06-30 04:14:48 --> No URI present. Default controller set.
INFO - 2025-06-30 04:14:48 --> Router Class Initialized
INFO - 2025-06-30 04:14:48 --> Output Class Initialized
INFO - 2025-06-30 04:14:48 --> Security Class Initialized
INFO - 2025-06-30 04:15:54 --> Config Class Initialized
INFO - 2025-06-30 04:15:54 --> Hooks Class Initialized
INFO - 2025-06-30 04:15:54 --> URI Class Initialized
DEBUG - 2025-06-30 04:15:54 --> No URI present. Default controller set.
INFO - 2025-06-30 04:15:54 --> Router Class Initialized
INFO - 2025-06-30 04:15:54 --> Output Class Initialized
INFO - 2025-06-30 04:15:54 --> Security Class Initialized
DEBUG - 2025-06-30 04:15:54 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:15:54 --> Utf8 Class Initialized
DEBUG - 2025-06-30 04:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:15:54 --> Input Class Initialized
INFO - 2025-06-30 04:15:54 --> Language Class Initialized
INFO - 2025-06-30 04:17:14 --> Config Class Initialized
INFO - 2025-06-30 04:17:14 --> Hooks Class Initialized
INFO - 2025-06-30 04:17:14 --> URI Class Initialized
DEBUG - 2025-06-30 04:17:14 --> No URI present. Default controller set.
INFO - 2025-06-30 04:17:14 --> Router Class Initialized
INFO - 2025-06-30 04:17:14 --> Output Class Initialized
INFO - 2025-06-30 04:17:14 --> Security Class Initialized
DEBUG - 2025-06-30 04:17:14 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:17:14 --> Utf8 Class Initialized
DEBUG - 2025-06-30 04:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:17:14 --> Input Class Initialized
INFO - 2025-06-30 04:17:14 --> Language Class Initialized
INFO - 2025-06-30 04:17:14 --> Config Class Initialized
INFO - 2025-06-30 04:17:14 --> Hooks Class Initialized
INFO - 2025-06-30 04:17:14 --> URI Class Initialized
DEBUG - 2025-06-30 04:17:14 --> No URI present. Default controller set.
INFO - 2025-06-30 04:17:14 --> Router Class Initialized
INFO - 2025-06-30 04:17:14 --> Output Class Initialized
INFO - 2025-06-30 04:17:14 --> Security Class Initialized
DEBUG - 2025-06-30 04:17:14 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:17:14 --> Utf8 Class Initialized
DEBUG - 2025-06-30 04:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:17:14 --> Input Class Initialized
INFO - 2025-06-30 04:17:14 --> Language Class Initialized
INFO - 2025-06-30 04:17:19 --> Config Class Initialized
INFO - 2025-06-30 04:17:19 --> Hooks Class Initialized
INFO - 2025-06-30 04:17:19 --> URI Class Initialized
DEBUG - 2025-06-30 04:17:19 --> No URI present. Default controller set.
INFO - 2025-06-30 04:17:19 --> Router Class Initialized
INFO - 2025-06-30 04:17:19 --> Output Class Initialized
INFO - 2025-06-30 04:17:19 --> Security Class Initialized
DEBUG - 2025-06-30 04:17:19 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:17:19 --> Utf8 Class Initialized
DEBUG - 2025-06-30 04:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:17:19 --> Input Class Initialized
INFO - 2025-06-30 04:17:19 --> Language Class Initialized
INFO - 2025-06-30 04:17:19 --> Config Class Initialized
INFO - 2025-06-30 04:17:19 --> Hooks Class Initialized
INFO - 2025-06-30 04:17:19 --> URI Class Initialized
INFO - 2025-06-30 04:17:19 --> Router Class Initialized
INFO - 2025-06-30 04:17:19 --> Output Class Initialized
INFO - 2025-06-30 04:17:19 --> Security Class Initialized
DEBUG - 2025-06-30 04:17:19 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:17:19 --> Utf8 Class Initialized
DEBUG - 2025-06-30 04:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:17:19 --> Input Class Initialized
INFO - 2025-06-30 04:17:19 --> Language Class Initialized
ERROR - 2025-06-30 04:17:19 --> 404 Page Not Found: Faviconico/index
INFO - 2025-06-30 04:20:20 --> Config Class Initialized
INFO - 2025-06-30 04:20:20 --> Hooks Class Initialized
INFO - 2025-06-30 04:20:20 --> URI Class Initialized
DEBUG - 2025-06-30 04:20:20 --> No URI present. Default controller set.
INFO - 2025-06-30 04:20:20 --> Router Class Initialized
INFO - 2025-06-30 04:20:20 --> Output Class Initialized
INFO - 2025-06-30 04:20:20 --> Security Class Initialized
INFO - 2025-06-30 04:20:20 --> Config Class Initialized
INFO - 2025-06-30 04:20:20 --> Hooks Class Initialized
INFO - 2025-06-30 04:20:20 --> URI Class Initialized
DEBUG - 2025-06-30 04:20:20 --> No URI present. Default controller set.
INFO - 2025-06-30 04:20:20 --> Router Class Initialized
INFO - 2025-06-30 04:20:20 --> Output Class Initialized
INFO - 2025-06-30 04:20:21 --> Security Class Initialized
INFO - 2025-06-30 04:21:54 --> Config Class Initialized
INFO - 2025-06-30 04:21:54 --> Hooks Class Initialized
INFO - 2025-06-30 04:21:54 --> URI Class Initialized
DEBUG - 2025-06-30 04:21:54 --> No URI present. Default controller set.
INFO - 2025-06-30 04:21:54 --> Router Class Initialized
INFO - 2025-06-30 04:21:54 --> Output Class Initialized
INFO - 2025-06-30 04:21:54 --> Security Class Initialized
DEBUG - 2025-06-30 04:21:54 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:21:54 --> Utf8 Class Initialized
DEBUG - 2025-06-30 04:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:21:54 --> Input Class Initialized
INFO - 2025-06-30 04:21:54 --> Language Class Initialized
INFO - 2025-06-30 04:22:30 --> Config Class Initialized
INFO - 2025-06-30 04:22:30 --> Hooks Class Initialized
ERROR - 2025-06-30 04:22:30 --> Severity: Warning --> Constant MB_ENABLED already defined /var/www/html/system/core/CodeIgniter.php 250
ERROR - 2025-06-30 04:22:30 --> Severity: Warning --> Constant ICONV_ENABLED already defined /var/www/html/system/core/CodeIgniter.php 267
ERROR - 2025-06-30 04:22:30 --> Severity: Warning --> Constant UTF8_ENABLED already defined /var/www/html/system/core/Utf8.php 69
DEBUG - 2025-06-30 04:22:30 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:22:30 --> Utf8 Class Initialized
INFO - 2025-06-30 04:22:30 --> URI Class Initialized
DEBUG - 2025-06-30 04:22:30 --> No URI present. Default controller set.
INFO - 2025-06-30 04:22:30 --> Router Class Initialized
INFO - 2025-06-30 04:22:30 --> Output Class Initialized
INFO - 2025-06-30 04:22:30 --> Security Class Initialized
DEBUG - 2025-06-30 04:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:22:30 --> Input Class Initialized
INFO - 2025-06-30 04:22:30 --> Language Class Initialized
INFO - 2025-06-30 04:22:30 --> Loader Class Initialized
INFO - 2025-06-30 04:22:30 --> Controller Class Initialized
INFO - 2025-06-30 04:22:30 --> File loaded: /var/www/html/application/views/welcome_message.php
INFO - 2025-06-30 04:22:30 --> Final output sent to browser
DEBUG - 2025-06-30 04:22:30 --> Total execution time: 0.1135
INFO - 2025-06-30 04:31:30 --> Config Class Initialized
INFO - 2025-06-30 04:31:30 --> Hooks Class Initialized
DEBUG - 2025-06-30 04:31:30 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:31:30 --> Utf8 Class Initialized
INFO - 2025-06-30 04:31:30 --> URI Class Initialized
DEBUG - 2025-06-30 04:31:30 --> No URI present. Default controller set.
INFO - 2025-06-30 04:31:30 --> Router Class Initialized
INFO - 2025-06-30 04:31:30 --> Output Class Initialized
INFO - 2025-06-30 04:31:30 --> Security Class Initialized
DEBUG - 2025-06-30 04:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:31:30 --> Input Class Initialized
INFO - 2025-06-30 04:31:30 --> Language Class Initialized
INFO - 2025-06-30 04:31:30 --> Loader Class Initialized
INFO - 2025-06-30 04:31:30 --> Controller Class Initialized
INFO - 2025-06-30 04:31:30 --> File loaded: /var/www/html/application/views/welcome_message.php
INFO - 2025-06-30 04:31:30 --> Final output sent to browser
DEBUG - 2025-06-30 04:31:30 --> Total execution time: 0.1863
INFO - 2025-06-30 04:31:55 --> Config Class Initialized
INFO - 2025-06-30 04:31:55 --> Hooks Class Initialized
DEBUG - 2025-06-30 04:31:55 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:31:55 --> Utf8 Class Initialized
INFO - 2025-06-30 04:31:55 --> URI Class Initialized
INFO - 2025-06-30 04:31:55 --> Router Class Initialized
INFO - 2025-06-30 04:31:55 --> Output Class Initialized
INFO - 2025-06-30 04:31:55 --> Security Class Initialized
DEBUG - 2025-06-30 04:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:31:55 --> Input Class Initialized
INFO - 2025-06-30 04:31:55 --> Language Class Initialized
INFO - 2025-06-30 04:31:55 --> Loader Class Initialized
INFO - 2025-06-30 04:31:55 --> Controller Class Initialized
INFO - 2025-06-30 04:31:55 --> Model "Medical_model" initialized
ERROR - 2025-06-30 04:31:55 --> Severity: Warning --> require_once(/var/www/html/vendor/autoload.php): Failed to open stream: No such file or directory /var/www/html/application/controllers/Medical.php 11
ERROR - 2025-06-30 04:31:55 --> Severity: error --> Exception: Failed opening required '/var/www/html/vendor/autoload.php' (include_path='.:/usr/share/php') /var/www/html/application/controllers/Medical.php 11
INFO - 2025-06-30 04:31:56 --> Config Class Initialized
INFO - 2025-06-30 04:31:56 --> Hooks Class Initialized
DEBUG - 2025-06-30 04:31:56 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:31:56 --> Utf8 Class Initialized
INFO - 2025-06-30 04:31:56 --> URI Class Initialized
INFO - 2025-06-30 04:31:56 --> Router Class Initialized
INFO - 2025-06-30 04:31:56 --> Output Class Initialized
INFO - 2025-06-30 04:31:56 --> Security Class Initialized
DEBUG - 2025-06-30 04:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:31:56 --> Input Class Initialized
INFO - 2025-06-30 04:31:56 --> Language Class Initialized
INFO - 2025-06-30 04:31:56 --> Loader Class Initialized
INFO - 2025-06-30 04:31:56 --> Controller Class Initialized
INFO - 2025-06-30 04:31:56 --> Model "Medical_model" initialized
ERROR - 2025-06-30 04:31:56 --> Severity: Warning --> require_once(/var/www/html/vendor/autoload.php): Failed to open stream: No such file or directory /var/www/html/application/controllers/Medical.php 11
ERROR - 2025-06-30 04:31:56 --> Severity: error --> Exception: Failed opening required '/var/www/html/vendor/autoload.php' (include_path='.:/usr/share/php') /var/www/html/application/controllers/Medical.php 11
INFO - 2025-06-30 04:32:23 --> Config Class Initialized
INFO - 2025-06-30 04:32:23 --> Hooks Class Initialized
DEBUG - 2025-06-30 04:32:23 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:32:23 --> Utf8 Class Initialized
INFO - 2025-06-30 04:32:23 --> URI Class Initialized
INFO - 2025-06-30 04:32:23 --> Router Class Initialized
INFO - 2025-06-30 04:32:23 --> Output Class Initialized
INFO - 2025-06-30 04:32:23 --> Security Class Initialized
DEBUG - 2025-06-30 04:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:32:23 --> Input Class Initialized
INFO - 2025-06-30 04:32:23 --> Language Class Initialized
INFO - 2025-06-30 04:32:23 --> Loader Class Initialized
INFO - 2025-06-30 04:32:23 --> Controller Class Initialized
INFO - 2025-06-30 04:32:23 --> Model "Medical_model" initialized
ERROR - 2025-06-30 04:32:23 --> Severity: error --> Exception: Call to undefined function base_url() /var/www/html/application/views/medical/upload.php 7
INFO - 2025-06-30 04:32:23 --> Config Class Initialized
INFO - 2025-06-30 04:32:23 --> Hooks Class Initialized
DEBUG - 2025-06-30 04:32:23 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:32:23 --> Utf8 Class Initialized
INFO - 2025-06-30 04:33:05 --> Config Class Initialized
INFO - 2025-06-30 04:33:05 --> Hooks Class Initialized
DEBUG - 2025-06-30 04:33:05 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:33:05 --> Utf8 Class Initialized
INFO - 2025-06-30 04:33:05 --> URI Class Initialized
INFO - 2025-06-30 04:33:05 --> Router Class Initialized
INFO - 2025-06-30 04:33:05 --> Output Class Initialized
INFO - 2025-06-30 04:33:05 --> Security Class Initialized
DEBUG - 2025-06-30 04:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:33:05 --> Input Class Initialized
INFO - 2025-06-30 04:33:05 --> Language Class Initialized
INFO - 2025-06-30 04:33:05 --> Loader Class Initialized
INFO - 2025-06-30 04:33:05 --> Helper loaded: url_helper
INFO - 2025-06-30 04:33:05 --> Controller Class Initialized
INFO - 2025-06-30 04:33:05 --> Model "Medical_model" initialized
ERROR - 2025-06-30 04:33:05 --> Severity: Warning --> Undefined property: CI_Loader::$session /var/www/html/application/views/medical/upload.php 22
ERROR - 2025-06-30 04:33:05 --> Severity: error --> Exception: Call to a member function flashdata() on null /var/www/html/application/views/medical/upload.php 22
INFO - 2025-06-30 04:33:32 --> Config Class Initialized
INFO - 2025-06-30 04:33:32 --> Hooks Class Initialized
DEBUG - 2025-06-30 04:33:32 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:33:32 --> Utf8 Class Initialized
INFO - 2025-06-30 04:33:32 --> URI Class Initialized
INFO - 2025-06-30 04:33:32 --> Router Class Initialized
INFO - 2025-06-30 04:33:32 --> Output Class Initialized
INFO - 2025-06-30 04:33:32 --> Security Class Initialized
DEBUG - 2025-06-30 04:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:33:32 --> Input Class Initialized
INFO - 2025-06-30 04:33:32 --> Language Class Initialized
INFO - 2025-06-30 04:33:32 --> Loader Class Initialized
INFO - 2025-06-30 04:33:32 --> Helper loaded: url_helper
DEBUG - 2025-06-30 04:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 04:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 04:33:32 --> Controller Class Initialized
INFO - 2025-06-30 04:33:32 --> Model "Medical_model" initialized
ERROR - 2025-06-30 04:33:32 --> Severity: error --> Exception: Call to undefined function form_open_multipart() /var/www/html/application/views/medical/upload.php 34
INFO - 2025-06-30 04:35:03 --> Config Class Initialized
INFO - 2025-06-30 04:35:03 --> Hooks Class Initialized
DEBUG - 2025-06-30 04:35:03 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:35:03 --> Utf8 Class Initialized
INFO - 2025-06-30 04:35:03 --> URI Class Initialized
INFO - 2025-06-30 04:35:03 --> Router Class Initialized
INFO - 2025-06-30 04:35:03 --> Output Class Initialized
INFO - 2025-06-30 04:35:03 --> Security Class Initialized
DEBUG - 2025-06-30 04:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:35:03 --> Input Class Initialized
INFO - 2025-06-30 04:35:03 --> Language Class Initialized
INFO - 2025-06-30 04:35:03 --> Loader Class Initialized
INFO - 2025-06-30 04:35:03 --> Helper loaded: url_helper
INFO - 2025-06-30 04:35:03 --> Helper loaded: form_helper
DEBUG - 2025-06-30 04:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 04:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 04:35:03 --> Controller Class Initialized
INFO - 2025-06-30 04:35:03 --> Model "Medical_model" initialized
INFO - 2025-06-30 04:35:03 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 04:35:03 --> Final output sent to browser
DEBUG - 2025-06-30 04:35:03 --> Total execution time: 0.2329
INFO - 2025-06-30 04:35:14 --> Config Class Initialized
INFO - 2025-06-30 04:35:14 --> Config Class Initialized
INFO - 2025-06-30 04:35:14 --> Hooks Class Initialized
INFO - 2025-06-30 04:35:14 --> Hooks Class Initialized
DEBUG - 2025-06-30 04:35:14 --> UTF-8 Support Enabled
DEBUG - 2025-06-30 04:35:14 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:35:14 --> Utf8 Class Initialized
INFO - 2025-06-30 04:35:14 --> Utf8 Class Initialized
INFO - 2025-06-30 04:35:14 --> URI Class Initialized
INFO - 2025-06-30 04:35:14 --> URI Class Initialized
INFO - 2025-06-30 04:35:14 --> Router Class Initialized
INFO - 2025-06-30 04:35:14 --> Router Class Initialized
INFO - 2025-06-30 04:35:14 --> Output Class Initialized
INFO - 2025-06-30 04:35:14 --> Output Class Initialized
INFO - 2025-06-30 04:35:14 --> Security Class Initialized
INFO - 2025-06-30 04:35:14 --> Security Class Initialized
DEBUG - 2025-06-30 04:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-06-30 04:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:35:14 --> Input Class Initialized
INFO - 2025-06-30 04:35:14 --> Input Class Initialized
INFO - 2025-06-30 04:35:14 --> Language Class Initialized
INFO - 2025-06-30 04:35:14 --> Language Class Initialized
ERROR - 2025-06-30 04:35:14 --> 404 Page Not Found: Well-known/appspecific
ERROR - 2025-06-30 04:35:14 --> 404 Page Not Found: Assets/vendor
INFO - 2025-06-30 04:35:14 --> Config Class Initialized
INFO - 2025-06-30 04:35:14 --> Hooks Class Initialized
DEBUG - 2025-06-30 04:35:14 --> UTF-8 Support Enabled
INFO - 2025-06-30 04:35:14 --> Utf8 Class Initialized
INFO - 2025-06-30 04:35:14 --> URI Class Initialized
INFO - 2025-06-30 04:35:14 --> Router Class Initialized
INFO - 2025-06-30 04:35:14 --> Output Class Initialized
INFO - 2025-06-30 04:35:14 --> Security Class Initialized
DEBUG - 2025-06-30 04:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 04:35:14 --> Input Class Initialized
INFO - 2025-06-30 04:35:14 --> Language Class Initialized
ERROR - 2025-06-30 04:35:14 --> 404 Page Not Found: Assets/vendor
INFO - 2025-06-30 05:07:40 --> Config Class Initialized
INFO - 2025-06-30 05:07:40 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:07:40 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:40 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:40 --> URI Class Initialized
INFO - 2025-06-30 05:07:40 --> Router Class Initialized
INFO - 2025-06-30 05:07:40 --> Output Class Initialized
INFO - 2025-06-30 05:07:40 --> Security Class Initialized
DEBUG - 2025-06-30 05:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:07:40 --> Input Class Initialized
INFO - 2025-06-30 05:07:40 --> Language Class Initialized
INFO - 2025-06-30 05:07:40 --> Loader Class Initialized
INFO - 2025-06-30 05:07:40 --> Helper loaded: url_helper
INFO - 2025-06-30 05:07:40 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:07:40 --> Controller Class Initialized
INFO - 2025-06-30 05:07:40 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:07:40 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:07:40 --> Final output sent to browser
DEBUG - 2025-06-30 05:07:40 --> Total execution time: 0.1396
INFO - 2025-06-30 05:07:40 --> Config Class Initialized
INFO - 2025-06-30 05:07:40 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:07:40 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:40 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:41 --> URI Class Initialized
INFO - 2025-06-30 05:07:41 --> Router Class Initialized
INFO - 2025-06-30 05:07:41 --> Output Class Initialized
INFO - 2025-06-30 05:07:41 --> Security Class Initialized
DEBUG - 2025-06-30 05:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:07:41 --> Input Class Initialized
INFO - 2025-06-30 05:07:41 --> Language Class Initialized
ERROR - 2025-06-30 05:07:41 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:07:41 --> Config Class Initialized
INFO - 2025-06-30 05:07:41 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:07:41 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:41 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:41 --> URI Class Initialized
INFO - 2025-06-30 05:07:41 --> Router Class Initialized
INFO - 2025-06-30 05:07:41 --> Output Class Initialized
INFO - 2025-06-30 05:07:41 --> Security Class Initialized
DEBUG - 2025-06-30 05:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:07:41 --> Input Class Initialized
INFO - 2025-06-30 05:07:41 --> Language Class Initialized
INFO - 2025-06-30 05:07:41 --> Loader Class Initialized
INFO - 2025-06-30 05:07:41 --> Helper loaded: url_helper
INFO - 2025-06-30 05:07:41 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:07:41 --> Controller Class Initialized
INFO - 2025-06-30 05:07:41 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:07:42 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:07:42 --> Final output sent to browser
DEBUG - 2025-06-30 05:07:42 --> Total execution time: 0.0977
INFO - 2025-06-30 05:07:42 --> Config Class Initialized
INFO - 2025-06-30 05:07:42 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:07:42 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:42 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:42 --> URI Class Initialized
INFO - 2025-06-30 05:07:42 --> Router Class Initialized
INFO - 2025-06-30 05:07:42 --> Output Class Initialized
INFO - 2025-06-30 05:07:42 --> Security Class Initialized
DEBUG - 2025-06-30 05:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:07:42 --> Input Class Initialized
INFO - 2025-06-30 05:07:42 --> Language Class Initialized
ERROR - 2025-06-30 05:07:42 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:07:57 --> Config Class Initialized
INFO - 2025-06-30 05:07:57 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:07:57 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:57 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:57 --> URI Class Initialized
INFO - 2025-06-30 05:07:57 --> Router Class Initialized
INFO - 2025-06-30 05:07:57 --> Output Class Initialized
INFO - 2025-06-30 05:07:57 --> Security Class Initialized
DEBUG - 2025-06-30 05:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:07:57 --> Input Class Initialized
INFO - 2025-06-30 05:07:57 --> Language Class Initialized
INFO - 2025-06-30 05:07:57 --> Loader Class Initialized
INFO - 2025-06-30 05:07:57 --> Helper loaded: url_helper
INFO - 2025-06-30 05:07:57 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:07:57 --> Controller Class Initialized
INFO - 2025-06-30 05:07:57 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:07:57 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:07:57 --> Final output sent to browser
DEBUG - 2025-06-30 05:07:57 --> Total execution time: 0.1294
INFO - 2025-06-30 05:07:57 --> Config Class Initialized
INFO - 2025-06-30 05:07:57 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:07:57 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:57 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:57 --> URI Class Initialized
INFO - 2025-06-30 05:07:57 --> Config Class Initialized
INFO - 2025-06-30 05:07:57 --> Hooks Class Initialized
INFO - 2025-06-30 05:07:57 --> Router Class Initialized
DEBUG - 2025-06-30 05:07:57 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:57 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:57 --> Output Class Initialized
INFO - 2025-06-30 05:07:57 --> URI Class Initialized
INFO - 2025-06-30 05:07:57 --> Security Class Initialized
INFO - 2025-06-30 05:07:57 --> Router Class Initialized
DEBUG - 2025-06-30 05:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:07:57 --> Input Class Initialized
INFO - 2025-06-30 05:07:57 --> Output Class Initialized
INFO - 2025-06-30 05:07:57 --> Language Class Initialized
INFO - 2025-06-30 05:07:57 --> Security Class Initialized
ERROR - 2025-06-30 05:07:57 --> 404 Page Not Found: Well-known/appspecific
DEBUG - 2025-06-30 05:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:07:57 --> Input Class Initialized
INFO - 2025-06-30 05:07:57 --> Language Class Initialized
ERROR - 2025-06-30 05:07:57 --> 404 Page Not Found: Faviconico/index
INFO - 2025-06-30 05:07:58 --> Config Class Initialized
INFO - 2025-06-30 05:07:58 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:07:58 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:58 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:58 --> URI Class Initialized
INFO - 2025-06-30 05:07:58 --> Router Class Initialized
INFO - 2025-06-30 05:07:58 --> Output Class Initialized
INFO - 2025-06-30 05:07:58 --> Security Class Initialized
DEBUG - 2025-06-30 05:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:07:58 --> Input Class Initialized
INFO - 2025-06-30 05:07:58 --> Language Class Initialized
INFO - 2025-06-30 05:07:58 --> Loader Class Initialized
INFO - 2025-06-30 05:07:58 --> Helper loaded: url_helper
INFO - 2025-06-30 05:07:58 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:07:58 --> Controller Class Initialized
INFO - 2025-06-30 05:07:58 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:07:58 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:07:58 --> Final output sent to browser
DEBUG - 2025-06-30 05:07:58 --> Total execution time: 0.1358
INFO - 2025-06-30 05:07:58 --> Config Class Initialized
INFO - 2025-06-30 05:07:58 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:07:58 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:58 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:58 --> URI Class Initialized
INFO - 2025-06-30 05:07:58 --> Config Class Initialized
INFO - 2025-06-30 05:07:58 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:07:58 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:58 --> Router Class Initialized
INFO - 2025-06-30 05:07:58 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:58 --> Output Class Initialized
INFO - 2025-06-30 05:07:58 --> URI Class Initialized
INFO - 2025-06-30 05:07:58 --> Security Class Initialized
INFO - 2025-06-30 05:07:58 --> Router Class Initialized
DEBUG - 2025-06-30 05:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:07:58 --> Input Class Initialized
INFO - 2025-06-30 05:07:58 --> Output Class Initialized
INFO - 2025-06-30 05:07:58 --> Language Class Initialized
INFO - 2025-06-30 05:07:58 --> Security Class Initialized
DEBUG - 2025-06-30 05:07:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2025-06-30 05:07:58 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:07:58 --> Input Class Initialized
INFO - 2025-06-30 05:07:58 --> Language Class Initialized
ERROR - 2025-06-30 05:07:58 --> 404 Page Not Found: Faviconico/index
INFO - 2025-06-30 05:07:58 --> Config Class Initialized
INFO - 2025-06-30 05:07:58 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:07:58 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:58 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:58 --> URI Class Initialized
INFO - 2025-06-30 05:07:58 --> Router Class Initialized
INFO - 2025-06-30 05:07:58 --> Output Class Initialized
INFO - 2025-06-30 05:07:58 --> Security Class Initialized
DEBUG - 2025-06-30 05:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:07:58 --> Input Class Initialized
INFO - 2025-06-30 05:07:58 --> Language Class Initialized
INFO - 2025-06-30 05:07:58 --> Loader Class Initialized
INFO - 2025-06-30 05:07:58 --> Helper loaded: url_helper
INFO - 2025-06-30 05:07:58 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:07:58 --> Controller Class Initialized
INFO - 2025-06-30 05:07:58 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:07:58 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:07:58 --> Final output sent to browser
DEBUG - 2025-06-30 05:07:58 --> Total execution time: 0.0951
INFO - 2025-06-30 05:07:58 --> Config Class Initialized
INFO - 2025-06-30 05:07:58 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:07:58 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:58 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:58 --> URI Class Initialized
INFO - 2025-06-30 05:07:58 --> Config Class Initialized
INFO - 2025-06-30 05:07:58 --> Router Class Initialized
INFO - 2025-06-30 05:07:58 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:07:58 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:07:58 --> Output Class Initialized
INFO - 2025-06-30 05:07:58 --> Utf8 Class Initialized
INFO - 2025-06-30 05:07:58 --> URI Class Initialized
INFO - 2025-06-30 05:07:58 --> Security Class Initialized
DEBUG - 2025-06-30 05:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:07:58 --> Router Class Initialized
INFO - 2025-06-30 05:07:58 --> Input Class Initialized
INFO - 2025-06-30 05:07:58 --> Output Class Initialized
INFO - 2025-06-30 05:07:58 --> Language Class Initialized
ERROR - 2025-06-30 05:07:58 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:07:58 --> Security Class Initialized
DEBUG - 2025-06-30 05:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:07:58 --> Input Class Initialized
INFO - 2025-06-30 05:07:58 --> Language Class Initialized
ERROR - 2025-06-30 05:07:58 --> 404 Page Not Found: Faviconico/index
INFO - 2025-06-30 05:08:13 --> Config Class Initialized
INFO - 2025-06-30 05:08:13 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:08:13 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:08:13 --> Utf8 Class Initialized
INFO - 2025-06-30 05:08:13 --> URI Class Initialized
INFO - 2025-06-30 05:08:13 --> Router Class Initialized
INFO - 2025-06-30 05:08:13 --> Output Class Initialized
INFO - 2025-06-30 05:08:13 --> Security Class Initialized
DEBUG - 2025-06-30 05:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:08:13 --> Input Class Initialized
INFO - 2025-06-30 05:08:13 --> Language Class Initialized
INFO - 2025-06-30 05:08:13 --> Loader Class Initialized
INFO - 2025-06-30 05:08:13 --> Helper loaded: url_helper
INFO - 2025-06-30 05:08:13 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:08:13 --> Controller Class Initialized
INFO - 2025-06-30 05:08:13 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:08:13 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:08:13 --> Final output sent to browser
DEBUG - 2025-06-30 05:08:13 --> Total execution time: 0.2931
INFO - 2025-06-30 05:08:13 --> Config Class Initialized
INFO - 2025-06-30 05:08:13 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:08:13 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:08:13 --> Utf8 Class Initialized
INFO - 2025-06-30 05:08:13 --> URI Class Initialized
INFO - 2025-06-30 05:08:13 --> Router Class Initialized
INFO - 2025-06-30 05:08:13 --> Output Class Initialized
INFO - 2025-06-30 05:08:13 --> Security Class Initialized
DEBUG - 2025-06-30 05:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:08:13 --> Input Class Initialized
INFO - 2025-06-30 05:08:13 --> Language Class Initialized
ERROR - 2025-06-30 05:08:13 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:08:14 --> Config Class Initialized
INFO - 2025-06-30 05:08:14 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:08:14 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:08:14 --> Utf8 Class Initialized
INFO - 2025-06-30 05:08:14 --> URI Class Initialized
INFO - 2025-06-30 05:08:14 --> Router Class Initialized
INFO - 2025-06-30 05:08:14 --> Output Class Initialized
INFO - 2025-06-30 05:08:14 --> Security Class Initialized
DEBUG - 2025-06-30 05:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:08:14 --> Input Class Initialized
INFO - 2025-06-30 05:08:14 --> Language Class Initialized
INFO - 2025-06-30 05:08:14 --> Loader Class Initialized
INFO - 2025-06-30 05:08:14 --> Helper loaded: url_helper
INFO - 2025-06-30 05:08:14 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:08:14 --> Controller Class Initialized
INFO - 2025-06-30 05:08:14 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:08:14 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:08:14 --> Final output sent to browser
DEBUG - 2025-06-30 05:08:14 --> Total execution time: 0.1107
INFO - 2025-06-30 05:08:14 --> Config Class Initialized
INFO - 2025-06-30 05:08:14 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:08:14 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:08:14 --> Utf8 Class Initialized
INFO - 2025-06-30 05:08:14 --> URI Class Initialized
INFO - 2025-06-30 05:08:14 --> Router Class Initialized
INFO - 2025-06-30 05:08:14 --> Output Class Initialized
INFO - 2025-06-30 05:08:14 --> Security Class Initialized
DEBUG - 2025-06-30 05:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:08:14 --> Input Class Initialized
INFO - 2025-06-30 05:08:14 --> Language Class Initialized
ERROR - 2025-06-30 05:08:14 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:08:15 --> Config Class Initialized
INFO - 2025-06-30 05:08:15 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:08:15 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:08:15 --> Utf8 Class Initialized
INFO - 2025-06-30 05:08:15 --> URI Class Initialized
INFO - 2025-06-30 05:08:15 --> Router Class Initialized
INFO - 2025-06-30 05:08:15 --> Output Class Initialized
INFO - 2025-06-30 05:08:15 --> Security Class Initialized
DEBUG - 2025-06-30 05:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:08:15 --> Input Class Initialized
INFO - 2025-06-30 05:08:15 --> Language Class Initialized
INFO - 2025-06-30 05:08:15 --> Loader Class Initialized
INFO - 2025-06-30 05:08:15 --> Helper loaded: url_helper
INFO - 2025-06-30 05:08:15 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:08:15 --> Controller Class Initialized
INFO - 2025-06-30 05:08:15 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:08:15 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:08:15 --> Final output sent to browser
DEBUG - 2025-06-30 05:08:15 --> Total execution time: 0.1096
INFO - 2025-06-30 05:08:15 --> Config Class Initialized
INFO - 2025-06-30 05:08:15 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:08:15 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:08:15 --> Utf8 Class Initialized
INFO - 2025-06-30 05:08:15 --> URI Class Initialized
INFO - 2025-06-30 05:08:15 --> Router Class Initialized
INFO - 2025-06-30 05:08:15 --> Output Class Initialized
INFO - 2025-06-30 05:08:15 --> Security Class Initialized
DEBUG - 2025-06-30 05:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:08:15 --> Input Class Initialized
INFO - 2025-06-30 05:08:15 --> Language Class Initialized
ERROR - 2025-06-30 05:08:15 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:10:23 --> Config Class Initialized
INFO - 2025-06-30 05:10:23 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:10:23 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:10:23 --> Utf8 Class Initialized
INFO - 2025-06-30 05:10:23 --> URI Class Initialized
INFO - 2025-06-30 05:10:23 --> Router Class Initialized
INFO - 2025-06-30 05:10:23 --> Output Class Initialized
INFO - 2025-06-30 05:10:23 --> Security Class Initialized
DEBUG - 2025-06-30 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:10:23 --> Input Class Initialized
INFO - 2025-06-30 05:10:23 --> Language Class Initialized
INFO - 2025-06-30 05:10:23 --> Loader Class Initialized
INFO - 2025-06-30 05:10:23 --> Helper loaded: url_helper
INFO - 2025-06-30 05:10:23 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:10:23 --> Controller Class Initialized
INFO - 2025-06-30 05:10:23 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:10:23 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:10:23 --> Final output sent to browser
DEBUG - 2025-06-30 05:10:23 --> Total execution time: 0.1411
INFO - 2025-06-30 05:10:23 --> Config Class Initialized
INFO - 2025-06-30 05:10:23 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:10:23 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:10:23 --> Utf8 Class Initialized
INFO - 2025-06-30 05:10:23 --> URI Class Initialized
INFO - 2025-06-30 05:10:23 --> Router Class Initialized
INFO - 2025-06-30 05:10:23 --> Output Class Initialized
INFO - 2025-06-30 05:10:23 --> Security Class Initialized
DEBUG - 2025-06-30 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:10:23 --> Input Class Initialized
INFO - 2025-06-30 05:10:23 --> Language Class Initialized
ERROR - 2025-06-30 05:10:23 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:10:36 --> Config Class Initialized
INFO - 2025-06-30 05:10:36 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:10:36 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:10:36 --> Utf8 Class Initialized
INFO - 2025-06-30 05:10:36 --> URI Class Initialized
INFO - 2025-06-30 05:10:36 --> Router Class Initialized
INFO - 2025-06-30 05:10:36 --> Output Class Initialized
INFO - 2025-06-30 05:10:36 --> Security Class Initialized
DEBUG - 2025-06-30 05:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:10:36 --> Input Class Initialized
INFO - 2025-06-30 05:10:36 --> Language Class Initialized
INFO - 2025-06-30 05:10:36 --> Loader Class Initialized
INFO - 2025-06-30 05:10:36 --> Helper loaded: url_helper
INFO - 2025-06-30 05:10:36 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:10:36 --> Controller Class Initialized
INFO - 2025-06-30 05:10:36 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:10:36 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:10:36 --> Final output sent to browser
DEBUG - 2025-06-30 05:10:36 --> Total execution time: 0.1387
INFO - 2025-06-30 05:10:36 --> Config Class Initialized
INFO - 2025-06-30 05:10:36 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:10:36 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:10:36 --> Utf8 Class Initialized
INFO - 2025-06-30 05:10:36 --> URI Class Initialized
INFO - 2025-06-30 05:10:36 --> Router Class Initialized
INFO - 2025-06-30 05:10:36 --> Output Class Initialized
INFO - 2025-06-30 05:10:36 --> Security Class Initialized
DEBUG - 2025-06-30 05:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:10:36 --> Input Class Initialized
INFO - 2025-06-30 05:10:36 --> Language Class Initialized
ERROR - 2025-06-30 05:10:36 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:10:42 --> Config Class Initialized
INFO - 2025-06-30 05:10:42 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:10:42 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:10:42 --> Utf8 Class Initialized
INFO - 2025-06-30 05:10:42 --> URI Class Initialized
INFO - 2025-06-30 05:10:42 --> Router Class Initialized
INFO - 2025-06-30 05:10:42 --> Output Class Initialized
INFO - 2025-06-30 05:10:42 --> Security Class Initialized
DEBUG - 2025-06-30 05:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:10:42 --> Input Class Initialized
INFO - 2025-06-30 05:10:42 --> Language Class Initialized
INFO - 2025-06-30 05:10:42 --> Loader Class Initialized
INFO - 2025-06-30 05:10:42 --> Helper loaded: url_helper
INFO - 2025-06-30 05:10:42 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:10:42 --> Controller Class Initialized
INFO - 2025-06-30 05:10:42 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:10:42 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:10:42 --> Final output sent to browser
DEBUG - 2025-06-30 05:10:42 --> Total execution time: 0.1359
INFO - 2025-06-30 05:10:42 --> Config Class Initialized
INFO - 2025-06-30 05:10:42 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:10:42 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:10:42 --> Utf8 Class Initialized
INFO - 2025-06-30 05:10:42 --> URI Class Initialized
INFO - 2025-06-30 05:10:42 --> Config Class Initialized
INFO - 2025-06-30 05:10:42 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:10:42 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:10:42 --> Router Class Initialized
INFO - 2025-06-30 05:10:42 --> Utf8 Class Initialized
INFO - 2025-06-30 05:10:42 --> Output Class Initialized
INFO - 2025-06-30 05:10:42 --> URI Class Initialized
INFO - 2025-06-30 05:10:42 --> Security Class Initialized
INFO - 2025-06-30 05:10:42 --> Router Class Initialized
DEBUG - 2025-06-30 05:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:10:42 --> Input Class Initialized
INFO - 2025-06-30 05:10:42 --> Output Class Initialized
INFO - 2025-06-30 05:10:42 --> Security Class Initialized
INFO - 2025-06-30 05:10:42 --> Language Class Initialized
DEBUG - 2025-06-30 05:10:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2025-06-30 05:10:42 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:10:42 --> Input Class Initialized
INFO - 2025-06-30 05:10:42 --> Language Class Initialized
ERROR - 2025-06-30 05:10:42 --> 404 Page Not Found: Faviconico/index
INFO - 2025-06-30 05:12:22 --> Config Class Initialized
INFO - 2025-06-30 05:12:22 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:22 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:22 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:22 --> URI Class Initialized
INFO - 2025-06-30 05:12:22 --> Router Class Initialized
INFO - 2025-06-30 05:12:22 --> Output Class Initialized
INFO - 2025-06-30 05:12:22 --> Security Class Initialized
DEBUG - 2025-06-30 05:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:22 --> Input Class Initialized
INFO - 2025-06-30 05:12:22 --> Language Class Initialized
INFO - 2025-06-30 05:12:22 --> Loader Class Initialized
INFO - 2025-06-30 05:12:22 --> Helper loaded: url_helper
INFO - 2025-06-30 05:12:22 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:12:22 --> Controller Class Initialized
INFO - 2025-06-30 05:12:22 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:12:22 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:12:22 --> Final output sent to browser
DEBUG - 2025-06-30 05:12:22 --> Total execution time: 0.2501
INFO - 2025-06-30 05:12:22 --> Config Class Initialized
INFO - 2025-06-30 05:12:22 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:22 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:22 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:22 --> URI Class Initialized
INFO - 2025-06-30 05:12:22 --> Router Class Initialized
INFO - 2025-06-30 05:12:22 --> Output Class Initialized
INFO - 2025-06-30 05:12:22 --> Security Class Initialized
DEBUG - 2025-06-30 05:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:22 --> Input Class Initialized
INFO - 2025-06-30 05:12:22 --> Language Class Initialized
ERROR - 2025-06-30 05:12:22 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:12:23 --> Config Class Initialized
INFO - 2025-06-30 05:12:23 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:23 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:23 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:23 --> URI Class Initialized
INFO - 2025-06-30 05:12:23 --> Router Class Initialized
INFO - 2025-06-30 05:12:23 --> Output Class Initialized
INFO - 2025-06-30 05:12:23 --> Security Class Initialized
DEBUG - 2025-06-30 05:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:23 --> Input Class Initialized
INFO - 2025-06-30 05:12:23 --> Language Class Initialized
INFO - 2025-06-30 05:12:23 --> Loader Class Initialized
INFO - 2025-06-30 05:12:23 --> Helper loaded: url_helper
INFO - 2025-06-30 05:12:23 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:12:23 --> Controller Class Initialized
INFO - 2025-06-30 05:12:23 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:12:23 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:12:23 --> Final output sent to browser
DEBUG - 2025-06-30 05:12:23 --> Total execution time: 0.1016
INFO - 2025-06-30 05:12:23 --> Config Class Initialized
INFO - 2025-06-30 05:12:23 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:23 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:23 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:23 --> URI Class Initialized
INFO - 2025-06-30 05:12:23 --> Router Class Initialized
INFO - 2025-06-30 05:12:23 --> Output Class Initialized
INFO - 2025-06-30 05:12:23 --> Security Class Initialized
DEBUG - 2025-06-30 05:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:23 --> Input Class Initialized
INFO - 2025-06-30 05:12:23 --> Language Class Initialized
ERROR - 2025-06-30 05:12:23 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:12:25 --> Config Class Initialized
INFO - 2025-06-30 05:12:25 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:25 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:25 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:25 --> URI Class Initialized
INFO - 2025-06-30 05:12:25 --> Router Class Initialized
INFO - 2025-06-30 05:12:25 --> Output Class Initialized
INFO - 2025-06-30 05:12:25 --> Security Class Initialized
DEBUG - 2025-06-30 05:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:25 --> Input Class Initialized
INFO - 2025-06-30 05:12:25 --> Language Class Initialized
INFO - 2025-06-30 05:12:25 --> Loader Class Initialized
INFO - 2025-06-30 05:12:25 --> Helper loaded: url_helper
INFO - 2025-06-30 05:12:25 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:12:25 --> Controller Class Initialized
INFO - 2025-06-30 05:12:25 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:12:25 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:12:25 --> Final output sent to browser
DEBUG - 2025-06-30 05:12:25 --> Total execution time: 0.1300
INFO - 2025-06-30 05:12:25 --> Config Class Initialized
INFO - 2025-06-30 05:12:25 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:25 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:25 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:25 --> URI Class Initialized
INFO - 2025-06-30 05:12:25 --> Config Class Initialized
INFO - 2025-06-30 05:12:25 --> Hooks Class Initialized
INFO - 2025-06-30 05:12:25 --> Router Class Initialized
DEBUG - 2025-06-30 05:12:25 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:25 --> Output Class Initialized
INFO - 2025-06-30 05:12:25 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:25 --> URI Class Initialized
INFO - 2025-06-30 05:12:25 --> Security Class Initialized
DEBUG - 2025-06-30 05:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:25 --> Router Class Initialized
INFO - 2025-06-30 05:12:25 --> Input Class Initialized
INFO - 2025-06-30 05:12:25 --> Output Class Initialized
INFO - 2025-06-30 05:12:25 --> Language Class Initialized
INFO - 2025-06-30 05:12:25 --> Security Class Initialized
ERROR - 2025-06-30 05:12:25 --> 404 Page Not Found: Well-known/appspecific
DEBUG - 2025-06-30 05:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:25 --> Input Class Initialized
INFO - 2025-06-30 05:12:25 --> Language Class Initialized
ERROR - 2025-06-30 05:12:25 --> 404 Page Not Found: Faviconico/index
INFO - 2025-06-30 05:12:25 --> Config Class Initialized
INFO - 2025-06-30 05:12:25 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:25 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:25 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:25 --> URI Class Initialized
INFO - 2025-06-30 05:12:25 --> Router Class Initialized
INFO - 2025-06-30 05:12:25 --> Output Class Initialized
INFO - 2025-06-30 05:12:25 --> Security Class Initialized
DEBUG - 2025-06-30 05:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:25 --> Input Class Initialized
INFO - 2025-06-30 05:12:25 --> Language Class Initialized
INFO - 2025-06-30 05:12:25 --> Loader Class Initialized
INFO - 2025-06-30 05:12:25 --> Helper loaded: url_helper
INFO - 2025-06-30 05:12:25 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:12:25 --> Controller Class Initialized
INFO - 2025-06-30 05:12:25 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:12:25 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:12:25 --> Final output sent to browser
DEBUG - 2025-06-30 05:12:25 --> Total execution time: 0.1058
INFO - 2025-06-30 05:12:25 --> Config Class Initialized
INFO - 2025-06-30 05:12:25 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:25 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:25 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:25 --> Config Class Initialized
INFO - 2025-06-30 05:12:25 --> URI Class Initialized
INFO - 2025-06-30 05:12:25 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:25 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:25 --> Router Class Initialized
INFO - 2025-06-30 05:12:25 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:25 --> URI Class Initialized
INFO - 2025-06-30 05:12:26 --> Output Class Initialized
INFO - 2025-06-30 05:12:26 --> Security Class Initialized
INFO - 2025-06-30 05:12:26 --> Router Class Initialized
DEBUG - 2025-06-30 05:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:26 --> Output Class Initialized
INFO - 2025-06-30 05:12:26 --> Input Class Initialized
INFO - 2025-06-30 05:12:26 --> Language Class Initialized
INFO - 2025-06-30 05:12:26 --> Security Class Initialized
DEBUG - 2025-06-30 05:12:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2025-06-30 05:12:26 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:12:26 --> Input Class Initialized
INFO - 2025-06-30 05:12:26 --> Language Class Initialized
ERROR - 2025-06-30 05:12:26 --> 404 Page Not Found: Faviconico/index
INFO - 2025-06-30 05:12:38 --> Config Class Initialized
INFO - 2025-06-30 05:12:38 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:38 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:38 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:38 --> URI Class Initialized
INFO - 2025-06-30 05:12:38 --> Router Class Initialized
INFO - 2025-06-30 05:12:38 --> Output Class Initialized
INFO - 2025-06-30 05:12:38 --> Security Class Initialized
DEBUG - 2025-06-30 05:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:38 --> Input Class Initialized
INFO - 2025-06-30 05:12:38 --> Language Class Initialized
INFO - 2025-06-30 05:12:38 --> Loader Class Initialized
INFO - 2025-06-30 05:12:38 --> Helper loaded: url_helper
INFO - 2025-06-30 05:12:38 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:12:38 --> Controller Class Initialized
INFO - 2025-06-30 05:12:38 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:12:38 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:12:38 --> Final output sent to browser
DEBUG - 2025-06-30 05:12:38 --> Total execution time: 0.2181
INFO - 2025-06-30 05:12:38 --> Config Class Initialized
INFO - 2025-06-30 05:12:38 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:38 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:38 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:38 --> URI Class Initialized
INFO - 2025-06-30 05:12:38 --> Router Class Initialized
INFO - 2025-06-30 05:12:38 --> Output Class Initialized
INFO - 2025-06-30 05:12:38 --> Security Class Initialized
DEBUG - 2025-06-30 05:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:38 --> Input Class Initialized
INFO - 2025-06-30 05:12:38 --> Language Class Initialized
ERROR - 2025-06-30 05:12:38 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:12:50 --> Config Class Initialized
INFO - 2025-06-30 05:12:50 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:50 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:50 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:50 --> URI Class Initialized
INFO - 2025-06-30 05:12:50 --> Router Class Initialized
INFO - 2025-06-30 05:12:50 --> Output Class Initialized
INFO - 2025-06-30 05:12:50 --> Security Class Initialized
DEBUG - 2025-06-30 05:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:50 --> Input Class Initialized
INFO - 2025-06-30 05:12:50 --> Language Class Initialized
INFO - 2025-06-30 05:12:50 --> Loader Class Initialized
INFO - 2025-06-30 05:12:50 --> Helper loaded: url_helper
INFO - 2025-06-30 05:12:50 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:12:50 --> Controller Class Initialized
INFO - 2025-06-30 05:12:50 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:12:50 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:12:50 --> Final output sent to browser
DEBUG - 2025-06-30 05:12:50 --> Total execution time: 0.1694
INFO - 2025-06-30 05:12:50 --> Config Class Initialized
INFO - 2025-06-30 05:12:50 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:12:50 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:12:50 --> Utf8 Class Initialized
INFO - 2025-06-30 05:12:50 --> URI Class Initialized
INFO - 2025-06-30 05:12:50 --> Router Class Initialized
INFO - 2025-06-30 05:12:50 --> Output Class Initialized
INFO - 2025-06-30 05:12:50 --> Security Class Initialized
DEBUG - 2025-06-30 05:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:12:50 --> Input Class Initialized
INFO - 2025-06-30 05:12:50 --> Language Class Initialized
ERROR - 2025-06-30 05:12:50 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:15:02 --> Config Class Initialized
INFO - 2025-06-30 05:15:02 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:15:02 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:15:02 --> Utf8 Class Initialized
INFO - 2025-06-30 05:15:02 --> URI Class Initialized
INFO - 2025-06-30 05:15:02 --> Router Class Initialized
INFO - 2025-06-30 05:15:02 --> Output Class Initialized
INFO - 2025-06-30 05:15:02 --> Security Class Initialized
DEBUG - 2025-06-30 05:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:15:02 --> Input Class Initialized
INFO - 2025-06-30 05:15:02 --> Language Class Initialized
INFO - 2025-06-30 05:15:02 --> Loader Class Initialized
INFO - 2025-06-30 05:15:02 --> Helper loaded: url_helper
INFO - 2025-06-30 05:15:02 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:15:02 --> Controller Class Initialized
INFO - 2025-06-30 05:15:02 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:15:02 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:15:02 --> Final output sent to browser
DEBUG - 2025-06-30 05:15:02 --> Total execution time: 0.1139
INFO - 2025-06-30 05:15:02 --> Config Class Initialized
INFO - 2025-06-30 05:15:02 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:15:02 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:15:02 --> Utf8 Class Initialized
INFO - 2025-06-30 05:15:02 --> URI Class Initialized
INFO - 2025-06-30 05:15:02 --> Router Class Initialized
INFO - 2025-06-30 05:15:02 --> Output Class Initialized
INFO - 2025-06-30 05:15:02 --> Security Class Initialized
DEBUG - 2025-06-30 05:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:15:02 --> Input Class Initialized
INFO - 2025-06-30 05:15:02 --> Language Class Initialized
ERROR - 2025-06-30 05:15:02 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:15:03 --> Config Class Initialized
INFO - 2025-06-30 05:15:03 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:15:03 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:15:03 --> Utf8 Class Initialized
INFO - 2025-06-30 05:15:03 --> URI Class Initialized
INFO - 2025-06-30 05:15:03 --> Router Class Initialized
INFO - 2025-06-30 05:15:03 --> Output Class Initialized
INFO - 2025-06-30 05:15:03 --> Security Class Initialized
DEBUG - 2025-06-30 05:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:15:03 --> Input Class Initialized
INFO - 2025-06-30 05:15:03 --> Language Class Initialized
INFO - 2025-06-30 05:15:03 --> Loader Class Initialized
INFO - 2025-06-30 05:15:03 --> Helper loaded: url_helper
INFO - 2025-06-30 05:15:03 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:15:03 --> Controller Class Initialized
INFO - 2025-06-30 05:15:03 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:15:03 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:15:03 --> Final output sent to browser
DEBUG - 2025-06-30 05:15:03 --> Total execution time: 0.0878
INFO - 2025-06-30 05:15:03 --> Config Class Initialized
INFO - 2025-06-30 05:15:03 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:15:03 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:15:03 --> Utf8 Class Initialized
INFO - 2025-06-30 05:15:03 --> URI Class Initialized
INFO - 2025-06-30 05:15:03 --> Router Class Initialized
INFO - 2025-06-30 05:15:03 --> Output Class Initialized
INFO - 2025-06-30 05:15:03 --> Security Class Initialized
DEBUG - 2025-06-30 05:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:15:03 --> Input Class Initialized
INFO - 2025-06-30 05:15:03 --> Language Class Initialized
ERROR - 2025-06-30 05:15:03 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:15:07 --> Config Class Initialized
INFO - 2025-06-30 05:15:07 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:15:07 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:15:07 --> Utf8 Class Initialized
INFO - 2025-06-30 05:15:07 --> URI Class Initialized
INFO - 2025-06-30 05:15:07 --> Router Class Initialized
INFO - 2025-06-30 05:15:07 --> Output Class Initialized
INFO - 2025-06-30 05:15:07 --> Security Class Initialized
DEBUG - 2025-06-30 05:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:15:07 --> Input Class Initialized
INFO - 2025-06-30 05:15:07 --> Language Class Initialized
INFO - 2025-06-30 05:15:07 --> Loader Class Initialized
INFO - 2025-06-30 05:15:07 --> Helper loaded: url_helper
INFO - 2025-06-30 05:15:07 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:15:07 --> Controller Class Initialized
INFO - 2025-06-30 05:15:07 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:15:07 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:15:07 --> Final output sent to browser
DEBUG - 2025-06-30 05:15:07 --> Total execution time: 0.1093
INFO - 2025-06-30 05:15:07 --> Config Class Initialized
INFO - 2025-06-30 05:15:07 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:15:07 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:15:07 --> Utf8 Class Initialized
INFO - 2025-06-30 05:15:07 --> URI Class Initialized
INFO - 2025-06-30 05:15:07 --> Router Class Initialized
INFO - 2025-06-30 05:15:07 --> Output Class Initialized
INFO - 2025-06-30 05:15:07 --> Security Class Initialized
DEBUG - 2025-06-30 05:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:15:07 --> Input Class Initialized
INFO - 2025-06-30 05:15:07 --> Language Class Initialized
ERROR - 2025-06-30 05:15:07 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:15:36 --> Config Class Initialized
INFO - 2025-06-30 05:15:36 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:15:36 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:15:36 --> Utf8 Class Initialized
INFO - 2025-06-30 05:15:36 --> URI Class Initialized
INFO - 2025-06-30 05:15:36 --> Router Class Initialized
INFO - 2025-06-30 05:15:36 --> Output Class Initialized
INFO - 2025-06-30 05:15:36 --> Security Class Initialized
DEBUG - 2025-06-30 05:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:15:36 --> Input Class Initialized
INFO - 2025-06-30 05:15:36 --> Language Class Initialized
INFO - 2025-06-30 05:15:36 --> Loader Class Initialized
INFO - 2025-06-30 05:15:36 --> Helper loaded: url_helper
INFO - 2025-06-30 05:15:36 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:15:36 --> Controller Class Initialized
INFO - 2025-06-30 05:15:36 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:15:36 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:15:36 --> Final output sent to browser
DEBUG - 2025-06-30 05:15:36 --> Total execution time: 0.2022
INFO - 2025-06-30 05:15:36 --> Config Class Initialized
INFO - 2025-06-30 05:15:36 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:15:36 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:15:36 --> Utf8 Class Initialized
INFO - 2025-06-30 05:15:36 --> URI Class Initialized
INFO - 2025-06-30 05:15:36 --> Router Class Initialized
INFO - 2025-06-30 05:15:36 --> Output Class Initialized
INFO - 2025-06-30 05:15:36 --> Security Class Initialized
DEBUG - 2025-06-30 05:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:15:36 --> Input Class Initialized
INFO - 2025-06-30 05:15:36 --> Language Class Initialized
ERROR - 2025-06-30 05:15:36 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:15:37 --> Config Class Initialized
INFO - 2025-06-30 05:15:37 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:15:37 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:15:37 --> Utf8 Class Initialized
INFO - 2025-06-30 05:15:37 --> URI Class Initialized
INFO - 2025-06-30 05:15:37 --> Router Class Initialized
INFO - 2025-06-30 05:15:37 --> Output Class Initialized
INFO - 2025-06-30 05:15:37 --> Security Class Initialized
DEBUG - 2025-06-30 05:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:15:37 --> Input Class Initialized
INFO - 2025-06-30 05:15:37 --> Language Class Initialized
INFO - 2025-06-30 05:15:37 --> Loader Class Initialized
INFO - 2025-06-30 05:15:37 --> Helper loaded: url_helper
INFO - 2025-06-30 05:15:37 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:15:37 --> Controller Class Initialized
INFO - 2025-06-30 05:15:37 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:15:37 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:15:37 --> Final output sent to browser
DEBUG - 2025-06-30 05:15:37 --> Total execution time: 0.1227
INFO - 2025-06-30 05:15:37 --> Config Class Initialized
INFO - 2025-06-30 05:15:37 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:15:37 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:15:37 --> Utf8 Class Initialized
INFO - 2025-06-30 05:15:37 --> URI Class Initialized
INFO - 2025-06-30 05:15:37 --> Router Class Initialized
INFO - 2025-06-30 05:15:37 --> Output Class Initialized
INFO - 2025-06-30 05:15:37 --> Security Class Initialized
DEBUG - 2025-06-30 05:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:15:37 --> Input Class Initialized
INFO - 2025-06-30 05:15:37 --> Language Class Initialized
ERROR - 2025-06-30 05:15:37 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:16:10 --> Config Class Initialized
INFO - 2025-06-30 05:16:10 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:16:10 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:16:10 --> Utf8 Class Initialized
INFO - 2025-06-30 05:16:10 --> URI Class Initialized
INFO - 2025-06-30 05:16:10 --> Router Class Initialized
INFO - 2025-06-30 05:16:10 --> Output Class Initialized
INFO - 2025-06-30 05:16:10 --> Security Class Initialized
DEBUG - 2025-06-30 05:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:16:10 --> Input Class Initialized
INFO - 2025-06-30 05:16:10 --> Language Class Initialized
INFO - 2025-06-30 05:16:10 --> Loader Class Initialized
INFO - 2025-06-30 05:16:10 --> Helper loaded: url_helper
INFO - 2025-06-30 05:16:10 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:16:10 --> Controller Class Initialized
INFO - 2025-06-30 05:16:10 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:16:10 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:16:10 --> Final output sent to browser
DEBUG - 2025-06-30 05:16:10 --> Total execution time: 0.1498
INFO - 2025-06-30 05:47:24 --> Config Class Initialized
INFO - 2025-06-30 05:47:24 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:47:24 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:47:24 --> Utf8 Class Initialized
INFO - 2025-06-30 05:47:24 --> URI Class Initialized
INFO - 2025-06-30 05:47:24 --> Router Class Initialized
INFO - 2025-06-30 05:47:24 --> Output Class Initialized
INFO - 2025-06-30 05:47:24 --> Security Class Initialized
DEBUG - 2025-06-30 05:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:47:24 --> Input Class Initialized
INFO - 2025-06-30 05:47:24 --> Language Class Initialized
INFO - 2025-06-30 05:47:24 --> Loader Class Initialized
INFO - 2025-06-30 05:47:24 --> Helper loaded: url_helper
INFO - 2025-06-30 05:47:24 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:47:24 --> Controller Class Initialized
INFO - 2025-06-30 05:47:24 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:47:24 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:47:24 --> Final output sent to browser
DEBUG - 2025-06-30 05:47:24 --> Total execution time: 0.1502
INFO - 2025-06-30 05:47:24 --> Config Class Initialized
INFO - 2025-06-30 05:47:24 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:47:24 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:47:24 --> Utf8 Class Initialized
INFO - 2025-06-30 05:47:24 --> URI Class Initialized
INFO - 2025-06-30 05:47:24 --> Router Class Initialized
INFO - 2025-06-30 05:47:24 --> Output Class Initialized
INFO - 2025-06-30 05:47:24 --> Security Class Initialized
DEBUG - 2025-06-30 05:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:47:24 --> Input Class Initialized
INFO - 2025-06-30 05:47:24 --> Language Class Initialized
ERROR - 2025-06-30 05:47:24 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:53:30 --> Config Class Initialized
INFO - 2025-06-30 05:53:30 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:53:30 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:53:30 --> Utf8 Class Initialized
INFO - 2025-06-30 05:53:30 --> URI Class Initialized
INFO - 2025-06-30 05:53:30 --> Router Class Initialized
INFO - 2025-06-30 05:53:30 --> Output Class Initialized
INFO - 2025-06-30 05:53:30 --> Security Class Initialized
DEBUG - 2025-06-30 05:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:53:30 --> Input Class Initialized
INFO - 2025-06-30 05:53:30 --> Language Class Initialized
INFO - 2025-06-30 05:53:30 --> Loader Class Initialized
INFO - 2025-06-30 05:53:30 --> Helper loaded: url_helper
INFO - 2025-06-30 05:53:30 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:53:30 --> Controller Class Initialized
INFO - 2025-06-30 05:53:30 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:53:30 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:53:30 --> Final output sent to browser
DEBUG - 2025-06-30 05:53:30 --> Total execution time: 0.1375
INFO - 2025-06-30 05:53:30 --> Config Class Initialized
INFO - 2025-06-30 05:53:30 --> Config Class Initialized
INFO - 2025-06-30 05:53:30 --> Hooks Class Initialized
INFO - 2025-06-30 05:53:30 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:53:30 --> UTF-8 Support Enabled
DEBUG - 2025-06-30 05:53:30 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:53:30 --> Utf8 Class Initialized
INFO - 2025-06-30 05:53:30 --> Utf8 Class Initialized
INFO - 2025-06-30 05:53:30 --> URI Class Initialized
INFO - 2025-06-30 05:53:30 --> URI Class Initialized
INFO - 2025-06-30 05:53:30 --> Router Class Initialized
INFO - 2025-06-30 05:53:30 --> Router Class Initialized
INFO - 2025-06-30 05:53:30 --> Output Class Initialized
INFO - 2025-06-30 05:53:30 --> Output Class Initialized
INFO - 2025-06-30 05:53:30 --> Security Class Initialized
INFO - 2025-06-30 05:53:30 --> Security Class Initialized
DEBUG - 2025-06-30 05:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-06-30 05:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:53:30 --> Input Class Initialized
INFO - 2025-06-30 05:53:30 --> Input Class Initialized
INFO - 2025-06-30 05:53:30 --> Language Class Initialized
INFO - 2025-06-30 05:53:30 --> Language Class Initialized
ERROR - 2025-06-30 05:53:30 --> 404 Page Not Found: Well-known/appspecific
ERROR - 2025-06-30 05:53:30 --> 404 Page Not Found: Assets/vendor
INFO - 2025-06-30 05:53:40 --> Config Class Initialized
INFO - 2025-06-30 05:53:40 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:53:40 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:53:40 --> Utf8 Class Initialized
INFO - 2025-06-30 05:53:40 --> URI Class Initialized
INFO - 2025-06-30 05:53:40 --> Router Class Initialized
INFO - 2025-06-30 05:53:40 --> Output Class Initialized
INFO - 2025-06-30 05:53:40 --> Security Class Initialized
DEBUG - 2025-06-30 05:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:53:40 --> Input Class Initialized
INFO - 2025-06-30 05:53:40 --> Language Class Initialized
ERROR - 2025-06-30 05:53:40 --> 404 Page Not Found: Assets/vendor
INFO - 2025-06-30 05:57:31 --> Config Class Initialized
INFO - 2025-06-30 05:57:31 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:57:31 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:57:31 --> Utf8 Class Initialized
INFO - 2025-06-30 05:57:31 --> URI Class Initialized
INFO - 2025-06-30 05:57:31 --> Router Class Initialized
INFO - 2025-06-30 05:57:31 --> Output Class Initialized
INFO - 2025-06-30 05:57:31 --> Security Class Initialized
DEBUG - 2025-06-30 05:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:57:31 --> Input Class Initialized
INFO - 2025-06-30 05:57:31 --> Language Class Initialized
INFO - 2025-06-30 05:57:31 --> Loader Class Initialized
INFO - 2025-06-30 05:57:31 --> Helper loaded: url_helper
INFO - 2025-06-30 05:57:31 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:57:31 --> Controller Class Initialized
INFO - 2025-06-30 05:57:31 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:57:31 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:57:31 --> Final output sent to browser
DEBUG - 2025-06-30 05:57:31 --> Total execution time: 0.1445
INFO - 2025-06-30 05:57:31 --> Config Class Initialized
INFO - 2025-06-30 05:57:31 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:57:31 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:57:31 --> Utf8 Class Initialized
INFO - 2025-06-30 05:57:31 --> URI Class Initialized
INFO - 2025-06-30 05:57:31 --> Router Class Initialized
INFO - 2025-06-30 05:57:31 --> Output Class Initialized
INFO - 2025-06-30 05:57:31 --> Security Class Initialized
DEBUG - 2025-06-30 05:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:57:31 --> Input Class Initialized
INFO - 2025-06-30 05:57:31 --> Language Class Initialized
ERROR - 2025-06-30 05:57:31 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:57:33 --> Config Class Initialized
INFO - 2025-06-30 05:57:33 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:57:33 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:57:33 --> Utf8 Class Initialized
INFO - 2025-06-30 05:57:33 --> URI Class Initialized
INFO - 2025-06-30 05:57:33 --> Router Class Initialized
INFO - 2025-06-30 05:57:33 --> Output Class Initialized
INFO - 2025-06-30 05:57:33 --> Security Class Initialized
DEBUG - 2025-06-30 05:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:57:33 --> Input Class Initialized
INFO - 2025-06-30 05:57:33 --> Language Class Initialized
INFO - 2025-06-30 05:57:33 --> Loader Class Initialized
INFO - 2025-06-30 05:57:33 --> Helper loaded: url_helper
INFO - 2025-06-30 05:57:33 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:57:33 --> Controller Class Initialized
INFO - 2025-06-30 05:57:33 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:57:33 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:57:33 --> Final output sent to browser
DEBUG - 2025-06-30 05:57:33 --> Total execution time: 0.1083
INFO - 2025-06-30 05:57:33 --> Config Class Initialized
INFO - 2025-06-30 05:57:33 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:57:33 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:57:33 --> Utf8 Class Initialized
INFO - 2025-06-30 05:57:33 --> URI Class Initialized
INFO - 2025-06-30 05:57:33 --> Router Class Initialized
INFO - 2025-06-30 05:57:33 --> Output Class Initialized
INFO - 2025-06-30 05:57:33 --> Security Class Initialized
DEBUG - 2025-06-30 05:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:57:33 --> Input Class Initialized
INFO - 2025-06-30 05:57:33 --> Language Class Initialized
ERROR - 2025-06-30 05:57:33 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:58:00 --> Config Class Initialized
INFO - 2025-06-30 05:58:00 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:58:00 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:58:00 --> Utf8 Class Initialized
INFO - 2025-06-30 05:58:00 --> URI Class Initialized
INFO - 2025-06-30 05:58:00 --> Router Class Initialized
INFO - 2025-06-30 05:58:00 --> Output Class Initialized
INFO - 2025-06-30 05:58:00 --> Security Class Initialized
DEBUG - 2025-06-30 05:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:58:00 --> Input Class Initialized
INFO - 2025-06-30 05:58:00 --> Language Class Initialized
INFO - 2025-06-30 05:58:00 --> Loader Class Initialized
INFO - 2025-06-30 05:58:00 --> Helper loaded: url_helper
INFO - 2025-06-30 05:58:00 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:58:00 --> Controller Class Initialized
INFO - 2025-06-30 05:58:00 --> Model "Medical_model" initialized
INFO - 2025-06-30 05:58:00 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 05:58:00 --> Final output sent to browser
DEBUG - 2025-06-30 05:58:00 --> Total execution time: 0.2513
INFO - 2025-06-30 05:58:00 --> Config Class Initialized
INFO - 2025-06-30 05:58:00 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:58:00 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:58:00 --> Utf8 Class Initialized
INFO - 2025-06-30 05:58:00 --> URI Class Initialized
INFO - 2025-06-30 05:58:00 --> Router Class Initialized
INFO - 2025-06-30 05:58:00 --> Output Class Initialized
INFO - 2025-06-30 05:58:00 --> Security Class Initialized
DEBUG - 2025-06-30 05:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:58:00 --> Input Class Initialized
INFO - 2025-06-30 05:58:00 --> Language Class Initialized
ERROR - 2025-06-30 05:58:01 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:58:07 --> Config Class Initialized
INFO - 2025-06-30 05:58:07 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:58:07 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:58:07 --> Utf8 Class Initialized
INFO - 2025-06-30 05:58:07 --> URI Class Initialized
INFO - 2025-06-30 05:58:07 --> Router Class Initialized
INFO - 2025-06-30 05:58:07 --> Output Class Initialized
INFO - 2025-06-30 05:58:07 --> Security Class Initialized
DEBUG - 2025-06-30 05:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:58:07 --> Input Class Initialized
INFO - 2025-06-30 05:58:07 --> Language Class Initialized
ERROR - 2025-06-30 05:58:07 --> 404 Page Not Found: Products/upload
INFO - 2025-06-30 05:58:07 --> Config Class Initialized
INFO - 2025-06-30 05:58:07 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:58:07 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:58:07 --> Utf8 Class Initialized
INFO - 2025-06-30 05:58:07 --> URI Class Initialized
INFO - 2025-06-30 05:58:07 --> Router Class Initialized
INFO - 2025-06-30 05:58:07 --> Output Class Initialized
INFO - 2025-06-30 05:58:07 --> Security Class Initialized
DEBUG - 2025-06-30 05:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:58:07 --> Input Class Initialized
INFO - 2025-06-30 05:58:07 --> Language Class Initialized
ERROR - 2025-06-30 05:58:07 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:58:11 --> Config Class Initialized
INFO - 2025-06-30 05:58:11 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:58:11 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:58:11 --> Utf8 Class Initialized
INFO - 2025-06-30 05:58:11 --> URI Class Initialized
INFO - 2025-06-30 05:58:11 --> Router Class Initialized
INFO - 2025-06-30 05:58:11 --> Output Class Initialized
INFO - 2025-06-30 05:58:11 --> Security Class Initialized
DEBUG - 2025-06-30 05:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:58:11 --> Input Class Initialized
INFO - 2025-06-30 05:58:11 --> Language Class Initialized
ERROR - 2025-06-30 05:58:11 --> 404 Page Not Found: Products/index
INFO - 2025-06-30 05:58:11 --> Config Class Initialized
INFO - 2025-06-30 05:58:11 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:58:11 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:58:11 --> Utf8 Class Initialized
INFO - 2025-06-30 05:58:11 --> URI Class Initialized
INFO - 2025-06-30 05:58:11 --> Router Class Initialized
INFO - 2025-06-30 05:58:11 --> Output Class Initialized
INFO - 2025-06-30 05:58:11 --> Security Class Initialized
DEBUG - 2025-06-30 05:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:58:11 --> Input Class Initialized
INFO - 2025-06-30 05:58:11 --> Language Class Initialized
ERROR - 2025-06-30 05:58:11 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:59:21 --> Config Class Initialized
INFO - 2025-06-30 05:59:21 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:59:21 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:59:21 --> Utf8 Class Initialized
INFO - 2025-06-30 05:59:21 --> URI Class Initialized
INFO - 2025-06-30 05:59:21 --> Router Class Initialized
INFO - 2025-06-30 05:59:21 --> Output Class Initialized
INFO - 2025-06-30 05:59:21 --> Security Class Initialized
DEBUG - 2025-06-30 05:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:59:21 --> Input Class Initialized
INFO - 2025-06-30 05:59:21 --> Language Class Initialized
INFO - 2025-06-30 05:59:22 --> Loader Class Initialized
INFO - 2025-06-30 05:59:22 --> Helper loaded: url_helper
INFO - 2025-06-30 05:59:22 --> Helper loaded: form_helper
DEBUG - 2025-06-30 05:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 05:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 05:59:22 --> Controller Class Initialized
INFO - 2025-06-30 05:59:22 --> Database Driver Class Initialized
INFO - 2025-06-30 05:59:22 --> Model "Product_search_model" initialized
INFO - 2025-06-30 05:59:22 --> Helper loaded: html_helper
INFO - 2025-06-30 05:59:22 --> Form Validation Class Initialized
ERROR - 2025-06-30 05:59:22 --> Query error: Table 'htest.medical_products' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `medical_products`
INFO - 2025-06-30 05:59:22 --> Language file loaded: language/english/db_lang.php
INFO - 2025-06-30 05:59:22 --> Config Class Initialized
INFO - 2025-06-30 05:59:22 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:59:22 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:59:22 --> Utf8 Class Initialized
INFO - 2025-06-30 05:59:22 --> URI Class Initialized
INFO - 2025-06-30 05:59:22 --> Router Class Initialized
INFO - 2025-06-30 05:59:22 --> Output Class Initialized
INFO - 2025-06-30 05:59:22 --> Security Class Initialized
DEBUG - 2025-06-30 05:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:59:22 --> Input Class Initialized
INFO - 2025-06-30 05:59:22 --> Language Class Initialized
ERROR - 2025-06-30 05:59:22 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 05:59:37 --> Config Class Initialized
INFO - 2025-06-30 05:59:37 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:59:37 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:59:37 --> Utf8 Class Initialized
INFO - 2025-06-30 05:59:37 --> Config Class Initialized
INFO - 2025-06-30 05:59:37 --> Hooks Class Initialized
DEBUG - 2025-06-30 05:59:37 --> UTF-8 Support Enabled
INFO - 2025-06-30 05:59:37 --> Utf8 Class Initialized
INFO - 2025-06-30 05:59:37 --> URI Class Initialized
INFO - 2025-06-30 05:59:37 --> Router Class Initialized
INFO - 2025-06-30 05:59:37 --> Output Class Initialized
INFO - 2025-06-30 05:59:37 --> Security Class Initialized
DEBUG - 2025-06-30 05:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 05:59:37 --> Input Class Initialized
INFO - 2025-06-30 05:59:37 --> Language Class Initialized
ERROR - 2025-06-30 05:59:37 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:02:07 --> Config Class Initialized
INFO - 2025-06-30 06:02:07 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:02:07 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:02:07 --> Utf8 Class Initialized
INFO - 2025-06-30 06:02:07 --> URI Class Initialized
DEBUG - 2025-06-30 06:02:07 --> No URI present. Default controller set.
INFO - 2025-06-30 06:02:07 --> Router Class Initialized
INFO - 2025-06-30 06:02:07 --> Output Class Initialized
INFO - 2025-06-30 06:02:07 --> Security Class Initialized
DEBUG - 2025-06-30 06:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:02:07 --> Input Class Initialized
INFO - 2025-06-30 06:02:07 --> Language Class Initialized
INFO - 2025-06-30 06:02:07 --> Loader Class Initialized
INFO - 2025-06-30 06:02:07 --> Helper loaded: url_helper
INFO - 2025-06-30 06:02:07 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:02:07 --> Controller Class Initialized
INFO - 2025-06-30 06:02:07 --> File loaded: /var/www/html/application/views/main_dashboard.php
INFO - 2025-06-30 06:02:07 --> Final output sent to browser
DEBUG - 2025-06-30 06:02:07 --> Total execution time: 0.1528
INFO - 2025-06-30 06:02:07 --> Config Class Initialized
INFO - 2025-06-30 06:02:07 --> Config Class Initialized
INFO - 2025-06-30 06:02:07 --> Hooks Class Initialized
INFO - 2025-06-30 06:02:07 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:02:07 --> UTF-8 Support Enabled
DEBUG - 2025-06-30 06:02:07 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:02:07 --> Utf8 Class Initialized
INFO - 2025-06-30 06:02:07 --> Utf8 Class Initialized
INFO - 2025-06-30 06:02:07 --> URI Class Initialized
INFO - 2025-06-30 06:02:07 --> URI Class Initialized
INFO - 2025-06-30 06:02:07 --> Router Class Initialized
INFO - 2025-06-30 06:02:07 --> Router Class Initialized
INFO - 2025-06-30 06:02:07 --> Output Class Initialized
INFO - 2025-06-30 06:02:07 --> Output Class Initialized
INFO - 2025-06-30 06:02:07 --> Security Class Initialized
INFO - 2025-06-30 06:02:07 --> Security Class Initialized
DEBUG - 2025-06-30 06:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-06-30 06:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:02:07 --> Input Class Initialized
INFO - 2025-06-30 06:02:07 --> Input Class Initialized
INFO - 2025-06-30 06:02:07 --> Language Class Initialized
INFO - 2025-06-30 06:02:07 --> Language Class Initialized
ERROR - 2025-06-30 06:02:07 --> 404 Page Not Found: Well-known/appspecific
ERROR - 2025-06-30 06:02:07 --> 404 Page Not Found: Assets/vendor
INFO - 2025-06-30 06:03:14 --> Config Class Initialized
INFO - 2025-06-30 06:03:14 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:03:14 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:03:14 --> Utf8 Class Initialized
INFO - 2025-06-30 06:03:14 --> URI Class Initialized
DEBUG - 2025-06-30 06:03:14 --> No URI present. Default controller set.
INFO - 2025-06-30 06:03:14 --> Router Class Initialized
INFO - 2025-06-30 06:03:14 --> Output Class Initialized
INFO - 2025-06-30 06:03:14 --> Security Class Initialized
DEBUG - 2025-06-30 06:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:03:14 --> Input Class Initialized
INFO - 2025-06-30 06:03:14 --> Language Class Initialized
INFO - 2025-06-30 06:03:14 --> Loader Class Initialized
INFO - 2025-06-30 06:03:14 --> Helper loaded: url_helper
INFO - 2025-06-30 06:03:14 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:03:15 --> Controller Class Initialized
INFO - 2025-06-30 06:03:15 --> File loaded: /var/www/html/application/views/main_dashboard.php
INFO - 2025-06-30 06:03:15 --> Final output sent to browser
DEBUG - 2025-06-30 06:03:15 --> Total execution time: 0.2207
INFO - 2025-06-30 06:03:15 --> Config Class Initialized
INFO - 2025-06-30 06:03:15 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:03:15 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:03:15 --> Utf8 Class Initialized
INFO - 2025-06-30 06:03:15 --> URI Class Initialized
INFO - 2025-06-30 06:03:15 --> Router Class Initialized
INFO - 2025-06-30 06:03:15 --> Output Class Initialized
INFO - 2025-06-30 06:03:15 --> Security Class Initialized
DEBUG - 2025-06-30 06:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:03:15 --> Input Class Initialized
INFO - 2025-06-30 06:03:15 --> Language Class Initialized
ERROR - 2025-06-30 06:03:15 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:03:19 --> Config Class Initialized
INFO - 2025-06-30 06:03:19 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:03:19 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:03:19 --> Utf8 Class Initialized
INFO - 2025-06-30 06:03:19 --> URI Class Initialized
INFO - 2025-06-30 06:03:19 --> Router Class Initialized
INFO - 2025-06-30 06:03:19 --> Output Class Initialized
INFO - 2025-06-30 06:03:19 --> Security Class Initialized
DEBUG - 2025-06-30 06:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:03:19 --> Input Class Initialized
INFO - 2025-06-30 06:03:19 --> Language Class Initialized
INFO - 2025-06-30 06:03:19 --> Loader Class Initialized
INFO - 2025-06-30 06:03:19 --> Helper loaded: url_helper
INFO - 2025-06-30 06:03:19 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:03:19 --> Controller Class Initialized
INFO - 2025-06-30 06:03:19 --> Database Driver Class Initialized
INFO - 2025-06-30 06:03:19 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:03:19 --> Upload Class Initialized
INFO - 2025-06-30 06:03:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:03:19 --> Pagination Class Initialized
ERROR - 2025-06-30 06:03:19 --> Query error: Table 'htest.medical_products' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `medical_products`
INFO - 2025-06-30 06:03:19 --> Language file loaded: language/english/db_lang.php
INFO - 2025-06-30 06:03:19 --> Config Class Initialized
INFO - 2025-06-30 06:03:19 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:03:19 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:03:19 --> Utf8 Class Initialized
INFO - 2025-06-30 06:03:19 --> URI Class Initialized
INFO - 2025-06-30 06:03:19 --> Router Class Initialized
INFO - 2025-06-30 06:03:19 --> Output Class Initialized
INFO - 2025-06-30 06:03:19 --> Security Class Initialized
DEBUG - 2025-06-30 06:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:03:19 --> Input Class Initialized
INFO - 2025-06-30 06:03:19 --> Language Class Initialized
ERROR - 2025-06-30 06:03:19 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:04:41 --> Config Class Initialized
INFO - 2025-06-30 06:04:41 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:04:41 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:04:41 --> Utf8 Class Initialized
INFO - 2025-06-30 06:04:41 --> URI Class Initialized
INFO - 2025-06-30 06:04:41 --> Router Class Initialized
INFO - 2025-06-30 06:04:41 --> Output Class Initialized
INFO - 2025-06-30 06:04:41 --> Security Class Initialized
DEBUG - 2025-06-30 06:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:04:41 --> Input Class Initialized
INFO - 2025-06-30 06:04:41 --> Language Class Initialized
INFO - 2025-06-30 06:04:41 --> Loader Class Initialized
INFO - 2025-06-30 06:04:41 --> Helper loaded: url_helper
INFO - 2025-06-30 06:04:41 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:04:41 --> Controller Class Initialized
INFO - 2025-06-30 06:04:41 --> Database Driver Class Initialized
INFO - 2025-06-30 06:04:41 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:04:41 --> Upload Class Initialized
INFO - 2025-06-30 06:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:04:41 --> Pagination Class Initialized
INFO - 2025-06-30 06:04:41 --> Database Forge Class Initialized
INFO - 2025-06-30 06:04:41 --> Final output sent to browser
DEBUG - 2025-06-30 06:04:41 --> Total execution time: 0.4812
INFO - 2025-06-30 06:04:41 --> Config Class Initialized
INFO - 2025-06-30 06:04:41 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:04:41 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:04:41 --> Utf8 Class Initialized
INFO - 2025-06-30 06:04:41 --> URI Class Initialized
INFO - 2025-06-30 06:04:41 --> Router Class Initialized
INFO - 2025-06-30 06:04:41 --> Output Class Initialized
INFO - 2025-06-30 06:04:41 --> Security Class Initialized
DEBUG - 2025-06-30 06:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:04:41 --> Input Class Initialized
INFO - 2025-06-30 06:04:41 --> Language Class Initialized
ERROR - 2025-06-30 06:04:41 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:04:43 --> Config Class Initialized
INFO - 2025-06-30 06:04:43 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:04:43 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:04:43 --> Utf8 Class Initialized
INFO - 2025-06-30 06:04:43 --> URI Class Initialized
INFO - 2025-06-30 06:04:43 --> Router Class Initialized
INFO - 2025-06-30 06:04:43 --> Output Class Initialized
INFO - 2025-06-30 06:04:43 --> Security Class Initialized
DEBUG - 2025-06-30 06:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:04:43 --> Input Class Initialized
INFO - 2025-06-30 06:04:43 --> Language Class Initialized
INFO - 2025-06-30 06:04:43 --> Loader Class Initialized
INFO - 2025-06-30 06:04:43 --> Helper loaded: url_helper
INFO - 2025-06-30 06:04:43 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:04:43 --> Controller Class Initialized
INFO - 2025-06-30 06:04:43 --> Database Driver Class Initialized
INFO - 2025-06-30 06:04:43 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:04:43 --> Upload Class Initialized
INFO - 2025-06-30 06:04:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:04:43 --> Pagination Class Initialized
INFO - 2025-06-30 06:04:43 --> File loaded: /var/www/html/application/views/medical_products/search_main.php
INFO - 2025-06-30 06:04:43 --> Final output sent to browser
DEBUG - 2025-06-30 06:04:43 --> Total execution time: 0.1516
INFO - 2025-06-30 06:04:44 --> Config Class Initialized
INFO - 2025-06-30 06:04:44 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:04:44 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:04:44 --> Utf8 Class Initialized
INFO - 2025-06-30 06:04:44 --> URI Class Initialized
INFO - 2025-06-30 06:04:44 --> Config Class Initialized
INFO - 2025-06-30 06:04:44 --> Hooks Class Initialized
INFO - 2025-06-30 06:04:44 --> Router Class Initialized
INFO - 2025-06-30 06:04:44 --> Output Class Initialized
DEBUG - 2025-06-30 06:04:44 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:04:44 --> Security Class Initialized
INFO - 2025-06-30 06:04:44 --> Utf8 Class Initialized
DEBUG - 2025-06-30 06:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:04:44 --> URI Class Initialized
INFO - 2025-06-30 06:04:44 --> Input Class Initialized
INFO - 2025-06-30 06:04:44 --> Language Class Initialized
INFO - 2025-06-30 06:04:44 --> Router Class Initialized
ERROR - 2025-06-30 06:04:44 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:04:44 --> Output Class Initialized
INFO - 2025-06-30 06:04:44 --> Security Class Initialized
DEBUG - 2025-06-30 06:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:04:44 --> Input Class Initialized
INFO - 2025-06-30 06:04:44 --> Language Class Initialized
ERROR - 2025-06-30 06:04:44 --> 404 Page Not Found: Assets/vendor
INFO - 2025-06-30 06:04:46 --> Config Class Initialized
INFO - 2025-06-30 06:04:46 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:04:46 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:04:46 --> Utf8 Class Initialized
INFO - 2025-06-30 06:04:46 --> URI Class Initialized
INFO - 2025-06-30 06:04:46 --> Router Class Initialized
INFO - 2025-06-30 06:04:46 --> Output Class Initialized
INFO - 2025-06-30 06:04:46 --> Security Class Initialized
DEBUG - 2025-06-30 06:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:04:46 --> Input Class Initialized
INFO - 2025-06-30 06:04:46 --> Language Class Initialized
INFO - 2025-06-30 06:04:46 --> Loader Class Initialized
INFO - 2025-06-30 06:04:46 --> Helper loaded: url_helper
INFO - 2025-06-30 06:04:46 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:04:46 --> Controller Class Initialized
INFO - 2025-06-30 06:04:46 --> Database Driver Class Initialized
INFO - 2025-06-30 06:04:46 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:04:46 --> Upload Class Initialized
INFO - 2025-06-30 06:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:04:46 --> Pagination Class Initialized
INFO - 2025-06-30 06:04:46 --> File loaded: /var/www/html/application/views/medical_products/search_main.php
INFO - 2025-06-30 06:04:46 --> Final output sent to browser
DEBUG - 2025-06-30 06:04:46 --> Total execution time: 0.1550
INFO - 2025-06-30 06:04:47 --> Config Class Initialized
INFO - 2025-06-30 06:04:47 --> Config Class Initialized
INFO - 2025-06-30 06:04:47 --> Hooks Class Initialized
INFO - 2025-06-30 06:04:47 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:04:47 --> UTF-8 Support Enabled
DEBUG - 2025-06-30 06:04:47 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:04:47 --> Utf8 Class Initialized
INFO - 2025-06-30 06:04:47 --> Utf8 Class Initialized
INFO - 2025-06-30 06:04:47 --> URI Class Initialized
INFO - 2025-06-30 06:04:47 --> URI Class Initialized
INFO - 2025-06-30 06:04:47 --> Router Class Initialized
INFO - 2025-06-30 06:04:47 --> Router Class Initialized
INFO - 2025-06-30 06:04:47 --> Output Class Initialized
INFO - 2025-06-30 06:04:47 --> Output Class Initialized
INFO - 2025-06-30 06:04:47 --> Security Class Initialized
INFO - 2025-06-30 06:04:47 --> Security Class Initialized
DEBUG - 2025-06-30 06:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-06-30 06:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:04:47 --> Input Class Initialized
INFO - 2025-06-30 06:04:47 --> Input Class Initialized
INFO - 2025-06-30 06:04:47 --> Language Class Initialized
INFO - 2025-06-30 06:04:47 --> Language Class Initialized
ERROR - 2025-06-30 06:04:47 --> 404 Page Not Found: Assets/vendor
ERROR - 2025-06-30 06:04:47 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:08:43 --> Config Class Initialized
INFO - 2025-06-30 06:08:43 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:08:43 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:08:43 --> Utf8 Class Initialized
INFO - 2025-06-30 06:08:43 --> URI Class Initialized
INFO - 2025-06-30 06:08:43 --> Router Class Initialized
INFO - 2025-06-30 06:08:43 --> Output Class Initialized
INFO - 2025-06-30 06:08:43 --> Security Class Initialized
DEBUG - 2025-06-30 06:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:08:43 --> Input Class Initialized
INFO - 2025-06-30 06:08:43 --> Language Class Initialized
INFO - 2025-06-30 06:08:43 --> Loader Class Initialized
INFO - 2025-06-30 06:08:43 --> Helper loaded: url_helper
INFO - 2025-06-30 06:08:43 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:08:43 --> Controller Class Initialized
INFO - 2025-06-30 06:08:43 --> Database Driver Class Initialized
INFO - 2025-06-30 06:08:43 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:08:43 --> Upload Class Initialized
INFO - 2025-06-30 06:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:08:43 --> Pagination Class Initialized
INFO - 2025-06-30 06:08:43 --> File loaded: /var/www/html/application/views/medical_products/index.php
INFO - 2025-06-30 06:08:43 --> Final output sent to browser
DEBUG - 2025-06-30 06:08:43 --> Total execution time: 0.2979
INFO - 2025-06-30 06:08:43 --> Config Class Initialized
INFO - 2025-06-30 06:08:43 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:08:43 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:08:43 --> Utf8 Class Initialized
INFO - 2025-06-30 06:08:43 --> URI Class Initialized
INFO - 2025-06-30 06:08:43 --> Router Class Initialized
INFO - 2025-06-30 06:08:43 --> Output Class Initialized
INFO - 2025-06-30 06:08:43 --> Security Class Initialized
DEBUG - 2025-06-30 06:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:08:43 --> Input Class Initialized
INFO - 2025-06-30 06:08:43 --> Language Class Initialized
ERROR - 2025-06-30 06:08:43 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:08:46 --> Config Class Initialized
INFO - 2025-06-30 06:08:46 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:08:46 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:08:46 --> Utf8 Class Initialized
INFO - 2025-06-30 06:08:46 --> URI Class Initialized
INFO - 2025-06-30 06:08:46 --> Router Class Initialized
INFO - 2025-06-30 06:08:46 --> Output Class Initialized
INFO - 2025-06-30 06:08:46 --> Security Class Initialized
DEBUG - 2025-06-30 06:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:08:46 --> Input Class Initialized
INFO - 2025-06-30 06:08:46 --> Language Class Initialized
INFO - 2025-06-30 06:08:46 --> Loader Class Initialized
INFO - 2025-06-30 06:08:46 --> Helper loaded: url_helper
INFO - 2025-06-30 06:08:46 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:08:46 --> Controller Class Initialized
INFO - 2025-06-30 06:08:46 --> Database Driver Class Initialized
INFO - 2025-06-30 06:08:46 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:08:46 --> Upload Class Initialized
INFO - 2025-06-30 06:08:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:08:46 --> Pagination Class Initialized
ERROR - 2025-06-30 06:08:46 --> Query error: Table 'htest.medical_products_upload_log' doesn't exist - Invalid query: SELECT *
FROM `medical_products_upload_log`
ORDER BY `created_at` DESC
 LIMIT 10
INFO - 2025-06-30 06:08:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-06-30 06:08:46 --> Config Class Initialized
INFO - 2025-06-30 06:08:46 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:08:46 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:08:46 --> Utf8 Class Initialized
INFO - 2025-06-30 06:08:46 --> URI Class Initialized
INFO - 2025-06-30 06:08:46 --> Router Class Initialized
INFO - 2025-06-30 06:08:46 --> Output Class Initialized
INFO - 2025-06-30 06:08:46 --> Security Class Initialized
DEBUG - 2025-06-30 06:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:08:46 --> Input Class Initialized
INFO - 2025-06-30 06:08:46 --> Language Class Initialized
ERROR - 2025-06-30 06:08:46 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:10:02 --> Config Class Initialized
INFO - 2025-06-30 06:10:02 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:10:02 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:10:02 --> Utf8 Class Initialized
INFO - 2025-06-30 06:10:02 --> URI Class Initialized
INFO - 2025-06-30 06:10:02 --> Router Class Initialized
INFO - 2025-06-30 06:10:02 --> Output Class Initialized
INFO - 2025-06-30 06:10:02 --> Security Class Initialized
DEBUG - 2025-06-30 06:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:10:03 --> Input Class Initialized
INFO - 2025-06-30 06:10:03 --> Language Class Initialized
INFO - 2025-06-30 06:10:03 --> Loader Class Initialized
INFO - 2025-06-30 06:10:03 --> Helper loaded: url_helper
INFO - 2025-06-30 06:10:03 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:10:03 --> Controller Class Initialized
INFO - 2025-06-30 06:10:03 --> Database Driver Class Initialized
INFO - 2025-06-30 06:10:03 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:10:03 --> Upload Class Initialized
INFO - 2025-06-30 06:10:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:10:03 --> Pagination Class Initialized
ERROR - 2025-06-30 06:10:03 --> Query error: Table 'htest.medical_products_upload_log' doesn't exist - Invalid query: SELECT *
FROM `medical_products_upload_log`
ORDER BY `created_at` DESC
 LIMIT 10
INFO - 2025-06-30 06:10:03 --> Language file loaded: language/english/db_lang.php
INFO - 2025-06-30 06:10:03 --> Config Class Initialized
INFO - 2025-06-30 06:10:03 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:10:03 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:10:03 --> Utf8 Class Initialized
INFO - 2025-06-30 06:10:03 --> URI Class Initialized
INFO - 2025-06-30 06:10:03 --> Router Class Initialized
INFO - 2025-06-30 06:10:03 --> Output Class Initialized
INFO - 2025-06-30 06:10:03 --> Security Class Initialized
DEBUG - 2025-06-30 06:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:10:03 --> Input Class Initialized
INFO - 2025-06-30 06:10:03 --> Language Class Initialized
ERROR - 2025-06-30 06:10:03 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:13:07 --> Config Class Initialized
INFO - 2025-06-30 06:13:07 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:13:07 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:13:07 --> Utf8 Class Initialized
INFO - 2025-06-30 06:13:07 --> URI Class Initialized
INFO - 2025-06-30 06:13:07 --> Router Class Initialized
INFO - 2025-06-30 06:13:07 --> Output Class Initialized
INFO - 2025-06-30 06:13:07 --> Security Class Initialized
DEBUG - 2025-06-30 06:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:13:07 --> Input Class Initialized
INFO - 2025-06-30 06:13:07 --> Language Class Initialized
INFO - 2025-06-30 06:13:07 --> Loader Class Initialized
INFO - 2025-06-30 06:13:07 --> Helper loaded: url_helper
INFO - 2025-06-30 06:13:07 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:13:07 --> Controller Class Initialized
INFO - 2025-06-30 06:13:07 --> Database Driver Class Initialized
INFO - 2025-06-30 06:13:07 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:13:07 --> Upload Class Initialized
INFO - 2025-06-30 06:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:13:07 --> Pagination Class Initialized
ERROR - 2025-06-30 06:13:07 --> Query error: Table 'htest.medical_products_upload_log' doesn't exist - Invalid query: SELECT *
FROM `medical_products_upload_log`
ORDER BY `created_at` DESC
 LIMIT 10
INFO - 2025-06-30 06:13:07 --> Language file loaded: language/english/db_lang.php
INFO - 2025-06-30 06:13:07 --> Config Class Initialized
INFO - 2025-06-30 06:13:07 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:13:07 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:13:07 --> Utf8 Class Initialized
INFO - 2025-06-30 06:13:07 --> URI Class Initialized
INFO - 2025-06-30 06:13:07 --> Router Class Initialized
INFO - 2025-06-30 06:13:07 --> Output Class Initialized
INFO - 2025-06-30 06:13:07 --> Security Class Initialized
DEBUG - 2025-06-30 06:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:13:07 --> Input Class Initialized
INFO - 2025-06-30 06:13:07 --> Language Class Initialized
ERROR - 2025-06-30 06:13:07 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:13:18 --> Config Class Initialized
INFO - 2025-06-30 06:13:18 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:13:18 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:13:18 --> Utf8 Class Initialized
INFO - 2025-06-30 06:13:18 --> URI Class Initialized
INFO - 2025-06-30 06:13:18 --> Router Class Initialized
INFO - 2025-06-30 06:13:18 --> Output Class Initialized
INFO - 2025-06-30 06:13:18 --> Security Class Initialized
DEBUG - 2025-06-30 06:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:13:18 --> Input Class Initialized
INFO - 2025-06-30 06:13:18 --> Language Class Initialized
INFO - 2025-06-30 06:13:18 --> Loader Class Initialized
INFO - 2025-06-30 06:13:18 --> Helper loaded: url_helper
INFO - 2025-06-30 06:13:18 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:13:18 --> Controller Class Initialized
INFO - 2025-06-30 06:13:18 --> Database Driver Class Initialized
INFO - 2025-06-30 06:13:18 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:13:18 --> Upload Class Initialized
INFO - 2025-06-30 06:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:13:18 --> Pagination Class Initialized
INFO - 2025-06-30 06:13:18 --> Database Forge Class Initialized
INFO - 2025-06-30 06:13:18 --> Database Forge Class Initialized
ERROR - 2025-06-30 06:13:18 --> Query error: Invalid default value for 'created_at' - Invalid query: CREATE TABLE IF NOT EXISTS `medical_products_upload_log` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`filename` VARCHAR(255) NOT NULL,
	`status` ENUM('processing','completed','failed') NOT NULL DEFAULT 'processing',
	`total_rows` INT(11) NOT NULL DEFAULT 0,
	`success_rows` INT(11) NOT NULL DEFAULT 0,
	`failed_rows` INT(11) NOT NULL DEFAULT 0,
	`error_message` TEXT NULL,
	`start_time` DATETIME NULL,
	`end_time` DATETIME NULL,
	`created_at` DATETIME NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_medical_products_upload_log` PRIMARY KEY(`id`),
	KEY `created_at` (`created_at`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
INFO - 2025-06-30 06:13:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-06-30 06:15:41 --> Config Class Initialized
INFO - 2025-06-30 06:15:41 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:15:41 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:15:41 --> Utf8 Class Initialized
INFO - 2025-06-30 06:15:41 --> URI Class Initialized
INFO - 2025-06-30 06:15:41 --> Router Class Initialized
INFO - 2025-06-30 06:15:41 --> Output Class Initialized
INFO - 2025-06-30 06:15:41 --> Security Class Initialized
DEBUG - 2025-06-30 06:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:15:41 --> Input Class Initialized
INFO - 2025-06-30 06:15:41 --> Language Class Initialized
INFO - 2025-06-30 06:15:41 --> Loader Class Initialized
INFO - 2025-06-30 06:15:41 --> Helper loaded: url_helper
INFO - 2025-06-30 06:15:41 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:15:41 --> Controller Class Initialized
INFO - 2025-06-30 06:15:41 --> Database Driver Class Initialized
INFO - 2025-06-30 06:15:41 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:15:41 --> Upload Class Initialized
INFO - 2025-06-30 06:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:15:41 --> Pagination Class Initialized
INFO - 2025-06-30 06:15:41 --> Database Forge Class Initialized
ERROR - 2025-06-30 06:15:41 --> Severity: error --> Exception: Undefined constant "CURRENT_TIMESTAMP" /var/www/html/application/controllers/Medical_products.php 554
INFO - 2025-06-30 06:16:40 --> Config Class Initialized
INFO - 2025-06-30 06:16:40 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:16:40 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:16:40 --> Utf8 Class Initialized
INFO - 2025-06-30 06:16:40 --> URI Class Initialized
INFO - 2025-06-30 06:16:40 --> Router Class Initialized
INFO - 2025-06-30 06:16:40 --> Output Class Initialized
INFO - 2025-06-30 06:16:40 --> Security Class Initialized
DEBUG - 2025-06-30 06:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:16:40 --> Input Class Initialized
INFO - 2025-06-30 06:16:40 --> Language Class Initialized
INFO - 2025-06-30 06:16:40 --> Loader Class Initialized
INFO - 2025-06-30 06:16:40 --> Helper loaded: url_helper
INFO - 2025-06-30 06:16:40 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:16:40 --> Controller Class Initialized
INFO - 2025-06-30 06:16:40 --> Database Driver Class Initialized
INFO - 2025-06-30 06:16:40 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:16:40 --> Upload Class Initialized
INFO - 2025-06-30 06:16:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:16:40 --> Pagination Class Initialized
INFO - 2025-06-30 06:16:40 --> Database Forge Class Initialized
INFO - 2025-06-30 06:16:40 --> Database Forge Class Initialized
ERROR - 2025-06-30 06:16:40 --> Query error: Invalid default value for 'created_at' - Invalid query: CREATE TABLE IF NOT EXISTS `medical_products_upload_log` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`filename` VARCHAR(255) NOT NULL,
	`status` ENUM('processing','completed','failed') NOT NULL DEFAULT 'processing',
	`total_rows` INT(11) NOT NULL DEFAULT 0,
	`success_rows` INT(11) NOT NULL DEFAULT 0,
	`failed_rows` INT(11) NOT NULL DEFAULT 0,
	`error_message` TEXT NULL,
	`start_time` DATETIME NULL,
	`end_time` DATETIME NULL,
	`created_at` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	`updated_at` TIMESTAMP NULL DEFAULT NULL,
	CONSTRAINT `pk_medical_products_upload_log` PRIMARY KEY(`id`),
	KEY `created_at` (`created_at`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
INFO - 2025-06-30 06:16:40 --> Language file loaded: language/english/db_lang.php
INFO - 2025-06-30 06:17:12 --> Config Class Initialized
INFO - 2025-06-30 06:17:12 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:17:12 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:17:12 --> Utf8 Class Initialized
INFO - 2025-06-30 06:17:12 --> URI Class Initialized
INFO - 2025-06-30 06:17:12 --> Router Class Initialized
INFO - 2025-06-30 06:17:12 --> Output Class Initialized
INFO - 2025-06-30 06:17:12 --> Security Class Initialized
DEBUG - 2025-06-30 06:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:17:12 --> Input Class Initialized
INFO - 2025-06-30 06:17:12 --> Language Class Initialized
INFO - 2025-06-30 06:17:12 --> Loader Class Initialized
INFO - 2025-06-30 06:17:12 --> Helper loaded: url_helper
INFO - 2025-06-30 06:17:12 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:17:12 --> Controller Class Initialized
INFO - 2025-06-30 06:17:12 --> Model "Medical_model" initialized
INFO - 2025-06-30 06:17:12 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 06:17:12 --> Final output sent to browser
DEBUG - 2025-06-30 06:17:12 --> Total execution time: 0.2802
INFO - 2025-06-30 06:17:14 --> Config Class Initialized
INFO - 2025-06-30 06:17:14 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:17:14 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:17:14 --> Utf8 Class Initialized
INFO - 2025-06-30 06:17:14 --> URI Class Initialized
INFO - 2025-06-30 06:17:14 --> Router Class Initialized
INFO - 2025-06-30 06:17:14 --> Output Class Initialized
INFO - 2025-06-30 06:17:14 --> Security Class Initialized
DEBUG - 2025-06-30 06:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:17:14 --> Input Class Initialized
INFO - 2025-06-30 06:17:14 --> Language Class Initialized
INFO - 2025-06-30 06:17:14 --> Loader Class Initialized
INFO - 2025-06-30 06:17:14 --> Helper loaded: url_helper
INFO - 2025-06-30 06:17:14 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:17:15 --> Controller Class Initialized
INFO - 2025-06-30 06:17:15 --> Database Driver Class Initialized
INFO - 2025-06-30 06:17:15 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:17:15 --> Upload Class Initialized
INFO - 2025-06-30 06:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:17:15 --> Pagination Class Initialized
ERROR - 2025-06-30 06:17:15 --> Query error: Table 'htest.medical_products_upload_log' doesn't exist - Invalid query: SELECT *
FROM `medical_products_upload_log`
ORDER BY `created_at` DESC
 LIMIT 10
INFO - 2025-06-30 06:17:15 --> Language file loaded: language/english/db_lang.php
INFO - 2025-06-30 06:17:15 --> Config Class Initialized
INFO - 2025-06-30 06:17:15 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:17:15 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:17:15 --> Utf8 Class Initialized
INFO - 2025-06-30 06:17:15 --> URI Class Initialized
INFO - 2025-06-30 06:17:15 --> Router Class Initialized
INFO - 2025-06-30 06:17:15 --> Output Class Initialized
INFO - 2025-06-30 06:17:15 --> Security Class Initialized
DEBUG - 2025-06-30 06:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:17:15 --> Input Class Initialized
INFO - 2025-06-30 06:17:15 --> Language Class Initialized
ERROR - 2025-06-30 06:17:15 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:17:45 --> Config Class Initialized
INFO - 2025-06-30 06:17:45 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:17:45 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:17:45 --> Utf8 Class Initialized
INFO - 2025-06-30 06:17:45 --> URI Class Initialized
INFO - 2025-06-30 06:17:45 --> Router Class Initialized
INFO - 2025-06-30 06:17:45 --> Output Class Initialized
INFO - 2025-06-30 06:17:45 --> Security Class Initialized
DEBUG - 2025-06-30 06:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:17:45 --> Input Class Initialized
INFO - 2025-06-30 06:17:45 --> Language Class Initialized
INFO - 2025-06-30 06:17:45 --> Loader Class Initialized
INFO - 2025-06-30 06:17:45 --> Helper loaded: url_helper
INFO - 2025-06-30 06:17:45 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:17:45 --> Controller Class Initialized
INFO - 2025-06-30 06:17:45 --> Database Driver Class Initialized
INFO - 2025-06-30 06:17:45 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:17:45 --> Upload Class Initialized
INFO - 2025-06-30 06:17:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:17:46 --> Pagination Class Initialized
INFO - 2025-06-30 06:17:46 --> Database Forge Class Initialized
INFO - 2025-06-30 06:17:46 --> Database Forge Class Initialized
ERROR - 2025-06-30 06:17:46 --> Query error: Invalid default value for 'created_at' - Invalid query: CREATE TABLE IF NOT EXISTS `medical_products_upload_log` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`filename` VARCHAR(255) NOT NULL,
	`status` ENUM('processing','completed','failed') NOT NULL DEFAULT 'processing',
	`total_rows` INT(11) NOT NULL DEFAULT 0,
	`success_rows` INT(11) NOT NULL DEFAULT 0,
	`failed_rows` INT(11) NOT NULL DEFAULT 0,
	`error_message` TEXT NULL,
	`start_time` DATETIME NULL,
	`end_time` DATETIME NULL,
	`created_at` TIMESTAMP NOT NULL DEFAULT 'current_timestamp()',
	`updated_at` TIMESTAMP NULL DEFAULT NULL,
	CONSTRAINT `pk_medical_products_upload_log` PRIMARY KEY(`id`),
	KEY `created_at` (`created_at`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
INFO - 2025-06-30 06:17:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-06-30 06:17:47 --> Config Class Initialized
INFO - 2025-06-30 06:17:47 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:17:47 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:17:47 --> Utf8 Class Initialized
INFO - 2025-06-30 06:17:47 --> URI Class Initialized
INFO - 2025-06-30 06:17:47 --> Router Class Initialized
INFO - 2025-06-30 06:17:47 --> Output Class Initialized
INFO - 2025-06-30 06:17:47 --> Security Class Initialized
DEBUG - 2025-06-30 06:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:17:47 --> Input Class Initialized
INFO - 2025-06-30 06:17:47 --> Language Class Initialized
INFO - 2025-06-30 06:17:47 --> Loader Class Initialized
INFO - 2025-06-30 06:17:47 --> Helper loaded: url_helper
INFO - 2025-06-30 06:17:47 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:17:47 --> Controller Class Initialized
INFO - 2025-06-30 06:17:47 --> Database Driver Class Initialized
INFO - 2025-06-30 06:17:47 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:17:47 --> Upload Class Initialized
INFO - 2025-06-30 06:17:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:17:47 --> Pagination Class Initialized
INFO - 2025-06-30 06:17:47 --> Database Forge Class Initialized
INFO - 2025-06-30 06:17:47 --> Database Forge Class Initialized
ERROR - 2025-06-30 06:17:47 --> Query error: Invalid default value for 'created_at' - Invalid query: CREATE TABLE IF NOT EXISTS `medical_products_upload_log` (
	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`filename` VARCHAR(255) NOT NULL,
	`status` ENUM('processing','completed','failed') NOT NULL DEFAULT 'processing',
	`total_rows` INT(11) NOT NULL DEFAULT 0,
	`success_rows` INT(11) NOT NULL DEFAULT 0,
	`failed_rows` INT(11) NOT NULL DEFAULT 0,
	`error_message` TEXT NULL,
	`start_time` DATETIME NULL,
	`end_time` DATETIME NULL,
	`created_at` TIMESTAMP NOT NULL DEFAULT 'current_timestamp()',
	`updated_at` TIMESTAMP NULL DEFAULT NULL,
	CONSTRAINT `pk_medical_products_upload_log` PRIMARY KEY(`id`),
	KEY `created_at` (`created_at`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
INFO - 2025-06-30 06:17:47 --> Language file loaded: language/english/db_lang.php
INFO - 2025-06-30 06:24:53 --> Config Class Initialized
INFO - 2025-06-30 06:24:53 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:24:53 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:24:53 --> Utf8 Class Initialized
INFO - 2025-06-30 06:24:53 --> URI Class Initialized
INFO - 2025-06-30 06:24:53 --> Router Class Initialized
INFO - 2025-06-30 06:24:53 --> Output Class Initialized
INFO - 2025-06-30 06:24:53 --> Security Class Initialized
DEBUG - 2025-06-30 06:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:24:53 --> Input Class Initialized
INFO - 2025-06-30 06:24:53 --> Language Class Initialized
INFO - 2025-06-30 06:24:53 --> Loader Class Initialized
INFO - 2025-06-30 06:24:53 --> Helper loaded: url_helper
INFO - 2025-06-30 06:24:53 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:24:53 --> Controller Class Initialized
INFO - 2025-06-30 06:24:53 --> Database Driver Class Initialized
INFO - 2025-06-30 06:24:53 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:24:53 --> Upload Class Initialized
INFO - 2025-06-30 06:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:24:53 --> Pagination Class Initialized
INFO - 2025-06-30 06:24:53 --> Database Forge Class Initialized
INFO - 2025-06-30 06:24:53 --> Database Forge Class Initialized
INFO - 2025-06-30 06:24:54 --> Database Forge Class Initialized
INFO - 2025-06-30 06:24:54 --> Final output sent to browser
DEBUG - 2025-06-30 06:24:54 --> Total execution time: 1.1437
INFO - 2025-06-30 06:24:57 --> Config Class Initialized
INFO - 2025-06-30 06:24:57 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:24:57 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:24:57 --> Utf8 Class Initialized
INFO - 2025-06-30 06:24:57 --> URI Class Initialized
INFO - 2025-06-30 06:24:57 --> Router Class Initialized
INFO - 2025-06-30 06:24:57 --> Output Class Initialized
INFO - 2025-06-30 06:24:57 --> Security Class Initialized
DEBUG - 2025-06-30 06:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:24:57 --> Input Class Initialized
INFO - 2025-06-30 06:24:57 --> Language Class Initialized
INFO - 2025-06-30 06:24:57 --> Loader Class Initialized
INFO - 2025-06-30 06:24:57 --> Helper loaded: url_helper
INFO - 2025-06-30 06:24:57 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:24:57 --> Controller Class Initialized
INFO - 2025-06-30 06:24:57 --> Model "Medical_model" initialized
INFO - 2025-06-30 06:24:57 --> File loaded: /var/www/html/application/views/medical/upload.php
INFO - 2025-06-30 06:24:57 --> Final output sent to browser
DEBUG - 2025-06-30 06:24:57 --> Total execution time: 0.1471
INFO - 2025-06-30 06:25:00 --> Config Class Initialized
INFO - 2025-06-30 06:25:00 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:25:00 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:25:00 --> Utf8 Class Initialized
INFO - 2025-06-30 06:25:00 --> URI Class Initialized
INFO - 2025-06-30 06:25:00 --> Router Class Initialized
INFO - 2025-06-30 06:25:00 --> Output Class Initialized
INFO - 2025-06-30 06:25:00 --> Security Class Initialized
DEBUG - 2025-06-30 06:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:25:00 --> Input Class Initialized
INFO - 2025-06-30 06:25:00 --> Language Class Initialized
INFO - 2025-06-30 06:25:00 --> Loader Class Initialized
INFO - 2025-06-30 06:25:00 --> Helper loaded: url_helper
INFO - 2025-06-30 06:25:00 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:25:00 --> Controller Class Initialized
INFO - 2025-06-30 06:25:00 --> Database Driver Class Initialized
INFO - 2025-06-30 06:25:00 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:25:00 --> Upload Class Initialized
INFO - 2025-06-30 06:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:25:00 --> Pagination Class Initialized
INFO - 2025-06-30 06:25:00 --> File loaded: /var/www/html/application/views/medical_products/upload.php
INFO - 2025-06-30 06:25:00 --> Final output sent to browser
DEBUG - 2025-06-30 06:25:00 --> Total execution time: 0.1820
INFO - 2025-06-30 06:25:00 --> Config Class Initialized
INFO - 2025-06-30 06:25:00 --> Config Class Initialized
INFO - 2025-06-30 06:25:00 --> Hooks Class Initialized
INFO - 2025-06-30 06:25:00 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:25:00 --> UTF-8 Support Enabled
DEBUG - 2025-06-30 06:25:00 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:25:00 --> Utf8 Class Initialized
INFO - 2025-06-30 06:25:00 --> Utf8 Class Initialized
INFO - 2025-06-30 06:25:00 --> URI Class Initialized
INFO - 2025-06-30 06:25:00 --> URI Class Initialized
INFO - 2025-06-30 06:25:00 --> Router Class Initialized
INFO - 2025-06-30 06:25:00 --> Router Class Initialized
INFO - 2025-06-30 06:25:00 --> Output Class Initialized
INFO - 2025-06-30 06:25:00 --> Output Class Initialized
INFO - 2025-06-30 06:25:00 --> Security Class Initialized
INFO - 2025-06-30 06:25:00 --> Security Class Initialized
DEBUG - 2025-06-30 06:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-06-30 06:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:25:00 --> Input Class Initialized
INFO - 2025-06-30 06:25:00 --> Input Class Initialized
INFO - 2025-06-30 06:25:00 --> Language Class Initialized
INFO - 2025-06-30 06:25:00 --> Language Class Initialized
ERROR - 2025-06-30 06:25:00 --> 404 Page Not Found: Assets/vendor
ERROR - 2025-06-30 06:25:00 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:25:49 --> Config Class Initialized
INFO - 2025-06-30 06:25:49 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:25:49 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:25:49 --> Utf8 Class Initialized
INFO - 2025-06-30 06:25:49 --> URI Class Initialized
INFO - 2025-06-30 06:25:49 --> Router Class Initialized
INFO - 2025-06-30 06:25:49 --> Output Class Initialized
INFO - 2025-06-30 06:25:49 --> Security Class Initialized
DEBUG - 2025-06-30 06:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:25:49 --> Input Class Initialized
INFO - 2025-06-30 06:25:49 --> Language Class Initialized
INFO - 2025-06-30 06:25:49 --> Loader Class Initialized
INFO - 2025-06-30 06:25:49 --> Helper loaded: url_helper
INFO - 2025-06-30 06:25:49 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:25:49 --> Controller Class Initialized
INFO - 2025-06-30 06:25:49 --> Database Driver Class Initialized
INFO - 2025-06-30 06:25:49 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:25:49 --> Upload Class Initialized
INFO - 2025-06-30 06:25:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:25:49 --> Pagination Class Initialized
INFO - 2025-06-30 06:25:49 --> File loaded: /var/www/html/application/views/medical_products/upload.php
INFO - 2025-06-30 06:25:49 --> Final output sent to browser
DEBUG - 2025-06-30 06:25:49 --> Total execution time: 0.1935
INFO - 2025-06-30 06:25:49 --> Config Class Initialized
INFO - 2025-06-30 06:25:49 --> Config Class Initialized
INFO - 2025-06-30 06:25:49 --> Hooks Class Initialized
INFO - 2025-06-30 06:25:49 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:25:49 --> UTF-8 Support Enabled
DEBUG - 2025-06-30 06:25:49 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:25:49 --> Utf8 Class Initialized
INFO - 2025-06-30 06:25:49 --> Utf8 Class Initialized
INFO - 2025-06-30 06:25:49 --> URI Class Initialized
INFO - 2025-06-30 06:25:49 --> URI Class Initialized
INFO - 2025-06-30 06:25:49 --> Router Class Initialized
INFO - 2025-06-30 06:25:49 --> Router Class Initialized
INFO - 2025-06-30 06:25:49 --> Output Class Initialized
INFO - 2025-06-30 06:25:49 --> Output Class Initialized
INFO - 2025-06-30 06:25:49 --> Security Class Initialized
INFO - 2025-06-30 06:25:49 --> Security Class Initialized
DEBUG - 2025-06-30 06:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-06-30 06:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:25:49 --> Input Class Initialized
INFO - 2025-06-30 06:25:49 --> Input Class Initialized
INFO - 2025-06-30 06:25:49 --> Language Class Initialized
INFO - 2025-06-30 06:25:49 --> Language Class Initialized
ERROR - 2025-06-30 06:25:49 --> 404 Page Not Found: Assets/vendor
ERROR - 2025-06-30 06:25:49 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:26:13 --> Config Class Initialized
INFO - 2025-06-30 06:26:13 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:26:13 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:26:13 --> Utf8 Class Initialized
INFO - 2025-06-30 06:26:13 --> URI Class Initialized
INFO - 2025-06-30 06:26:13 --> Router Class Initialized
INFO - 2025-06-30 06:26:13 --> Output Class Initialized
INFO - 2025-06-30 06:26:13 --> Security Class Initialized
DEBUG - 2025-06-30 06:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:26:13 --> Input Class Initialized
INFO - 2025-06-30 06:26:13 --> Language Class Initialized
INFO - 2025-06-30 06:26:13 --> Loader Class Initialized
INFO - 2025-06-30 06:26:13 --> Helper loaded: url_helper
INFO - 2025-06-30 06:26:13 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:26:13 --> Controller Class Initialized
INFO - 2025-06-30 06:26:13 --> Database Driver Class Initialized
INFO - 2025-06-30 06:26:13 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:26:13 --> Upload Class Initialized
INFO - 2025-06-30 06:26:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:26:13 --> Pagination Class Initialized
INFO - 2025-06-30 06:26:14 --> File loaded: /var/www/html/application/views/medical_products/upload.php
INFO - 2025-06-30 06:26:14 --> Final output sent to browser
DEBUG - 2025-06-30 06:26:14 --> Total execution time: 0.1867
INFO - 2025-06-30 06:26:14 --> Config Class Initialized
INFO - 2025-06-30 06:26:14 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:26:14 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:26:14 --> Utf8 Class Initialized
INFO - 2025-06-30 06:26:14 --> URI Class Initialized
INFO - 2025-06-30 06:26:14 --> Router Class Initialized
INFO - 2025-06-30 06:26:14 --> Output Class Initialized
INFO - 2025-06-30 06:26:14 --> Security Class Initialized
DEBUG - 2025-06-30 06:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:26:14 --> Input Class Initialized
INFO - 2025-06-30 06:26:14 --> Language Class Initialized
ERROR - 2025-06-30 06:26:14 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:26:25 --> Config Class Initialized
INFO - 2025-06-30 06:26:25 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:26:25 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:26:25 --> Utf8 Class Initialized
INFO - 2025-06-30 06:26:25 --> URI Class Initialized
INFO - 2025-06-30 06:26:25 --> Router Class Initialized
INFO - 2025-06-30 06:26:25 --> Output Class Initialized
INFO - 2025-06-30 06:26:25 --> Security Class Initialized
DEBUG - 2025-06-30 06:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:26:25 --> Input Class Initialized
INFO - 2025-06-30 06:26:25 --> Language Class Initialized
ERROR - 2025-06-30 06:26:25 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:27:42 --> Config Class Initialized
INFO - 2025-06-30 06:27:42 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:27:42 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:27:42 --> Utf8 Class Initialized
INFO - 2025-06-30 06:27:42 --> URI Class Initialized
INFO - 2025-06-30 06:27:42 --> Router Class Initialized
INFO - 2025-06-30 06:27:42 --> Output Class Initialized
INFO - 2025-06-30 06:27:42 --> Security Class Initialized
DEBUG - 2025-06-30 06:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:27:42 --> Input Class Initialized
INFO - 2025-06-30 06:27:42 --> Language Class Initialized
ERROR - 2025-06-30 06:27:42 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:28:16 --> Config Class Initialized
INFO - 2025-06-30 06:28:16 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:28:16 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:28:16 --> Utf8 Class Initialized
INFO - 2025-06-30 06:28:16 --> URI Class Initialized
INFO - 2025-06-30 06:28:16 --> Router Class Initialized
INFO - 2025-06-30 06:28:16 --> Output Class Initialized
INFO - 2025-06-30 06:28:16 --> Security Class Initialized
DEBUG - 2025-06-30 06:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:28:16 --> Input Class Initialized
INFO - 2025-06-30 06:28:16 --> Language Class Initialized
ERROR - 2025-06-30 06:28:16 --> 404 Page Not Found: Medical_products/upload_simple
INFO - 2025-06-30 06:28:16 --> Config Class Initialized
INFO - 2025-06-30 06:28:16 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:28:16 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:28:16 --> Utf8 Class Initialized
INFO - 2025-06-30 06:28:16 --> URI Class Initialized
INFO - 2025-06-30 06:28:16 --> Router Class Initialized
INFO - 2025-06-30 06:28:16 --> Output Class Initialized
INFO - 2025-06-30 06:28:16 --> Security Class Initialized
DEBUG - 2025-06-30 06:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:28:16 --> Input Class Initialized
INFO - 2025-06-30 06:28:16 --> Language Class Initialized
ERROR - 2025-06-30 06:28:16 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:28:19 --> Config Class Initialized
INFO - 2025-06-30 06:28:19 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:28:19 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:28:19 --> Utf8 Class Initialized
INFO - 2025-06-30 06:28:19 --> URI Class Initialized
INFO - 2025-06-30 06:28:19 --> Router Class Initialized
INFO - 2025-06-30 06:28:19 --> Output Class Initialized
INFO - 2025-06-30 06:28:19 --> Security Class Initialized
DEBUG - 2025-06-30 06:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:28:19 --> Input Class Initialized
INFO - 2025-06-30 06:28:19 --> Language Class Initialized
INFO - 2025-06-30 06:28:19 --> Loader Class Initialized
INFO - 2025-06-30 06:28:19 --> Helper loaded: url_helper
INFO - 2025-06-30 06:28:19 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:28:19 --> Controller Class Initialized
INFO - 2025-06-30 06:28:19 --> Database Driver Class Initialized
INFO - 2025-06-30 06:28:19 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:28:19 --> Upload Class Initialized
INFO - 2025-06-30 06:28:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:28:19 --> Pagination Class Initialized
INFO - 2025-06-30 06:28:19 --> File loaded: /var/www/html/application/views/medical_products/upload.php
INFO - 2025-06-30 06:28:19 --> Final output sent to browser
DEBUG - 2025-06-30 06:28:19 --> Total execution time: 0.2373
INFO - 2025-06-30 06:28:19 --> Config Class Initialized
INFO - 2025-06-30 06:28:19 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:28:19 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:28:19 --> Utf8 Class Initialized
INFO - 2025-06-30 06:28:19 --> URI Class Initialized
INFO - 2025-06-30 06:28:19 --> Router Class Initialized
INFO - 2025-06-30 06:28:19 --> Output Class Initialized
INFO - 2025-06-30 06:28:19 --> Security Class Initialized
DEBUG - 2025-06-30 06:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:28:19 --> Input Class Initialized
INFO - 2025-06-30 06:28:19 --> Language Class Initialized
ERROR - 2025-06-30 06:28:19 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:28:24 --> Config Class Initialized
INFO - 2025-06-30 06:28:24 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:28:24 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:28:24 --> Utf8 Class Initialized
INFO - 2025-06-30 06:28:24 --> URI Class Initialized
INFO - 2025-06-30 06:28:24 --> Router Class Initialized
INFO - 2025-06-30 06:28:24 --> Output Class Initialized
INFO - 2025-06-30 06:28:24 --> Security Class Initialized
DEBUG - 2025-06-30 06:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:28:24 --> Input Class Initialized
INFO - 2025-06-30 06:28:24 --> Language Class Initialized
ERROR - 2025-06-30 06:28:24 --> 404 Page Not Found: Medical_products/upload_simple
INFO - 2025-06-30 06:28:24 --> Config Class Initialized
INFO - 2025-06-30 06:28:24 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:28:24 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:28:24 --> Utf8 Class Initialized
INFO - 2025-06-30 06:28:25 --> URI Class Initialized
INFO - 2025-06-30 06:28:25 --> Router Class Initialized
INFO - 2025-06-30 06:28:25 --> Output Class Initialized
INFO - 2025-06-30 06:28:25 --> Security Class Initialized
DEBUG - 2025-06-30 06:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:28:25 --> Input Class Initialized
INFO - 2025-06-30 06:28:25 --> Language Class Initialized
ERROR - 2025-06-30 06:28:25 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:29:43 --> Config Class Initialized
INFO - 2025-06-30 06:29:43 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:29:43 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:29:43 --> Utf8 Class Initialized
INFO - 2025-06-30 06:29:43 --> URI Class Initialized
INFO - 2025-06-30 06:29:43 --> Router Class Initialized
INFO - 2025-06-30 06:29:43 --> Output Class Initialized
INFO - 2025-06-30 06:29:43 --> Security Class Initialized
DEBUG - 2025-06-30 06:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:29:43 --> Input Class Initialized
INFO - 2025-06-30 06:29:43 --> Language Class Initialized
INFO - 2025-06-30 06:29:43 --> Loader Class Initialized
INFO - 2025-06-30 06:29:43 --> Helper loaded: url_helper
INFO - 2025-06-30 06:29:43 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:29:43 --> Controller Class Initialized
INFO - 2025-06-30 06:29:43 --> Database Driver Class Initialized
INFO - 2025-06-30 06:29:43 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:29:43 --> Upload Class Initialized
INFO - 2025-06-30 06:29:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:29:43 --> Pagination Class Initialized
INFO - 2025-06-30 06:29:43 --> File loaded: /var/www/html/application/views/medical_products/upload.php
INFO - 2025-06-30 06:29:43 --> Final output sent to browser
DEBUG - 2025-06-30 06:29:43 --> Total execution time: 0.1807
INFO - 2025-06-30 06:29:43 --> Config Class Initialized
INFO - 2025-06-30 06:29:43 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:29:43 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:29:43 --> Utf8 Class Initialized
INFO - 2025-06-30 06:29:43 --> URI Class Initialized
INFO - 2025-06-30 06:29:43 --> Router Class Initialized
INFO - 2025-06-30 06:29:43 --> Output Class Initialized
INFO - 2025-06-30 06:29:43 --> Security Class Initialized
DEBUG - 2025-06-30 06:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:29:43 --> Input Class Initialized
INFO - 2025-06-30 06:29:43 --> Language Class Initialized
ERROR - 2025-06-30 06:29:43 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:29:44 --> Config Class Initialized
INFO - 2025-06-30 06:29:44 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:29:44 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:29:44 --> Utf8 Class Initialized
INFO - 2025-06-30 06:29:44 --> URI Class Initialized
INFO - 2025-06-30 06:29:44 --> Router Class Initialized
INFO - 2025-06-30 06:29:44 --> Output Class Initialized
INFO - 2025-06-30 06:29:44 --> Security Class Initialized
DEBUG - 2025-06-30 06:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:29:44 --> Input Class Initialized
INFO - 2025-06-30 06:29:44 --> Language Class Initialized
INFO - 2025-06-30 06:29:44 --> Loader Class Initialized
INFO - 2025-06-30 06:29:44 --> Helper loaded: url_helper
INFO - 2025-06-30 06:29:44 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:29:44 --> Controller Class Initialized
INFO - 2025-06-30 06:29:44 --> Database Driver Class Initialized
INFO - 2025-06-30 06:29:44 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:29:44 --> Upload Class Initialized
INFO - 2025-06-30 06:29:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:29:44 --> Pagination Class Initialized
INFO - 2025-06-30 06:29:44 --> File loaded: /var/www/html/application/views/medical_products/upload.php
INFO - 2025-06-30 06:29:44 --> Final output sent to browser
DEBUG - 2025-06-30 06:29:44 --> Total execution time: 0.1398
INFO - 2025-06-30 06:29:44 --> Config Class Initialized
INFO - 2025-06-30 06:29:44 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:29:44 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:29:44 --> Utf8 Class Initialized
INFO - 2025-06-30 06:29:44 --> URI Class Initialized
INFO - 2025-06-30 06:29:44 --> Router Class Initialized
INFO - 2025-06-30 06:29:44 --> Output Class Initialized
INFO - 2025-06-30 06:29:44 --> Security Class Initialized
DEBUG - 2025-06-30 06:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:29:44 --> Input Class Initialized
INFO - 2025-06-30 06:29:44 --> Language Class Initialized
ERROR - 2025-06-30 06:29:44 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:29:48 --> Config Class Initialized
INFO - 2025-06-30 06:29:48 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:29:48 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:29:48 --> Utf8 Class Initialized
INFO - 2025-06-30 06:29:48 --> URI Class Initialized
INFO - 2025-06-30 06:29:48 --> Router Class Initialized
INFO - 2025-06-30 06:29:48 --> Output Class Initialized
INFO - 2025-06-30 06:29:48 --> Security Class Initialized
DEBUG - 2025-06-30 06:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:29:48 --> Input Class Initialized
INFO - 2025-06-30 06:29:48 --> Language Class Initialized
INFO - 2025-06-30 06:29:48 --> Loader Class Initialized
INFO - 2025-06-30 06:29:48 --> Helper loaded: url_helper
INFO - 2025-06-30 06:29:48 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:29:49 --> Controller Class Initialized
INFO - 2025-06-30 06:29:49 --> Database Driver Class Initialized
INFO - 2025-06-30 06:29:49 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:29:49 --> Upload Class Initialized
INFO - 2025-06-30 06:29:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:29:49 --> Pagination Class Initialized
INFO - 2025-06-30 06:29:49 --> File loaded: /var/www/html/application/views/medical_products/upload_simple.php
INFO - 2025-06-30 06:29:49 --> Final output sent to browser
DEBUG - 2025-06-30 06:29:49 --> Total execution time: 0.1794
INFO - 2025-06-30 06:29:49 --> Config Class Initialized
INFO - 2025-06-30 06:29:49 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:29:49 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:29:49 --> Utf8 Class Initialized
INFO - 2025-06-30 06:29:49 --> URI Class Initialized
INFO - 2025-06-30 06:29:49 --> Router Class Initialized
INFO - 2025-06-30 06:29:49 --> Output Class Initialized
INFO - 2025-06-30 06:29:49 --> Security Class Initialized
DEBUG - 2025-06-30 06:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:29:49 --> Input Class Initialized
INFO - 2025-06-30 06:29:49 --> Language Class Initialized
ERROR - 2025-06-30 06:29:49 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:30:31 --> Config Class Initialized
INFO - 2025-06-30 06:30:31 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:30:31 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:30:31 --> Utf8 Class Initialized
INFO - 2025-06-30 06:30:31 --> URI Class Initialized
INFO - 2025-06-30 06:30:31 --> Router Class Initialized
INFO - 2025-06-30 06:30:31 --> Output Class Initialized
INFO - 2025-06-30 06:30:31 --> Security Class Initialized
DEBUG - 2025-06-30 06:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:30:31 --> Input Class Initialized
INFO - 2025-06-30 06:30:31 --> Language Class Initialized
INFO - 2025-06-30 06:30:31 --> Loader Class Initialized
INFO - 2025-06-30 06:30:31 --> Helper loaded: url_helper
INFO - 2025-06-30 06:30:31 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:30:31 --> Controller Class Initialized
INFO - 2025-06-30 06:30:31 --> Database Driver Class Initialized
INFO - 2025-06-30 06:30:31 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:30:31 --> Upload Class Initialized
INFO - 2025-06-30 06:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:30:31 --> Pagination Class Initialized
INFO - 2025-06-30 06:30:31 --> File loaded: /var/www/html/application/views/medical_products/upload.php
INFO - 2025-06-30 06:30:31 --> Final output sent to browser
DEBUG - 2025-06-30 06:30:31 --> Total execution time: 0.1979
INFO - 2025-06-30 06:30:31 --> Config Class Initialized
INFO - 2025-06-30 06:30:31 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:30:31 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:30:31 --> Utf8 Class Initialized
INFO - 2025-06-30 06:30:31 --> URI Class Initialized
INFO - 2025-06-30 06:30:31 --> Router Class Initialized
INFO - 2025-06-30 06:30:31 --> Output Class Initialized
INFO - 2025-06-30 06:30:31 --> Security Class Initialized
DEBUG - 2025-06-30 06:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:30:31 --> Input Class Initialized
INFO - 2025-06-30 06:30:31 --> Language Class Initialized
ERROR - 2025-06-30 06:30:31 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:30:32 --> Config Class Initialized
INFO - 2025-06-30 06:30:32 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:30:32 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:30:32 --> Utf8 Class Initialized
INFO - 2025-06-30 06:30:32 --> URI Class Initialized
INFO - 2025-06-30 06:30:32 --> Router Class Initialized
INFO - 2025-06-30 06:30:32 --> Output Class Initialized
INFO - 2025-06-30 06:30:32 --> Security Class Initialized
DEBUG - 2025-06-30 06:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:30:32 --> Input Class Initialized
INFO - 2025-06-30 06:30:32 --> Language Class Initialized
INFO - 2025-06-30 06:30:32 --> Loader Class Initialized
INFO - 2025-06-30 06:30:32 --> Helper loaded: url_helper
INFO - 2025-06-30 06:30:32 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:30:32 --> Controller Class Initialized
INFO - 2025-06-30 06:30:32 --> Database Driver Class Initialized
INFO - 2025-06-30 06:30:32 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:30:32 --> Upload Class Initialized
INFO - 2025-06-30 06:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:30:32 --> Pagination Class Initialized
INFO - 2025-06-30 06:30:32 --> File loaded: /var/www/html/application/views/medical_products/upload.php
INFO - 2025-06-30 06:30:32 --> Final output sent to browser
DEBUG - 2025-06-30 06:30:32 --> Total execution time: 0.1391
INFO - 2025-06-30 06:30:32 --> Config Class Initialized
INFO - 2025-06-30 06:30:32 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:30:32 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:30:32 --> Utf8 Class Initialized
INFO - 2025-06-30 06:30:32 --> URI Class Initialized
INFO - 2025-06-30 06:30:32 --> Router Class Initialized
INFO - 2025-06-30 06:30:32 --> Output Class Initialized
INFO - 2025-06-30 06:30:32 --> Security Class Initialized
DEBUG - 2025-06-30 06:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:30:32 --> Input Class Initialized
INFO - 2025-06-30 06:30:32 --> Language Class Initialized
ERROR - 2025-06-30 06:30:32 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:30:38 --> Config Class Initialized
INFO - 2025-06-30 06:30:38 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:30:38 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:30:38 --> Utf8 Class Initialized
INFO - 2025-06-30 06:30:38 --> URI Class Initialized
INFO - 2025-06-30 06:30:38 --> Router Class Initialized
INFO - 2025-06-30 06:30:38 --> Output Class Initialized
INFO - 2025-06-30 06:30:38 --> Security Class Initialized
DEBUG - 2025-06-30 06:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:30:38 --> Input Class Initialized
INFO - 2025-06-30 06:30:38 --> Language Class Initialized
INFO - 2025-06-30 06:30:38 --> Loader Class Initialized
INFO - 2025-06-30 06:30:38 --> Helper loaded: url_helper
INFO - 2025-06-30 06:30:38 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:30:38 --> Controller Class Initialized
INFO - 2025-06-30 06:30:38 --> Database Driver Class Initialized
INFO - 2025-06-30 06:30:38 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:30:38 --> Upload Class Initialized
INFO - 2025-06-30 06:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:30:38 --> Pagination Class Initialized
INFO - 2025-06-30 06:30:38 --> File loaded: /var/www/html/application/views/medical_products/upload_simple.php
INFO - 2025-06-30 06:30:38 --> Final output sent to browser
DEBUG - 2025-06-30 06:30:38 --> Total execution time: 0.1624
INFO - 2025-06-30 06:30:38 --> Config Class Initialized
INFO - 2025-06-30 06:30:38 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:30:38 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:30:38 --> Utf8 Class Initialized
INFO - 2025-06-30 06:30:38 --> URI Class Initialized
INFO - 2025-06-30 06:30:38 --> Router Class Initialized
INFO - 2025-06-30 06:30:38 --> Output Class Initialized
INFO - 2025-06-30 06:30:38 --> Security Class Initialized
DEBUG - 2025-06-30 06:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:30:38 --> Input Class Initialized
INFO - 2025-06-30 06:30:38 --> Language Class Initialized
ERROR - 2025-06-30 06:30:38 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:35:35 --> Config Class Initialized
INFO - 2025-06-30 06:35:35 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:35:35 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:35:35 --> Utf8 Class Initialized
INFO - 2025-06-30 06:35:35 --> URI Class Initialized
INFO - 2025-06-30 06:35:35 --> Router Class Initialized
INFO - 2025-06-30 06:35:35 --> Output Class Initialized
INFO - 2025-06-30 06:35:35 --> Security Class Initialized
DEBUG - 2025-06-30 06:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:35:35 --> Input Class Initialized
INFO - 2025-06-30 06:35:35 --> Language Class Initialized
INFO - 2025-06-30 06:35:35 --> Loader Class Initialized
INFO - 2025-06-30 06:35:35 --> Helper loaded: url_helper
INFO - 2025-06-30 06:35:35 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:35:35 --> Controller Class Initialized
INFO - 2025-06-30 06:35:35 --> Database Driver Class Initialized
INFO - 2025-06-30 06:35:35 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:35:35 --> Upload Class Initialized
INFO - 2025-06-30 06:35:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:35:35 --> Pagination Class Initialized
INFO - 2025-06-30 06:35:35 --> File loaded: /var/www/html/application/views/medical_products/upload_simple.php
INFO - 2025-06-30 06:35:35 --> Final output sent to browser
DEBUG - 2025-06-30 06:35:35 --> Total execution time: 0.1614
INFO - 2025-06-30 06:35:35 --> Config Class Initialized
INFO - 2025-06-30 06:35:35 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:35:35 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:35:35 --> Utf8 Class Initialized
INFO - 2025-06-30 06:35:35 --> URI Class Initialized
INFO - 2025-06-30 06:35:35 --> Router Class Initialized
INFO - 2025-06-30 06:35:35 --> Output Class Initialized
INFO - 2025-06-30 06:35:35 --> Security Class Initialized
DEBUG - 2025-06-30 06:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:35:35 --> Input Class Initialized
INFO - 2025-06-30 06:35:35 --> Language Class Initialized
ERROR - 2025-06-30 06:35:35 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 06:35:37 --> Config Class Initialized
INFO - 2025-06-30 06:35:37 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:35:37 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:35:37 --> Utf8 Class Initialized
INFO - 2025-06-30 06:35:37 --> URI Class Initialized
INFO - 2025-06-30 06:35:37 --> Router Class Initialized
INFO - 2025-06-30 06:35:37 --> Output Class Initialized
INFO - 2025-06-30 06:35:37 --> Security Class Initialized
DEBUG - 2025-06-30 06:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:35:37 --> Input Class Initialized
INFO - 2025-06-30 06:35:37 --> Language Class Initialized
INFO - 2025-06-30 06:35:37 --> Loader Class Initialized
INFO - 2025-06-30 06:35:37 --> Helper loaded: url_helper
INFO - 2025-06-30 06:35:37 --> Helper loaded: form_helper
DEBUG - 2025-06-30 06:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 06:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 06:35:37 --> Controller Class Initialized
INFO - 2025-06-30 06:35:37 --> Database Driver Class Initialized
INFO - 2025-06-30 06:35:37 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 06:35:37 --> Upload Class Initialized
INFO - 2025-06-30 06:35:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-06-30 06:35:37 --> Pagination Class Initialized
INFO - 2025-06-30 06:35:37 --> File loaded: /var/www/html/application/views/medical_products/upload.php
INFO - 2025-06-30 06:35:37 --> Final output sent to browser
DEBUG - 2025-06-30 06:35:37 --> Total execution time: 0.1723
INFO - 2025-06-30 06:35:37 --> Config Class Initialized
INFO - 2025-06-30 06:35:37 --> Hooks Class Initialized
DEBUG - 2025-06-30 06:35:37 --> UTF-8 Support Enabled
INFO - 2025-06-30 06:35:37 --> Utf8 Class Initialized
INFO - 2025-06-30 06:35:37 --> URI Class Initialized
INFO - 2025-06-30 06:35:37 --> Router Class Initialized
INFO - 2025-06-30 06:35:37 --> Output Class Initialized
INFO - 2025-06-30 06:35:37 --> Security Class Initialized
DEBUG - 2025-06-30 06:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 06:35:37 --> Input Class Initialized
INFO - 2025-06-30 06:35:37 --> Language Class Initialized
ERROR - 2025-06-30 06:35:37 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 07:05:51 --> Config Class Initialized
INFO - 2025-06-30 07:05:51 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:05:51 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:05:51 --> Utf8 Class Initialized
INFO - 2025-06-30 07:05:51 --> URI Class Initialized
INFO - 2025-06-30 07:05:51 --> Router Class Initialized
INFO - 2025-06-30 07:05:51 --> Output Class Initialized
INFO - 2025-06-30 07:05:51 --> Security Class Initialized
DEBUG - 2025-06-30 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:05:51 --> Input Class Initialized
INFO - 2025-06-30 07:05:51 --> Language Class Initialized
INFO - 2025-06-30 07:05:51 --> Loader Class Initialized
INFO - 2025-06-30 07:05:51 --> Helper loaded: url_helper
INFO - 2025-06-30 07:05:51 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:05:51 --> Controller Class Initialized
INFO - 2025-06-30 07:05:51 --> Database Driver Class Initialized
INFO - 2025-06-30 07:05:51 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:05:51 --> Upload Class Initialized
INFO - 2025-06-30 07:05:51 --> Form Validation Class Initialized
INFO - 2025-06-30 07:05:51 --> Database Forge Class Initialized
INFO - 2025-06-30 07:05:51 --> Helper loaded: file_helper
INFO - 2025-06-30 07:05:51 --> File loaded: /var/www/html/application/views/medical_products/upload.php
INFO - 2025-06-30 07:05:51 --> Final output sent to browser
DEBUG - 2025-06-30 07:05:51 --> Total execution time: 0.2274
INFO - 2025-06-30 07:05:51 --> Config Class Initialized
INFO - 2025-06-30 07:05:51 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:05:51 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:05:51 --> Utf8 Class Initialized
INFO - 2025-06-30 07:05:51 --> URI Class Initialized
INFO - 2025-06-30 07:05:51 --> Router Class Initialized
INFO - 2025-06-30 07:05:51 --> Output Class Initialized
INFO - 2025-06-30 07:05:51 --> Security Class Initialized
DEBUG - 2025-06-30 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:05:51 --> Input Class Initialized
INFO - 2025-06-30 07:05:51 --> Language Class Initialized
ERROR - 2025-06-30 07:05:51 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 07:05:55 --> Config Class Initialized
INFO - 2025-06-30 07:05:55 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:05:55 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:05:55 --> Utf8 Class Initialized
INFO - 2025-06-30 07:05:55 --> URI Class Initialized
INFO - 2025-06-30 07:05:55 --> Router Class Initialized
INFO - 2025-06-30 07:05:55 --> Output Class Initialized
INFO - 2025-06-30 07:05:55 --> Security Class Initialized
DEBUG - 2025-06-30 07:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:05:55 --> Input Class Initialized
INFO - 2025-06-30 07:05:55 --> Language Class Initialized
INFO - 2025-06-30 07:05:55 --> Loader Class Initialized
INFO - 2025-06-30 07:05:55 --> Helper loaded: url_helper
INFO - 2025-06-30 07:05:55 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:05:55 --> Controller Class Initialized
INFO - 2025-06-30 07:05:55 --> Database Driver Class Initialized
INFO - 2025-06-30 07:05:55 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:05:55 --> Upload Class Initialized
INFO - 2025-06-30 07:05:55 --> Form Validation Class Initialized
INFO - 2025-06-30 07:05:55 --> Database Forge Class Initialized
INFO - 2025-06-30 07:05:55 --> Helper loaded: file_helper
INFO - 2025-06-30 07:05:55 --> File loaded: /var/www/html/application/views/medical_products/upload_simple.php
INFO - 2025-06-30 07:05:55 --> Final output sent to browser
DEBUG - 2025-06-30 07:05:55 --> Total execution time: 0.1773
INFO - 2025-06-30 07:05:55 --> Config Class Initialized
INFO - 2025-06-30 07:05:55 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:05:55 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:05:55 --> Utf8 Class Initialized
INFO - 2025-06-30 07:05:55 --> URI Class Initialized
INFO - 2025-06-30 07:05:55 --> Router Class Initialized
INFO - 2025-06-30 07:05:55 --> Output Class Initialized
INFO - 2025-06-30 07:05:55 --> Security Class Initialized
DEBUG - 2025-06-30 07:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:05:55 --> Input Class Initialized
INFO - 2025-06-30 07:05:55 --> Language Class Initialized
ERROR - 2025-06-30 07:05:55 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 07:06:08 --> Config Class Initialized
INFO - 2025-06-30 07:06:08 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:06:08 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:06:08 --> Utf8 Class Initialized
INFO - 2025-06-30 07:06:08 --> URI Class Initialized
INFO - 2025-06-30 07:06:08 --> Router Class Initialized
INFO - 2025-06-30 07:06:08 --> Output Class Initialized
INFO - 2025-06-30 07:06:08 --> Security Class Initialized
DEBUG - 2025-06-30 07:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:06:08 --> Input Class Initialized
INFO - 2025-06-30 07:06:08 --> Language Class Initialized
INFO - 2025-06-30 07:06:09 --> Loader Class Initialized
INFO - 2025-06-30 07:06:09 --> Helper loaded: url_helper
INFO - 2025-06-30 07:06:09 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:06:09 --> Controller Class Initialized
INFO - 2025-06-30 07:06:09 --> Database Driver Class Initialized
INFO - 2025-06-30 07:06:09 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:06:09 --> Upload Class Initialized
INFO - 2025-06-30 07:06:09 --> Form Validation Class Initialized
INFO - 2025-06-30 07:06:09 --> Database Forge Class Initialized
INFO - 2025-06-30 07:06:09 --> Helper loaded: file_helper
INFO - 2025-06-30 07:06:09 --> File loaded: /var/www/html/application/views/medical_products/upload.php
INFO - 2025-06-30 07:06:09 --> Final output sent to browser
DEBUG - 2025-06-30 07:06:09 --> Total execution time: 0.1709
INFO - 2025-06-30 07:06:09 --> Config Class Initialized
INFO - 2025-06-30 07:06:09 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:06:09 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:06:09 --> Utf8 Class Initialized
INFO - 2025-06-30 07:06:09 --> URI Class Initialized
INFO - 2025-06-30 07:06:09 --> Router Class Initialized
INFO - 2025-06-30 07:06:09 --> Output Class Initialized
INFO - 2025-06-30 07:06:09 --> Security Class Initialized
DEBUG - 2025-06-30 07:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:06:09 --> Input Class Initialized
INFO - 2025-06-30 07:06:09 --> Language Class Initialized
ERROR - 2025-06-30 07:06:09 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 07:08:52 --> Config Class Initialized
INFO - 2025-06-30 07:08:52 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:08:52 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:08:52 --> Utf8 Class Initialized
INFO - 2025-06-30 07:08:52 --> URI Class Initialized
INFO - 2025-06-30 07:08:52 --> Router Class Initialized
INFO - 2025-06-30 07:08:52 --> Output Class Initialized
INFO - 2025-06-30 07:08:52 --> Security Class Initialized
DEBUG - 2025-06-30 07:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:08:52 --> Input Class Initialized
INFO - 2025-06-30 07:08:52 --> Language Class Initialized
INFO - 2025-06-30 07:08:52 --> Loader Class Initialized
INFO - 2025-06-30 07:08:52 --> Helper loaded: url_helper
INFO - 2025-06-30 07:08:52 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:08:52 --> Controller Class Initialized
INFO - 2025-06-30 07:08:52 --> Database Driver Class Initialized
INFO - 2025-06-30 07:08:52 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:08:52 --> Upload Class Initialized
INFO - 2025-06-30 07:08:52 --> Form Validation Class Initialized
DEBUG - 2025-06-30 07:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2025-06-30 07:08:52 --> Database Forge Class Initialized
INFO - 2025-06-30 07:08:52 --> Helper loaded: file_helper
INFO - 2025-06-30 07:08:52 --> File loaded: /var/www/html/application/views/medical_products/upload.php
INFO - 2025-06-30 07:08:52 --> Final output sent to browser
DEBUG - 2025-06-30 07:08:52 --> Total execution time: 0.3090
INFO - 2025-06-30 07:08:52 --> Config Class Initialized
INFO - 2025-06-30 07:08:52 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:08:52 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:08:52 --> Utf8 Class Initialized
INFO - 2025-06-30 07:08:52 --> URI Class Initialized
INFO - 2025-06-30 07:08:52 --> Router Class Initialized
INFO - 2025-06-30 07:08:52 --> Output Class Initialized
INFO - 2025-06-30 07:08:52 --> Security Class Initialized
DEBUG - 2025-06-30 07:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:08:52 --> Input Class Initialized
INFO - 2025-06-30 07:08:52 --> Language Class Initialized
ERROR - 2025-06-30 07:08:52 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 07:08:56 --> Config Class Initialized
INFO - 2025-06-30 07:08:56 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:08:56 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:08:56 --> Utf8 Class Initialized
INFO - 2025-06-30 07:08:56 --> URI Class Initialized
INFO - 2025-06-30 07:08:56 --> Router Class Initialized
INFO - 2025-06-30 07:08:56 --> Output Class Initialized
INFO - 2025-06-30 07:08:56 --> Security Class Initialized
DEBUG - 2025-06-30 07:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:08:56 --> Input Class Initialized
INFO - 2025-06-30 07:08:56 --> Language Class Initialized
INFO - 2025-06-30 07:08:56 --> Loader Class Initialized
INFO - 2025-06-30 07:08:56 --> Helper loaded: url_helper
INFO - 2025-06-30 07:08:56 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:08:56 --> Controller Class Initialized
INFO - 2025-06-30 07:08:56 --> Database Driver Class Initialized
INFO - 2025-06-30 07:08:56 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:08:56 --> Upload Class Initialized
INFO - 2025-06-30 07:08:56 --> Form Validation Class Initialized
DEBUG - 2025-06-30 07:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2025-06-30 07:08:56 --> Database Forge Class Initialized
INFO - 2025-06-30 07:08:56 --> Helper loaded: file_helper
INFO - 2025-06-30 07:08:56 --> Language file loaded: language/english/upload_lang.php
ERROR - 2025-06-30 07:08:56 --> The upload path does not appear to be valid.
INFO - 2025-06-30 07:08:56 --> Config Class Initialized
INFO - 2025-06-30 07:08:56 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:08:56 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:08:56 --> Utf8 Class Initialized
INFO - 2025-06-30 07:08:56 --> URI Class Initialized
INFO - 2025-06-30 07:08:56 --> Router Class Initialized
INFO - 2025-06-30 07:08:56 --> Output Class Initialized
INFO - 2025-06-30 07:08:56 --> Security Class Initialized
DEBUG - 2025-06-30 07:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:08:56 --> Input Class Initialized
INFO - 2025-06-30 07:08:56 --> Language Class Initialized
INFO - 2025-06-30 07:08:56 --> Loader Class Initialized
INFO - 2025-06-30 07:08:56 --> Helper loaded: url_helper
INFO - 2025-06-30 07:08:56 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:08:56 --> Controller Class Initialized
INFO - 2025-06-30 07:08:56 --> Database Driver Class Initialized
INFO - 2025-06-30 07:08:56 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:08:56 --> Upload Class Initialized
INFO - 2025-06-30 07:08:56 --> Form Validation Class Initialized
DEBUG - 2025-06-30 07:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2025-06-30 07:08:56 --> Database Forge Class Initialized
INFO - 2025-06-30 07:08:56 --> Helper loaded: file_helper
INFO - 2025-06-30 07:08:56 --> File loaded: /var/www/html/application/views/medical_products/upload_simple.php
INFO - 2025-06-30 07:08:56 --> Final output sent to browser
DEBUG - 2025-06-30 07:08:56 --> Total execution time: 0.1443
INFO - 2025-06-30 07:08:56 --> Config Class Initialized
INFO - 2025-06-30 07:08:56 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:08:56 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:08:56 --> Utf8 Class Initialized
INFO - 2025-06-30 07:08:56 --> URI Class Initialized
INFO - 2025-06-30 07:08:56 --> Router Class Initialized
INFO - 2025-06-30 07:08:56 --> Output Class Initialized
INFO - 2025-06-30 07:08:56 --> Security Class Initialized
DEBUG - 2025-06-30 07:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:08:56 --> Input Class Initialized
INFO - 2025-06-30 07:08:56 --> Language Class Initialized
ERROR - 2025-06-30 07:08:56 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 07:09:09 --> Config Class Initialized
INFO - 2025-06-30 07:09:09 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:09:09 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:09:09 --> Utf8 Class Initialized
INFO - 2025-06-30 07:09:09 --> URI Class Initialized
INFO - 2025-06-30 07:09:09 --> Router Class Initialized
INFO - 2025-06-30 07:09:09 --> Output Class Initialized
INFO - 2025-06-30 07:09:09 --> Security Class Initialized
DEBUG - 2025-06-30 07:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:09:09 --> Input Class Initialized
INFO - 2025-06-30 07:09:09 --> Language Class Initialized
INFO - 2025-06-30 07:09:09 --> Loader Class Initialized
INFO - 2025-06-30 07:09:09 --> Helper loaded: url_helper
INFO - 2025-06-30 07:09:09 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:09:09 --> Controller Class Initialized
INFO - 2025-06-30 07:09:09 --> Database Driver Class Initialized
INFO - 2025-06-30 07:09:09 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:09:09 --> Upload Class Initialized
INFO - 2025-06-30 07:09:09 --> Form Validation Class Initialized
DEBUG - 2025-06-30 07:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2025-06-30 07:09:09 --> Database Forge Class Initialized
INFO - 2025-06-30 07:09:09 --> Helper loaded: file_helper
INFO - 2025-06-30 07:09:09 --> Language file loaded: language/english/upload_lang.php
ERROR - 2025-06-30 07:09:09 --> The upload path does not appear to be valid.
INFO - 2025-06-30 07:09:09 --> Config Class Initialized
INFO - 2025-06-30 07:09:09 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:09:09 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:09:09 --> Utf8 Class Initialized
INFO - 2025-06-30 07:09:09 --> URI Class Initialized
INFO - 2025-06-30 07:09:09 --> Router Class Initialized
INFO - 2025-06-30 07:09:09 --> Output Class Initialized
INFO - 2025-06-30 07:09:09 --> Security Class Initialized
DEBUG - 2025-06-30 07:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:09:09 --> Input Class Initialized
INFO - 2025-06-30 07:09:09 --> Language Class Initialized
INFO - 2025-06-30 07:09:09 --> Loader Class Initialized
INFO - 2025-06-30 07:09:09 --> Helper loaded: url_helper
INFO - 2025-06-30 07:09:09 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:09:09 --> Controller Class Initialized
INFO - 2025-06-30 07:09:09 --> Database Driver Class Initialized
INFO - 2025-06-30 07:09:09 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:09:09 --> Upload Class Initialized
INFO - 2025-06-30 07:09:09 --> Form Validation Class Initialized
DEBUG - 2025-06-30 07:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2025-06-30 07:09:09 --> Database Forge Class Initialized
INFO - 2025-06-30 07:09:09 --> Helper loaded: file_helper
INFO - 2025-06-30 07:09:09 --> File loaded: /var/www/html/application/views/medical_products/upload_simple.php
INFO - 2025-06-30 07:09:09 --> Final output sent to browser
DEBUG - 2025-06-30 07:09:09 --> Total execution time: 0.1438
INFO - 2025-06-30 07:09:09 --> Config Class Initialized
INFO - 2025-06-30 07:09:09 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:09:09 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:09:09 --> Utf8 Class Initialized
INFO - 2025-06-30 07:09:09 --> URI Class Initialized
INFO - 2025-06-30 07:09:09 --> Router Class Initialized
INFO - 2025-06-30 07:09:09 --> Output Class Initialized
INFO - 2025-06-30 07:09:09 --> Security Class Initialized
DEBUG - 2025-06-30 07:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:09:09 --> Input Class Initialized
INFO - 2025-06-30 07:09:09 --> Language Class Initialized
ERROR - 2025-06-30 07:09:09 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 07:11:47 --> Config Class Initialized
INFO - 2025-06-30 07:11:47 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:11:47 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:11:47 --> Utf8 Class Initialized
INFO - 2025-06-30 07:11:47 --> URI Class Initialized
INFO - 2025-06-30 07:11:47 --> Router Class Initialized
INFO - 2025-06-30 07:11:47 --> Output Class Initialized
INFO - 2025-06-30 07:11:47 --> Security Class Initialized
DEBUG - 2025-06-30 07:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:11:47 --> Input Class Initialized
INFO - 2025-06-30 07:11:47 --> Language Class Initialized
INFO - 2025-06-30 07:11:47 --> Loader Class Initialized
INFO - 2025-06-30 07:11:47 --> Helper loaded: url_helper
INFO - 2025-06-30 07:11:47 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:11:47 --> Controller Class Initialized
INFO - 2025-06-30 07:11:47 --> Database Driver Class Initialized
INFO - 2025-06-30 07:11:47 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:11:47 --> Upload Class Initialized
INFO - 2025-06-30 07:11:47 --> Form Validation Class Initialized
DEBUG - 2025-06-30 07:11:47 --> Session class already loaded. Second attempt ignored.
INFO - 2025-06-30 07:11:47 --> Database Forge Class Initialized
INFO - 2025-06-30 07:11:47 --> Helper loaded: file_helper
INFO - 2025-06-30 07:11:47 --> Language file loaded: language/english/upload_lang.php
ERROR - 2025-06-30 07:11:47 --> The upload path does not appear to be valid.
INFO - 2025-06-30 07:11:47 --> Final output sent to browser
DEBUG - 2025-06-30 07:11:47 --> Total execution time: 0.2118
INFO - 2025-06-30 07:11:47 --> Config Class Initialized
INFO - 2025-06-30 07:11:47 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:11:47 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:11:47 --> Utf8 Class Initialized
INFO - 2025-06-30 07:11:47 --> URI Class Initialized
INFO - 2025-06-30 07:11:47 --> Router Class Initialized
INFO - 2025-06-30 07:11:47 --> Output Class Initialized
INFO - 2025-06-30 07:11:47 --> Security Class Initialized
DEBUG - 2025-06-30 07:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:11:47 --> Input Class Initialized
INFO - 2025-06-30 07:11:47 --> Language Class Initialized
ERROR - 2025-06-30 07:11:47 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 07:15:21 --> Config Class Initialized
INFO - 2025-06-30 07:15:21 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:15:21 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:15:21 --> Utf8 Class Initialized
INFO - 2025-06-30 07:15:21 --> URI Class Initialized
INFO - 2025-06-30 07:15:21 --> Router Class Initialized
INFO - 2025-06-30 07:15:21 --> Output Class Initialized
INFO - 2025-06-30 07:15:21 --> Security Class Initialized
DEBUG - 2025-06-30 07:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:15:21 --> Input Class Initialized
INFO - 2025-06-30 07:15:21 --> Language Class Initialized
INFO - 2025-06-30 07:15:21 --> Loader Class Initialized
INFO - 2025-06-30 07:15:21 --> Helper loaded: url_helper
INFO - 2025-06-30 07:15:21 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:15:21 --> Controller Class Initialized
INFO - 2025-06-30 07:15:21 --> Database Driver Class Initialized
INFO - 2025-06-30 07:15:21 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:15:21 --> Upload Class Initialized
INFO - 2025-06-30 07:15:21 --> Form Validation Class Initialized
DEBUG - 2025-06-30 07:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2025-06-30 07:15:21 --> Database Forge Class Initialized
INFO - 2025-06-30 07:15:21 --> Helper loaded: file_helper
INFO - 2025-06-30 07:15:21 --> File loaded: /var/www/html/application/views/medical_products/upload_simple.php
INFO - 2025-06-30 07:15:21 --> Final output sent to browser
DEBUG - 2025-06-30 07:15:21 --> Total execution time: 0.2194
INFO - 2025-06-30 07:15:21 --> Config Class Initialized
INFO - 2025-06-30 07:15:21 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:15:21 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:15:21 --> Utf8 Class Initialized
INFO - 2025-06-30 07:15:21 --> URI Class Initialized
INFO - 2025-06-30 07:15:21 --> Router Class Initialized
INFO - 2025-06-30 07:15:21 --> Output Class Initialized
INFO - 2025-06-30 07:15:21 --> Security Class Initialized
DEBUG - 2025-06-30 07:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:15:21 --> Input Class Initialized
INFO - 2025-06-30 07:15:21 --> Language Class Initialized
ERROR - 2025-06-30 07:15:21 --> 404 Page Not Found: Well-known/appspecific
INFO - 2025-06-30 07:15:28 --> Config Class Initialized
INFO - 2025-06-30 07:15:28 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:15:28 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:15:28 --> Utf8 Class Initialized
INFO - 2025-06-30 07:15:28 --> URI Class Initialized
INFO - 2025-06-30 07:15:28 --> Router Class Initialized
INFO - 2025-06-30 07:15:28 --> Output Class Initialized
INFO - 2025-06-30 07:15:28 --> Security Class Initialized
DEBUG - 2025-06-30 07:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:15:28 --> Input Class Initialized
INFO - 2025-06-30 07:15:28 --> Language Class Initialized
INFO - 2025-06-30 07:15:28 --> Loader Class Initialized
INFO - 2025-06-30 07:15:28 --> Helper loaded: url_helper
INFO - 2025-06-30 07:15:28 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:15:28 --> Controller Class Initialized
INFO - 2025-06-30 07:15:28 --> Database Driver Class Initialized
INFO - 2025-06-30 07:15:28 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:15:28 --> Upload Class Initialized
INFO - 2025-06-30 07:15:28 --> Form Validation Class Initialized
DEBUG - 2025-06-30 07:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2025-06-30 07:15:28 --> Database Forge Class Initialized
INFO - 2025-06-30 07:15:28 --> Helper loaded: file_helper
INFO - 2025-06-30 07:15:28 --> Language file loaded: language/english/upload_lang.php
ERROR - 2025-06-30 07:15:28 --> The upload path does not appear to be valid.
INFO - 2025-06-30 07:15:28 --> Final output sent to browser
DEBUG - 2025-06-30 07:15:28 --> Total execution time: 0.1922
INFO - 2025-06-30 07:23:33 --> Config Class Initialized
INFO - 2025-06-30 07:23:33 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:23:33 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:23:33 --> Utf8 Class Initialized
INFO - 2025-06-30 07:23:33 --> URI Class Initialized
INFO - 2025-06-30 07:23:33 --> Router Class Initialized
INFO - 2025-06-30 07:23:33 --> Output Class Initialized
INFO - 2025-06-30 07:23:33 --> Security Class Initialized
DEBUG - 2025-06-30 07:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:23:33 --> Input Class Initialized
INFO - 2025-06-30 07:23:33 --> Language Class Initialized
INFO - 2025-06-30 07:23:33 --> Loader Class Initialized
INFO - 2025-06-30 07:23:33 --> Helper loaded: url_helper
INFO - 2025-06-30 07:23:33 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:23:33 --> Controller Class Initialized
INFO - 2025-06-30 07:23:33 --> Database Driver Class Initialized
INFO - 2025-06-30 07:23:33 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:23:33 --> Upload Class Initialized
INFO - 2025-06-30 07:23:33 --> Form Validation Class Initialized
DEBUG - 2025-06-30 07:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2025-06-30 07:23:33 --> Database Forge Class Initialized
INFO - 2025-06-30 07:23:33 --> Helper loaded: file_helper
ERROR - 2025-06-30 07:23:33 --> Severity: error --> Exception: Class "SimpleXLSX" not found /var/www/html/application/controllers/Medical_products.php 939
INFO - 2025-06-30 07:25:30 --> Config Class Initialized
INFO - 2025-06-30 07:25:30 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:25:30 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:25:30 --> Utf8 Class Initialized
INFO - 2025-06-30 07:25:30 --> URI Class Initialized
INFO - 2025-06-30 07:25:30 --> Router Class Initialized
INFO - 2025-06-30 07:25:30 --> Output Class Initialized
INFO - 2025-06-30 07:25:30 --> Security Class Initialized
DEBUG - 2025-06-30 07:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:25:30 --> Input Class Initialized
INFO - 2025-06-30 07:25:30 --> Language Class Initialized
INFO - 2025-06-30 07:25:30 --> Loader Class Initialized
INFO - 2025-06-30 07:25:30 --> Helper loaded: url_helper
INFO - 2025-06-30 07:25:30 --> Helper loaded: form_helper
DEBUG - 2025-06-30 07:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:25:30 --> Controller Class Initialized
INFO - 2025-06-30 07:25:30 --> Database Driver Class Initialized
INFO - 2025-06-30 07:25:30 --> Model "Medical_products_model" initialized
INFO - 2025-06-30 07:25:30 --> Upload Class Initialized
INFO - 2025-06-30 07:25:30 --> Form Validation Class Initialized
DEBUG - 2025-06-30 07:25:30 --> Session class already loaded. Second attempt ignored.
INFO - 2025-06-30 07:25:30 --> Database Forge Class Initialized
INFO - 2025-06-30 07:25:30 --> Helper loaded: file_helper
ERROR - 2025-06-30 07:25:30 --> Severity: error --> Exception: Class "SimpleXLSX" not found /var/www/html/application/controllers/Medical_products.php 950
ERROR - 2025-06-30 07:30:54 --> Severity: error --> Exception: Class "SimpleXLSX" not found /var/www/html/application/controllers/Medical_products.php 950
ERROR - 2025-06-30 07:34:21 --> Severity: Warning --> require_once(/var/www/html/application/third_party/PHPExcel/PHPExcel.php): Failed to open stream: No such file or directory /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:34:21 --> Severity: error --> Exception: Failed opening required '/var/www/html/application/third_party/PHPExcel/PHPExcel.php' (include_path='.:/usr/share/php') /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:36:33 --> Severity: Warning --> require_once(/var/www/html/application/third_party/PHPExcel/PHPExcel.php): Failed to open stream: No such file or directory /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:36:33 --> Severity: error --> Exception: Failed opening required '/var/www/html/application/third_party/PHPExcel/PHPExcel.php' (include_path='.:/usr/share/php') /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:38:19 --> Severity: Warning --> require_once(/var/www/html/application/third_party/PHPExcel/PHPExcel.php): Failed to open stream: No such file or directory /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:38:19 --> Severity: error --> Exception: Failed opening required '/var/www/html/application/third_party/PHPExcel/PHPExcel.php' (include_path='.:/usr/share/php') /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:38:33 --> Severity: Warning --> require_once(/var/www/html/application/third_party/PHPExcel/PHPExcel.php): Failed to open stream: No such file or directory /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:38:33 --> Severity: error --> Exception: Failed opening required '/var/www/html/application/third_party/PHPExcel/PHPExcel.php' (include_path='.:/usr/share/php') /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:38:35 --> Severity: Warning --> require_once(/var/www/html/application/third_party/PHPExcel/PHPExcel.php): Failed to open stream: No such file or directory /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:38:35 --> Severity: error --> Exception: Failed opening required '/var/www/html/application/third_party/PHPExcel/PHPExcel.php' (include_path='.:/usr/share/php') /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:38:36 --> Severity: Warning --> require_once(/var/www/html/application/third_party/PHPExcel/PHPExcel.php): Failed to open stream: No such file or directory /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:38:36 --> Severity: error --> Exception: Failed opening required '/var/www/html/application/third_party/PHPExcel/PHPExcel.php' (include_path='.:/usr/share/php') /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:38:39 --> Severity: Warning --> require_once(/var/www/html/application/third_party/PHPExcel/PHPExcel.php): Failed to open stream: No such file or directory /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:38:39 --> Severity: error --> Exception: Failed opening required '/var/www/html/application/third_party/PHPExcel/PHPExcel.php' (include_path='.:/usr/share/php') /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:38:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /var/www/html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-06-30 07:38:54 --> Unable to connect to the database
ERROR - 2025-06-30 07:38:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /var/www/html/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2025-06-30 07:38:55 --> Unable to connect to the database
ERROR - 2025-06-30 07:38:57 --> Severity: Warning --> require_once(/var/www/html/application/third_party/PHPExcel/PHPExcel.php): Failed to open stream: No such file or directory /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:38:57 --> Severity: error --> Exception: Failed opening required '/var/www/html/application/third_party/PHPExcel/PHPExcel.php' (include_path='.:/usr/share/php') /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:39:03 --> Severity: Warning --> require_once(/var/www/html/application/third_party/PHPExcel/PHPExcel.php): Failed to open stream: No such file or directory /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:39:03 --> Severity: error --> Exception: Failed opening required '/var/www/html/application/third_party/PHPExcel/PHPExcel.php' (include_path='.:/usr/share/php') /var/www/html/application/libraries/Excel.php 4
ERROR - 2025-06-30 07:43:43 --> Severity: Compile Error --> Cannot redeclare Medical_products::search() /var/www/html/application/controllers/Medical_products.php 126
ERROR - 2025-06-30 07:43:56 --> Severity: Compile Error --> Cannot redeclare Medical_products::search() /var/www/html/application/controllers/Medical_products.php 126
INFO - 2025-06-30 07:49:06 --> Config Class Initialized
INFO - 2025-06-30 07:49:06 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:49:06 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:49:06 --> Utf8 Class Initialized
INFO - 2025-06-30 07:49:06 --> URI Class Initialized
INFO - 2025-06-30 07:49:06 --> Router Class Initialized
INFO - 2025-06-30 07:49:06 --> Output Class Initialized
INFO - 2025-06-30 07:49:06 --> Security Class Initialized
DEBUG - 2025-06-30 07:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:49:06 --> Input Class Initialized
INFO - 2025-06-30 07:49:06 --> Language Class Initialized
ERROR - 2025-06-30 07:49:06 --> Severity: Compile Error --> Cannot redeclare Medical_products::search() /var/www/html/application/controllers/Medical_products.php 120
INFO - 2025-06-30 07:50:42 --> Config Class Initialized
INFO - 2025-06-30 07:50:42 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:50:42 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:50:42 --> Utf8 Class Initialized
INFO - 2025-06-30 07:50:42 --> URI Class Initialized
DEBUG - 2025-06-30 07:50:42 --> No URI present. Default controller set.
INFO - 2025-06-30 07:50:42 --> Router Class Initialized
INFO - 2025-06-30 07:50:42 --> Output Class Initialized
INFO - 2025-06-30 07:50:42 --> Security Class Initialized
DEBUG - 2025-06-30 07:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:50:42 --> Input Class Initialized
INFO - 2025-06-30 07:50:42 --> Language Class Initialized
INFO - 2025-06-30 07:50:42 --> Loader Class Initialized
INFO - 2025-06-30 07:50:42 --> Helper loaded: url_helper
INFO - 2025-06-30 07:50:42 --> Helper loaded: form_helper
INFO - 2025-06-30 07:50:42 --> Helper loaded: file_helper
INFO - 2025-06-30 07:50:42 --> Database Driver Class Initialized
DEBUG - 2025-06-30 07:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:50:42 --> Form Validation Class Initialized
INFO - 2025-06-30 07:50:42 --> Controller Class Initialized
INFO - 2025-06-30 07:50:42 --> File loaded: /var/www/html/application/views/main_dashboard.php
INFO - 2025-06-30 07:50:42 --> Final output sent to browser
DEBUG - 2025-06-30 07:50:42 --> Total execution time: 0.2017
INFO - 2025-06-30 07:50:43 --> Config Class Initialized
INFO - 2025-06-30 07:50:43 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:50:43 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:50:43 --> Utf8 Class Initialized
INFO - 2025-06-30 07:50:43 --> URI Class Initialized
INFO - 2025-06-30 07:50:43 --> Router Class Initialized
INFO - 2025-06-30 07:50:43 --> Output Class Initialized
INFO - 2025-06-30 07:50:43 --> Security Class Initialized
DEBUG - 2025-06-30 07:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:50:43 --> Input Class Initialized
INFO - 2025-06-30 07:50:43 --> Language Class Initialized
INFO - 2025-06-30 07:50:43 --> Config Class Initialized
INFO - 2025-06-30 07:50:43 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:50:43 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:50:43 --> Utf8 Class Initialized
INFO - 2025-06-30 07:50:43 --> URI Class Initialized
DEBUG - 2025-06-30 07:50:43 --> No URI present. Default controller set.
INFO - 2025-06-30 07:50:43 --> Router Class Initialized
INFO - 2025-06-30 07:50:43 --> Output Class Initialized
INFO - 2025-06-30 07:50:43 --> Security Class Initialized
DEBUG - 2025-06-30 07:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:50:43 --> Input Class Initialized
INFO - 2025-06-30 07:50:43 --> Language Class Initialized
INFO - 2025-06-30 07:50:43 --> Loader Class Initialized
INFO - 2025-06-30 07:50:43 --> Helper loaded: url_helper
INFO - 2025-06-30 07:50:43 --> Helper loaded: form_helper
INFO - 2025-06-30 07:50:43 --> Helper loaded: file_helper
INFO - 2025-06-30 07:50:43 --> Database Driver Class Initialized
DEBUG - 2025-06-30 07:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:50:44 --> Form Validation Class Initialized
INFO - 2025-06-30 07:50:44 --> Controller Class Initialized
INFO - 2025-06-30 07:50:44 --> File loaded: /var/www/html/application/views/main_dashboard.php
INFO - 2025-06-30 07:50:44 --> Final output sent to browser
DEBUG - 2025-06-30 07:50:44 --> Total execution time: 0.1416
INFO - 2025-06-30 07:50:44 --> Config Class Initialized
INFO - 2025-06-30 07:50:44 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:50:44 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:50:44 --> Utf8 Class Initialized
INFO - 2025-06-30 07:50:44 --> URI Class Initialized
INFO - 2025-06-30 07:50:44 --> Router Class Initialized
INFO - 2025-06-30 07:50:44 --> Output Class Initialized
INFO - 2025-06-30 07:50:44 --> Security Class Initialized
DEBUG - 2025-06-30 07:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:50:44 --> Input Class Initialized
INFO - 2025-06-30 07:50:44 --> Language Class Initialized
INFO - 2025-06-30 07:50:45 --> Config Class Initialized
INFO - 2025-06-30 07:50:45 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:50:45 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:50:45 --> Utf8 Class Initialized
INFO - 2025-06-30 07:50:45 --> URI Class Initialized
INFO - 2025-06-30 07:50:45 --> Router Class Initialized
INFO - 2025-06-30 07:50:45 --> Output Class Initialized
INFO - 2025-06-30 07:50:45 --> Security Class Initialized
DEBUG - 2025-06-30 07:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:50:45 --> Input Class Initialized
INFO - 2025-06-30 07:50:45 --> Language Class Initialized
ERROR - 2025-06-30 07:50:45 --> Severity: Compile Error --> Cannot redeclare Medical_products::search() /var/www/html/application/controllers/Medical_products.php 120
INFO - 2025-06-30 07:52:48 --> Config Class Initialized
INFO - 2025-06-30 07:52:48 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:52:49 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:52:49 --> Utf8 Class Initialized
INFO - 2025-06-30 07:52:49 --> URI Class Initialized
INFO - 2025-06-30 07:52:49 --> Router Class Initialized
INFO - 2025-06-30 07:52:49 --> Output Class Initialized
INFO - 2025-06-30 07:52:49 --> Security Class Initialized
DEBUG - 2025-06-30 07:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:52:49 --> Input Class Initialized
INFO - 2025-06-30 07:52:49 --> Language Class Initialized
INFO - 2025-06-30 07:52:49 --> Config Class Initialized
INFO - 2025-06-30 07:52:49 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:52:49 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:52:49 --> Utf8 Class Initialized
INFO - 2025-06-30 07:52:49 --> URI Class Initialized
INFO - 2025-06-30 07:52:49 --> Router Class Initialized
INFO - 2025-06-30 07:52:49 --> Output Class Initialized
INFO - 2025-06-30 07:52:49 --> Security Class Initialized
DEBUG - 2025-06-30 07:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:52:49 --> Input Class Initialized
INFO - 2025-06-30 07:52:49 --> Language Class Initialized
INFO - 2025-06-30 07:52:49 --> Config Class Initialized
INFO - 2025-06-30 07:52:49 --> Hooks Class Initialized
DEBUG - 2025-06-30 07:52:49 --> UTF-8 Support Enabled
INFO - 2025-06-30 07:52:49 --> Utf8 Class Initialized
INFO - 2025-06-30 07:52:49 --> URI Class Initialized
DEBUG - 2025-06-30 07:52:49 --> No URI present. Default controller set.
INFO - 2025-06-30 07:52:49 --> Router Class Initialized
INFO - 2025-06-30 07:52:49 --> Output Class Initialized
INFO - 2025-06-30 07:52:49 --> Security Class Initialized
DEBUG - 2025-06-30 07:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 07:52:49 --> Input Class Initialized
INFO - 2025-06-30 07:52:49 --> Language Class Initialized
INFO - 2025-06-30 07:52:49 --> Loader Class Initialized
INFO - 2025-06-30 07:52:49 --> Helper loaded: url_helper
INFO - 2025-06-30 07:52:49 --> Helper loaded: form_helper
INFO - 2025-06-30 07:52:49 --> Helper loaded: file_helper
INFO - 2025-06-30 07:52:49 --> Database Driver Class Initialized
DEBUG - 2025-06-30 07:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 07:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 07:52:49 --> Form Validation Class Initialized
INFO - 2025-06-30 07:52:49 --> Upload Class Initialized
ERROR - 2025-06-30 07:52:49 --> Unable to load the requested class: Input
INFO - 2025-06-30 08:31:55 --> Config Class Initialized
INFO - 2025-06-30 08:31:55 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:31:55 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:31:55 --> Utf8 Class Initialized
INFO - 2025-06-30 08:31:55 --> URI Class Initialized
DEBUG - 2025-06-30 08:31:55 --> No URI present. Default controller set.
INFO - 2025-06-30 08:31:55 --> Router Class Initialized
INFO - 2025-06-30 08:31:55 --> Output Class Initialized
INFO - 2025-06-30 08:31:55 --> Security Class Initialized
DEBUG - 2025-06-30 08:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:31:55 --> Input Class Initialized
INFO - 2025-06-30 08:31:55 --> Language Class Initialized
INFO - 2025-06-30 08:31:55 --> Loader Class Initialized
INFO - 2025-06-30 08:31:55 --> Helper loaded: url_helper
INFO - 2025-06-30 08:31:55 --> Helper loaded: form_helper
INFO - 2025-06-30 08:31:55 --> Helper loaded: file_helper
INFO - 2025-06-30 08:31:55 --> Database Driver Class Initialized
DEBUG - 2025-06-30 08:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 08:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 08:31:55 --> Form Validation Class Initialized
INFO - 2025-06-30 08:31:55 --> Upload Class Initialized
ERROR - 2025-06-30 08:31:55 --> Unable to load the requested class: Input
INFO - 2025-06-30 08:33:21 --> Config Class Initialized
INFO - 2025-06-30 08:33:21 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:33:21 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:33:21 --> Utf8 Class Initialized
INFO - 2025-06-30 08:33:21 --> URI Class Initialized
DEBUG - 2025-06-30 08:33:21 --> No URI present. Default controller set.
INFO - 2025-06-30 08:33:21 --> Router Class Initialized
INFO - 2025-06-30 08:33:21 --> Output Class Initialized
INFO - 2025-06-30 08:33:21 --> Security Class Initialized
DEBUG - 2025-06-30 08:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:33:21 --> Input Class Initialized
INFO - 2025-06-30 08:33:21 --> Language Class Initialized
INFO - 2025-06-30 08:33:21 --> Loader Class Initialized
INFO - 2025-06-30 08:33:21 --> Helper loaded: url_helper
INFO - 2025-06-30 08:33:21 --> Helper loaded: form_helper
INFO - 2025-06-30 08:33:21 --> Helper loaded: file_helper
INFO - 2025-06-30 08:33:21 --> Database Driver Class Initialized
DEBUG - 2025-06-30 08:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 08:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 08:33:21 --> Form Validation Class Initialized
INFO - 2025-06-30 08:33:21 --> Upload Class Initialized
INFO - 2025-06-30 08:33:21 --> Controller Class Initialized
INFO - 2025-06-30 08:33:21 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-06-30 08:33:21 --> Final output sent to browser
DEBUG - 2025-06-30 08:33:21 --> Total execution time: 0.2563
INFO - 2025-06-30 08:33:21 --> Config Class Initialized
INFO - 2025-06-30 08:33:21 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:33:21 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:33:21 --> Utf8 Class Initialized
INFO - 2025-06-30 08:33:21 --> URI Class Initialized
INFO - 2025-06-30 08:33:21 --> Router Class Initialized
INFO - 2025-06-30 08:33:21 --> Output Class Initialized
INFO - 2025-06-30 08:33:21 --> Security Class Initialized
DEBUG - 2025-06-30 08:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:33:21 --> Input Class Initialized
INFO - 2025-06-30 08:33:21 --> Language Class Initialized
INFO - 2025-06-30 08:33:37 --> Config Class Initialized
INFO - 2025-06-30 08:33:37 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:33:37 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:33:37 --> Utf8 Class Initialized
INFO - 2025-06-30 08:33:37 --> URI Class Initialized
DEBUG - 2025-06-30 08:33:37 --> No URI present. Default controller set.
INFO - 2025-06-30 08:33:37 --> Router Class Initialized
INFO - 2025-06-30 08:33:37 --> Output Class Initialized
INFO - 2025-06-30 08:33:37 --> Security Class Initialized
DEBUG - 2025-06-30 08:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:33:37 --> Input Class Initialized
INFO - 2025-06-30 08:33:37 --> Language Class Initialized
INFO - 2025-06-30 08:33:37 --> Loader Class Initialized
INFO - 2025-06-30 08:33:37 --> Helper loaded: url_helper
INFO - 2025-06-30 08:33:37 --> Helper loaded: form_helper
INFO - 2025-06-30 08:33:37 --> Helper loaded: file_helper
INFO - 2025-06-30 08:33:37 --> Database Driver Class Initialized
DEBUG - 2025-06-30 08:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 08:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 08:33:37 --> Form Validation Class Initialized
INFO - 2025-06-30 08:33:37 --> Upload Class Initialized
INFO - 2025-06-30 08:33:37 --> Controller Class Initialized
INFO - 2025-06-30 08:33:37 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-06-30 08:33:37 --> Final output sent to browser
DEBUG - 2025-06-30 08:33:37 --> Total execution time: 0.1729
INFO - 2025-06-30 08:33:37 --> Config Class Initialized
INFO - 2025-06-30 08:33:37 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:33:37 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:33:37 --> Utf8 Class Initialized
INFO - 2025-06-30 08:33:37 --> URI Class Initialized
INFO - 2025-06-30 08:33:37 --> Router Class Initialized
INFO - 2025-06-30 08:33:37 --> Output Class Initialized
INFO - 2025-06-30 08:33:37 --> Security Class Initialized
DEBUG - 2025-06-30 08:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:33:37 --> Input Class Initialized
INFO - 2025-06-30 08:33:37 --> Language Class Initialized
INFO - 2025-06-30 08:33:42 --> Config Class Initialized
INFO - 2025-06-30 08:33:42 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:33:42 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:33:42 --> Utf8 Class Initialized
INFO - 2025-06-30 08:33:42 --> URI Class Initialized
INFO - 2025-06-30 08:33:42 --> Router Class Initialized
INFO - 2025-06-30 08:33:42 --> Output Class Initialized
INFO - 2025-06-30 08:33:42 --> Security Class Initialized
DEBUG - 2025-06-30 08:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:33:42 --> Input Class Initialized
INFO - 2025-06-30 08:33:42 --> Language Class Initialized
ERROR - 2025-06-30 08:33:42 --> Severity: Compile Error --> Cannot redeclare Medical_products::search() /var/www/html/source/application/controllers/Medical_products.php 157
INFO - 2025-06-30 08:33:45 --> Config Class Initialized
INFO - 2025-06-30 08:33:45 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:33:45 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:33:45 --> Utf8 Class Initialized
INFO - 2025-06-30 08:33:45 --> URI Class Initialized
INFO - 2025-06-30 08:33:45 --> Router Class Initialized
INFO - 2025-06-30 08:33:45 --> Output Class Initialized
INFO - 2025-06-30 08:33:45 --> Security Class Initialized
DEBUG - 2025-06-30 08:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:33:45 --> Input Class Initialized
INFO - 2025-06-30 08:33:45 --> Language Class Initialized
INFO - 2025-06-30 08:33:45 --> Config Class Initialized
INFO - 2025-06-30 08:33:45 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:33:45 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:33:45 --> Utf8 Class Initialized
INFO - 2025-06-30 08:33:45 --> URI Class Initialized
INFO - 2025-06-30 08:33:45 --> Router Class Initialized
INFO - 2025-06-30 08:33:45 --> Output Class Initialized
INFO - 2025-06-30 08:33:45 --> Security Class Initialized
DEBUG - 2025-06-30 08:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:33:45 --> Input Class Initialized
INFO - 2025-06-30 08:33:45 --> Language Class Initialized
INFO - 2025-06-30 08:33:47 --> Config Class Initialized
INFO - 2025-06-30 08:33:47 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:33:47 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:33:47 --> Utf8 Class Initialized
INFO - 2025-06-30 08:33:47 --> URI Class Initialized
INFO - 2025-06-30 08:33:47 --> Router Class Initialized
INFO - 2025-06-30 08:33:47 --> Output Class Initialized
INFO - 2025-06-30 08:33:47 --> Security Class Initialized
DEBUG - 2025-06-30 08:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:33:47 --> Input Class Initialized
INFO - 2025-06-30 08:33:47 --> Language Class Initialized
ERROR - 2025-06-30 08:33:47 --> Severity: Compile Error --> Cannot redeclare Medical_products::search() /var/www/html/source/application/controllers/Medical_products.php 157
INFO - 2025-06-30 08:33:49 --> Config Class Initialized
INFO - 2025-06-30 08:33:49 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:33:49 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:33:49 --> Utf8 Class Initialized
INFO - 2025-06-30 08:33:49 --> URI Class Initialized
INFO - 2025-06-30 08:33:49 --> Router Class Initialized
INFO - 2025-06-30 08:33:49 --> Output Class Initialized
INFO - 2025-06-30 08:33:49 --> Security Class Initialized
DEBUG - 2025-06-30 08:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:33:49 --> Input Class Initialized
INFO - 2025-06-30 08:33:49 --> Language Class Initialized
INFO - 2025-06-30 08:33:49 --> Config Class Initialized
INFO - 2025-06-30 08:33:49 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:33:49 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:33:49 --> Utf8 Class Initialized
INFO - 2025-06-30 08:33:49 --> URI Class Initialized
INFO - 2025-06-30 08:33:49 --> Router Class Initialized
INFO - 2025-06-30 08:33:49 --> Output Class Initialized
INFO - 2025-06-30 08:33:49 --> Security Class Initialized
DEBUG - 2025-06-30 08:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:33:49 --> Input Class Initialized
INFO - 2025-06-30 08:33:49 --> Language Class Initialized
INFO - 2025-06-30 08:34:03 --> Config Class Initialized
INFO - 2025-06-30 08:34:03 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:34:03 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:34:03 --> Utf8 Class Initialized
INFO - 2025-06-30 08:34:03 --> URI Class Initialized
DEBUG - 2025-06-30 08:34:03 --> No URI present. Default controller set.
INFO - 2025-06-30 08:34:03 --> Router Class Initialized
INFO - 2025-06-30 08:34:03 --> Output Class Initialized
INFO - 2025-06-30 08:34:03 --> Security Class Initialized
DEBUG - 2025-06-30 08:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:34:03 --> Input Class Initialized
INFO - 2025-06-30 08:34:03 --> Language Class Initialized
INFO - 2025-06-30 08:34:03 --> Loader Class Initialized
INFO - 2025-06-30 08:34:03 --> Helper loaded: url_helper
INFO - 2025-06-30 08:34:03 --> Helper loaded: form_helper
INFO - 2025-06-30 08:34:03 --> Helper loaded: file_helper
INFO - 2025-06-30 08:34:03 --> Database Driver Class Initialized
DEBUG - 2025-06-30 08:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 08:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 08:34:03 --> Form Validation Class Initialized
INFO - 2025-06-30 08:34:03 --> Upload Class Initialized
INFO - 2025-06-30 08:34:03 --> Controller Class Initialized
INFO - 2025-06-30 08:34:03 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-06-30 08:34:03 --> Final output sent to browser
DEBUG - 2025-06-30 08:34:03 --> Total execution time: 0.1671
INFO - 2025-06-30 08:34:03 --> Config Class Initialized
INFO - 2025-06-30 08:34:03 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:34:03 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:34:03 --> Utf8 Class Initialized
INFO - 2025-06-30 08:34:03 --> URI Class Initialized
INFO - 2025-06-30 08:34:03 --> Router Class Initialized
INFO - 2025-06-30 08:34:03 --> Output Class Initialized
INFO - 2025-06-30 08:34:03 --> Security Class Initialized
DEBUG - 2025-06-30 08:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:34:03 --> Input Class Initialized
INFO - 2025-06-30 08:34:03 --> Language Class Initialized
INFO - 2025-06-30 08:36:15 --> Config Class Initialized
INFO - 2025-06-30 08:36:15 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:36:15 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:36:15 --> Utf8 Class Initialized
INFO - 2025-06-30 08:36:15 --> URI Class Initialized
DEBUG - 2025-06-30 08:36:15 --> No URI present. Default controller set.
INFO - 2025-06-30 08:36:15 --> Router Class Initialized
INFO - 2025-06-30 08:36:15 --> Output Class Initialized
INFO - 2025-06-30 08:36:15 --> Security Class Initialized
DEBUG - 2025-06-30 08:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:36:15 --> Input Class Initialized
INFO - 2025-06-30 08:36:15 --> Language Class Initialized
INFO - 2025-06-30 08:36:15 --> Loader Class Initialized
INFO - 2025-06-30 08:36:15 --> Helper loaded: url_helper
INFO - 2025-06-30 08:36:15 --> Helper loaded: form_helper
INFO - 2025-06-30 08:36:15 --> Helper loaded: file_helper
INFO - 2025-06-30 08:36:15 --> Database Driver Class Initialized
DEBUG - 2025-06-30 08:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 08:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 08:36:15 --> Form Validation Class Initialized
INFO - 2025-06-30 08:36:15 --> Upload Class Initialized
INFO - 2025-06-30 08:36:15 --> Controller Class Initialized
INFO - 2025-06-30 08:36:15 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-06-30 08:36:15 --> Final output sent to browser
DEBUG - 2025-06-30 08:36:15 --> Total execution time: 0.3169
INFO - 2025-06-30 08:36:15 --> Config Class Initialized
INFO - 2025-06-30 08:36:15 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:36:15 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:36:15 --> Utf8 Class Initialized
INFO - 2025-06-30 08:36:15 --> URI Class Initialized
INFO - 2025-06-30 08:36:15 --> Router Class Initialized
INFO - 2025-06-30 08:36:15 --> Output Class Initialized
INFO - 2025-06-30 08:36:16 --> Security Class Initialized
DEBUG - 2025-06-30 08:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:36:16 --> Input Class Initialized
INFO - 2025-06-30 08:36:16 --> Language Class Initialized
INFO - 2025-06-30 08:38:42 --> Config Class Initialized
INFO - 2025-06-30 08:38:42 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:38:42 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:38:42 --> Utf8 Class Initialized
INFO - 2025-06-30 08:38:42 --> URI Class Initialized
DEBUG - 2025-06-30 08:38:42 --> No URI present. Default controller set.
INFO - 2025-06-30 08:38:42 --> Router Class Initialized
INFO - 2025-06-30 08:38:42 --> Output Class Initialized
INFO - 2025-06-30 08:38:42 --> Security Class Initialized
DEBUG - 2025-06-30 08:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:38:42 --> Input Class Initialized
INFO - 2025-06-30 08:38:42 --> Language Class Initialized
INFO - 2025-06-30 08:38:42 --> Loader Class Initialized
INFO - 2025-06-30 08:38:42 --> Helper loaded: url_helper
INFO - 2025-06-30 08:38:42 --> Helper loaded: form_helper
INFO - 2025-06-30 08:38:42 --> Helper loaded: file_helper
INFO - 2025-06-30 08:38:42 --> Database Driver Class Initialized
DEBUG - 2025-06-30 08:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 08:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 08:38:42 --> Form Validation Class Initialized
INFO - 2025-06-30 08:38:42 --> Upload Class Initialized
INFO - 2025-06-30 08:38:42 --> Controller Class Initialized
INFO - 2025-06-30 08:38:42 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-06-30 08:38:42 --> Final output sent to browser
DEBUG - 2025-06-30 08:38:42 --> Total execution time: 0.1750
INFO - 2025-06-30 08:38:42 --> Config Class Initialized
INFO - 2025-06-30 08:38:42 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:38:42 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:38:42 --> Utf8 Class Initialized
INFO - 2025-06-30 08:38:42 --> URI Class Initialized
INFO - 2025-06-30 08:38:42 --> Router Class Initialized
INFO - 2025-06-30 08:38:42 --> Output Class Initialized
INFO - 2025-06-30 08:38:42 --> Security Class Initialized
DEBUG - 2025-06-30 08:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:38:42 --> Input Class Initialized
INFO - 2025-06-30 08:38:42 --> Language Class Initialized
INFO - 2025-06-30 08:38:52 --> Config Class Initialized
INFO - 2025-06-30 08:38:52 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:38:52 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:38:52 --> Utf8 Class Initialized
INFO - 2025-06-30 08:38:52 --> URI Class Initialized
DEBUG - 2025-06-30 08:38:52 --> No URI present. Default controller set.
INFO - 2025-06-30 08:38:52 --> Router Class Initialized
INFO - 2025-06-30 08:38:52 --> Output Class Initialized
INFO - 2025-06-30 08:38:52 --> Security Class Initialized
DEBUG - 2025-06-30 08:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:38:52 --> Input Class Initialized
INFO - 2025-06-30 08:38:52 --> Language Class Initialized
INFO - 2025-06-30 08:38:52 --> Loader Class Initialized
INFO - 2025-06-30 08:38:52 --> Helper loaded: url_helper
INFO - 2025-06-30 08:38:52 --> Helper loaded: form_helper
INFO - 2025-06-30 08:38:52 --> Helper loaded: file_helper
INFO - 2025-06-30 08:38:52 --> Database Driver Class Initialized
DEBUG - 2025-06-30 08:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 08:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 08:38:52 --> Form Validation Class Initialized
INFO - 2025-06-30 08:38:52 --> Upload Class Initialized
INFO - 2025-06-30 08:38:52 --> Controller Class Initialized
INFO - 2025-06-30 08:38:52 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-06-30 08:38:52 --> Final output sent to browser
DEBUG - 2025-06-30 08:38:52 --> Total execution time: 0.1741
INFO - 2025-06-30 08:38:53 --> Config Class Initialized
INFO - 2025-06-30 08:38:53 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:38:53 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:38:53 --> Utf8 Class Initialized
INFO - 2025-06-30 08:38:53 --> URI Class Initialized
INFO - 2025-06-30 08:38:53 --> Router Class Initialized
INFO - 2025-06-30 08:38:53 --> Output Class Initialized
INFO - 2025-06-30 08:38:53 --> Security Class Initialized
DEBUG - 2025-06-30 08:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:38:53 --> Input Class Initialized
INFO - 2025-06-30 08:38:53 --> Language Class Initialized
INFO - 2025-06-30 08:38:54 --> Config Class Initialized
INFO - 2025-06-30 08:38:54 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:38:54 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:38:54 --> Utf8 Class Initialized
INFO - 2025-06-30 08:38:54 --> URI Class Initialized
DEBUG - 2025-06-30 08:38:54 --> No URI present. Default controller set.
INFO - 2025-06-30 08:38:54 --> Router Class Initialized
INFO - 2025-06-30 08:38:54 --> Output Class Initialized
INFO - 2025-06-30 08:38:54 --> Security Class Initialized
DEBUG - 2025-06-30 08:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:38:54 --> Input Class Initialized
INFO - 2025-06-30 08:38:54 --> Language Class Initialized
INFO - 2025-06-30 08:38:54 --> Loader Class Initialized
INFO - 2025-06-30 08:38:54 --> Helper loaded: url_helper
INFO - 2025-06-30 08:38:54 --> Helper loaded: form_helper
INFO - 2025-06-30 08:38:54 --> Helper loaded: file_helper
INFO - 2025-06-30 08:38:54 --> Database Driver Class Initialized
DEBUG - 2025-06-30 08:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 08:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 08:38:54 --> Form Validation Class Initialized
INFO - 2025-06-30 08:38:54 --> Upload Class Initialized
INFO - 2025-06-30 08:38:54 --> Controller Class Initialized
INFO - 2025-06-30 08:38:54 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-06-30 08:38:54 --> Final output sent to browser
DEBUG - 2025-06-30 08:38:54 --> Total execution time: 0.1259
INFO - 2025-06-30 08:38:54 --> Config Class Initialized
INFO - 2025-06-30 08:38:54 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:38:54 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:38:54 --> Utf8 Class Initialized
INFO - 2025-06-30 08:38:54 --> URI Class Initialized
INFO - 2025-06-30 08:38:54 --> Router Class Initialized
INFO - 2025-06-30 08:38:54 --> Output Class Initialized
INFO - 2025-06-30 08:38:54 --> Security Class Initialized
DEBUG - 2025-06-30 08:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:38:54 --> Input Class Initialized
INFO - 2025-06-30 08:38:54 --> Language Class Initialized
INFO - 2025-06-30 08:41:05 --> Config Class Initialized
INFO - 2025-06-30 08:41:05 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:41:05 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:41:05 --> Utf8 Class Initialized
INFO - 2025-06-30 08:41:05 --> URI Class Initialized
DEBUG - 2025-06-30 08:41:05 --> No URI present. Default controller set.
INFO - 2025-06-30 08:41:05 --> Router Class Initialized
INFO - 2025-06-30 08:41:05 --> Output Class Initialized
INFO - 2025-06-30 08:41:05 --> Security Class Initialized
DEBUG - 2025-06-30 08:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:41:05 --> Input Class Initialized
INFO - 2025-06-30 08:41:05 --> Language Class Initialized
INFO - 2025-06-30 08:41:05 --> Loader Class Initialized
INFO - 2025-06-30 08:41:05 --> Helper loaded: url_helper
INFO - 2025-06-30 08:41:05 --> Helper loaded: form_helper
INFO - 2025-06-30 08:41:05 --> Helper loaded: file_helper
INFO - 2025-06-30 08:41:05 --> Database Driver Class Initialized
DEBUG - 2025-06-30 08:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 08:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 08:41:05 --> Form Validation Class Initialized
INFO - 2025-06-30 08:41:05 --> Upload Class Initialized
INFO - 2025-06-30 08:41:05 --> Controller Class Initialized
INFO - 2025-06-30 08:41:05 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-06-30 08:41:05 --> Final output sent to browser
DEBUG - 2025-06-30 08:41:05 --> Total execution time: 0.1710
INFO - 2025-06-30 08:41:06 --> Config Class Initialized
INFO - 2025-06-30 08:41:06 --> Hooks Class Initialized
DEBUG - 2025-06-30 08:41:06 --> UTF-8 Support Enabled
INFO - 2025-06-30 08:41:06 --> Utf8 Class Initialized
INFO - 2025-06-30 08:41:06 --> URI Class Initialized
DEBUG - 2025-06-30 08:41:06 --> No URI present. Default controller set.
INFO - 2025-06-30 08:41:06 --> Router Class Initialized
INFO - 2025-06-30 08:41:06 --> Output Class Initialized
INFO - 2025-06-30 08:41:06 --> Security Class Initialized
DEBUG - 2025-06-30 08:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-30 08:41:06 --> Input Class Initialized
INFO - 2025-06-30 08:41:06 --> Language Class Initialized
INFO - 2025-06-30 08:41:06 --> Loader Class Initialized
INFO - 2025-06-30 08:41:06 --> Helper loaded: url_helper
INFO - 2025-06-30 08:41:06 --> Helper loaded: form_helper
INFO - 2025-06-30 08:41:06 --> Helper loaded: file_helper
INFO - 2025-06-30 08:41:06 --> Database Driver Class Initialized
DEBUG - 2025-06-30 08:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-30 08:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-30 08:41:06 --> Form Validation Class Initialized
INFO - 2025-06-30 08:41:06 --> Upload Class Initialized
INFO - 2025-06-30 08:41:06 --> Controller Class Initialized
INFO - 2025-06-30 08:41:06 --> File loaded: /var/www/html/source/application/views/main_dashboard.php
INFO - 2025-06-30 08:41:06 --> Final output sent to browser
DEBUG - 2025-06-30 08:41:06 --> Total execution time: 0.1342
