<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title) ? $title : '의료제품 엑셀 업로드' ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .upload-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            margin-top: 2rem;
        }
        .drag-drop-zone {
            border: 2px dashed #007bff;
            border-radius: 8px;
            padding: 3rem 2rem;
            text-align: center;
            background: #f8f9ff;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .drag-drop-zone:hover {
            border-color: #0056b3;
            background: #e6f3ff;
        }
        .drag-drop-zone.dragover {
            border-color: #28a745;
            background: #f0fff4;
        }
        .file-info {
            background: #e9ecef;
            border-radius: 5px;
            padding: 1rem;
            margin-top: 1rem;
            display: none;
        }
        .preview-table {
            max-height: 400px;
            overflow-y: auto;
            margin-top: 1rem;
        }
        .error-message {
            color: #dc3545;
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
            padding: 0.75rem;
            margin-top: 1rem;
        }
        .success-message {
            color: #155724;
            background: #d4edda;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            padding: 0.75rem;
            margin-top: 1rem;
        }
        .progress-container {
            display: none;
            margin-top: 1rem;
        }
        .btn-upload {
            background: linear-gradient(45deg, #007bff, #0056b3);
            border: none;
            padding: 0.75rem 2rem;
            font-weight: bold;
        }
        .btn-upload:hover {
            background: linear-gradient(45deg, #0056b3, #004085);
        }
        .format-guide {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 5px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        .column-info {
            background: #e3f2fd;
            border: 1px solid #bbdefb;
            border-radius: 5px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        .log-sidebar {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 1.5rem;
            margin-top: 2rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .log-item {
            background: white;
            border-radius: 5px;
            padding: 1rem;
            margin-bottom: 1rem;
            border-left: 4px solid #007bff;
            transition: all 0.3s ease;
        }
        .log-item:hover {
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        .log-item.success {
            border-left-color: #28a745;
        }
        .log-item.failed {
            border-left-color: #dc3545;
        }
        .log-item.processing {
            border-left-color: #ffc107;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="upload-container">
                    <div class="text-center mb-4">
                        <h2 class="text-primary">
                            <i class="fas fa-upload"></i> 의료제품 엑셀 업로드
                        </h2>
                        <p class="text-muted">엑셀 파일을 업로드하여 의료제품 정보를 일괄 등록할 수 있습니다.</p>
                        <div class="mt-3">
                            <a href="<?= base_url('upload') ?>" class="btn btn-outline-secondary me-2">
                                <i class="fas fa-arrow-left"></i> 업로드 메인
                            </a>
                            <a href="<?= base_url('medical_products') ?>" class="btn btn-outline-primary">
                                <i class="fas fa-search"></i> 제품 검색
                            </a>
                        </div>
                    </div>

                    <!-- 파일 형식 안내 -->
                    <div class="format-guide">
                        <h5><i class="fas fa-info-circle"></i> 엑셀 파일 형식 안내</h5>
                        <p class="mb-2"><strong>파일 형식:</strong> .xlsx, .xls 파일만 업로드 가능</p>
                        <p class="mb-2"><strong>최대 크기:</strong> 10MB 이하</p>
                        <p class="mb-2"><strong>시트명:</strong> "raw_data" 시트의 데이터를 처리합니다</p>
                        <p class="mb-0"><strong>처리 방식:</strong> 기존 데이터를 모두 삭제하고 새로 입력됩니다</p>
                    </div>

                    <!-- 컬럼 정보 안내 -->
                    <div class="column-info">
                        <h5><i class="fas fa-table"></i> 처리되는 컬럼 정보 (14개 컬럼)</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <ul class="list-unstyled mb-0 small">
                                    <li><strong>B열:</strong> CSO품목</li>
                                    <li><strong>D열:</strong> 구분</li>
                                    <li><strong>E열:</strong> 업체명</li>
                                    <li><strong>F열:</strong> 분류번호</li>
                                    <li><strong>J열:</strong> 보험코드</li>
                                    <li><strong>K열:</strong> 제품명</li>
                                    <li><strong>L열:</strong> 약가</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul class="list-unstyled mb-0 small">
                                    <li><strong>M열:</strong> 성분명(영문)</li>
                                    <li><strong>P열:</strong> 제형</li>
                                    <li><strong>Q열:</strong> 성분코드</li>
                                    <li><strong>T열:</strong> 함량</li>
                                    <li><strong>U열:</strong> 단위</li>
                                    <li><strong>V열:</strong> ATC코드</li>
                                    <li><strong>AQ열:</strong> 수수료율</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- 오류 메시지 표시 -->
                    <?php if (isset($error)): ?>
                        <div class="error-message">
                            <strong>업로드 오류:</strong> <?= $error ?>
                        </div>
                    <?php endif; ?>

                    <!-- 업로드 폼 -->
                    <form id="uploadForm" enctype="multipart/form-data" action="<?= base_url('medical_products/process_excel') ?>" method="post">
                        <div class="drag-drop-zone" id="dragDropZone">
                            <i class="fas fa-cloud-upload-alt fa-3x text-primary mb-3"></i>
                            <h4>파일을 이곳에 드래그하거나 클릭하여 선택하세요</h4>
                            <p class="text-muted">의료제품 엑셀 파일 (.xlsx, .xls)</p>
                            <input type="file" name="excel_file" id="excel_file" class="d-none" accept=".xlsx,.xls">
                        </div>

                        <!-- 파일 정보 표시 -->
                        <div class="file-info" id="fileInfo">
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>파일명:</strong> <span id="fileName"></span>
                                </div>
                                <div class="col-md-3">
                                    <strong>크기:</strong> <span id="fileSize"></span>
                                </div>
                                <div class="col-md-3">
                                    <strong>형식:</strong> <span id="fileType"></span>
                                </div>
                            </div>
                        </div>

                        <!-- 진행률 표시 -->
                        <div class="progress-container" id="progressContainer">
                            <div class="progress">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" 
                                     role="progressbar" style="width: 0%" id="uploadProgress"></div>
                            </div>
                            <div class="text-center mt-2">
                                <small class="text-muted" id="progressText">업로드 중...</small>
                            </div>
                        </div>

                        <!-- 업로드 버튼 -->
                        <div class="text-center mt-3">
                            <button type="submit" class="btn btn-upload text-white" id="uploadBtn" disabled>
                                <i class="fas fa-upload"></i> 업로드 및 저장
                            </button>
                            <button type="button" class="btn btn-outline-secondary ms-2" onclick="location.reload()">
                                <i class="fas fa-refresh"></i> 새로고침
                            </button>
                        </div>
                    </form>

                    <!-- 결과 표시 -->
                    <div id="resultContainer" style="display: none;">
                        <hr>
                        <h5><i class="fas fa-chart-bar"></i> 업로드 결과</h5>
                        <div class="row text-center">
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title text-success" id="successCount">0</h5>
                                        <p class="card-text">성공한 데이터</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title text-danger" id="failedCount">0</h5>
                                        <p class="card-text">실패한 데이터</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title text-info" id="totalCount">0</h5>
                                        <p class="card-text">전체 데이터</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 최근 업로드 이력 사이드바 -->
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="log-sidebar">
                    <h5><i class="fas fa-history"></i> 최근 업로드 이력</h5>
                    <div class="mt-3">
                        <?php if (!empty($upload_logs)): ?>
                            <?php foreach ($upload_logs as $log): ?>
                                <div class="log-item <?= $log['status'] ?>">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h6 class="mb-1"><?= htmlspecialchars($log['filename']) ?></h6>
                                            <small class="text-muted"><?= date('Y-m-d H:i', strtotime($log['created_at'])) ?></small>
                                        </div>
                                        <span class="badge bg-<?= $log['status'] === 'completed' ? 'success' : ($log['status'] === 'failed' ? 'danger' : 'warning') ?>">
                                            <?= $log['status'] ?>
                                        </span>
                                    </div>
                                    <?php if ($log['status'] === 'completed'): ?>
                                        <div class="mt-2">
                                            <small>
                                                <i class="fas fa-check-circle text-success me-1"></i>
                                                성공: <?= number_format($log['success_rows']) ?>개 |
                                                <i class="fas fa-times-circle text-danger me-1"></i>
                                                실패: <?= number_format($log['failed_rows']) ?>개
                                            </small>
                                        </div>
                                    <?php elseif ($log['status'] === 'failed'): ?>
                                        <div class="mt-2">
                                            <small class="text-danger">
                                                <i class="fas fa-exclamation-triangle me-1"></i>
                                                <?= htmlspecialchars($log['error_message'] ?? '오류 정보 없음') ?>
                                            </small>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center text-muted py-4">
                                <i class="fas fa-history fa-2x mb-2"></i>
                                <p>업로드 이력이 없습니다.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <hr>

        <div class="row">
            <!-- 복합 엑셀 업로드 -->
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-file-excel me-2 text-success"></i>복합 엑셀 업로드 (Raw Data 시트)</h5>
                    </div>
                    <div class="card-body">
                        <p class="card-text">표준 양식의 엑셀 파일을 업로드합니다. 'raw_data' 시트의 데이터를 처리하여 전체 데이터를 업데이트합니다.</p>
                        <form action="<?= base_url('medical_products/process_excel') ?>" method="post" enctype="multipart/form-data" class="upload-form">
                            <div class="mb-3">
                                <label for="excel_file" class="form-label">엑셀 파일 선택</label>
                                <input class="form-control" type="file" name="excel_file" id="excel_file" required accept=".xlsx, .xls">
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-upload me-2"></i>업로드 및 처리 시작
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- 단순 엑셀 업로드 -->
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-file-alt me-2 text-info"></i>단순 엑셀 업로드</h5>
                    </div>
                    <div class="card-body">
                        <p class="card-text">필수 컬럼(제품명, 회사명, 보험코드 등)을 포함한 단순 형식의 엑셀 파일을 업로드합니다. 기존 데이터를 업데이트하거나 새 데이터를 추가합니다.</p>
                        <form action="<?= base_url('medical_products/upload_simple') ?>" method="post" enctype="multipart/form-data" class="upload-form">
                            <div class="mb-3">
                                <label for="excel_file_simple" class="form-label">엑셀 파일 선택</label>
                                <input class="form-control" type="file" name="excel_file_simple" id="excel_file_simple" required accept=".xlsx, .xls">
                            </div>
                            <button type="submit" class="btn btn-info w-100">
                                <i class="fas fa-plus-circle me-2"></i>단순 데이터 추가/업데이트
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <hr class="my-5">

        <div class="card mt-4">
            <div class="card-header">
                <h5><i class="fas fa-file-excel"></i> 엑셀 데이터 추출 및 다운로드</h5>
            </div>
            <div class="card-body">
                <p>엑셀 파일의 'raw_data' 시트에서 특정 열의 데이터만 추출하여 새 엑셀 파일로 다운로드합니다.</p>
                <?= form_open_multipart('medical_products/download_filtered_excel', ['id' => 'downloadForm']) ?>
                    <div class="mb-3">
                        <label for="excel_file_download" class="form-label">엑셀 파일 선택</label>
                        <input class="form-control" type="file" id="excel_file_download" name="excel_file" required>
                    </div>
                    <div class="mb-3">
                        <label for="columns_to_extract" class="form-label">추출할 열 (쉼표로 구분)</label>
                        <input type="text" class="form-control" id="columns_to_extract" name="columns" value="B,D,E,F,J,K,L,M,P,Q,T,U,V,AQ">
                        <div class="form-text">'XS'와 같이 잘못된 열 이름은 무시됩니다.</div>
                    </div>
                    <button type="submit" class="btn btn-info">
                        <i class="fas fa-download"></i> 추출 및 다운로드
                    </button>
                <?= form_close() ?>
            </div>
        </div>

        <h4 class="mt-5"><i class="fas fa-history"></i> 최근 업로드 기록</h4>
        <table class="table table-striped table-hover mt-3">
            <thead class="table-dark">
                <tr>
                    <th>파일명</th>
                    <th>상태</th>
                    <th>성공 개수</th>
                    <th>실패 개수</th>
                    <th>전체 개수</th>
                    <th>오류 메시지</th>
                    <th>시간</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($upload_logs)): ?>
                    <?php foreach ($upload_logs as $log): ?>
                        <tr>
                            <td><?= htmlspecialchars($log['filename']) ?></td>
                            <td><?= $log['status'] ?></td>
                            <td><?= number_format($log['success_rows']) ?></td>
                            <td><?= number_format($log['failed_rows']) ?></td>
                            <td><?= number_format($log['total_rows']) ?></td>
                            <td><?= htmlspecialchars($log['error_message'] ?? '오류 정보 없음') ?></td>
                            <td><?= date('Y-m-d H:i', strtotime($log['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">업로드 이력이 없습니다.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const dragDropZone = document.getElementById('dragDropZone');
        const fileInput = document.getElementById('excel_file');
        const fileInfo = document.getElementById('fileInfo');
        const uploadBtn = document.getElementById('uploadBtn');
        const uploadForm = document.getElementById('uploadForm');
        const progressContainer = document.getElementById('progressContainer');
        const resultContainer = document.getElementById('resultContainer');

        // 드래그 앤 드롭 이벤트
        dragDropZone.addEventListener('click', () => fileInput.click());
        
        dragDropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dragDropZone.classList.add('dragover');
        });

        dragDropZone.addEventListener('dragleave', () => {
            dragDropZone.classList.remove('dragover');
        });

        dragDropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dragDropZone.classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                fileInput.files = files;
                handleFileSelect(files[0]);
            }
        });

        // 파일 선택 이벤트
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                handleFileSelect(e.target.files[0]);
            }
        });

        // 파일 선택 처리
        function handleFileSelect(file) {
            const fileName = file.name;
            const fileSize = formatFileSize(file.size);
            const fileType = file.type || fileName.split('.').pop().toUpperCase();

            document.getElementById('fileName').textContent = fileName;
            document.getElementById('fileSize').textContent = fileSize;
            document.getElementById('fileType').textContent = fileType;

            fileInfo.style.display = 'block';
            uploadBtn.disabled = false;

            // 결과 컨테이너 숨기기
            resultContainer.style.display = 'none';
        }

        // 파일 크기 포맷팅
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        // 폼 제출 처리
        uploadForm.addEventListener('submit', function(e) {
            if (fileInput.files.length === 0) {
                e.preventDefault();
                alert('파일을 먼저 선택해주세요.');
                return;
            }

            // 진행률 표시
            progressContainer.style.display = 'block';
            uploadBtn.disabled = true;
            
            // 간단한 진행률 애니메이션
            let progress = 0;
            const progressBar = document.getElementById('uploadProgress');
            const progressText = document.getElementById('progressText');
            
            const interval = setInterval(() => {
                progress += Math.random() * 15;
                if (progress > 90) progress = 90;
                progressBar.style.width = progress + '%';
                progressText.textContent = `업로드 중... ${Math.round(progress)}%`;
            }, 200);

            // 실제 제출 시 정리
            setTimeout(() => {
                clearInterval(interval);
                progressBar.style.width = '100%';
                progressText.textContent = '처리 중...';
            }, 2000);
        });
    });
    </script>
</body>
</html> 
